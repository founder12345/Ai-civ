"""
Run the full Phase 1-5 simulation headless and print stats over time —
economy + society + politics + Tier-2 cognition, all wired together.

Demonstrates, in one run:
  - a stable multi-subsystem tick loop over 400+ ticks
  - an election firing on schedule and the ruling party changing
  - a sandbox-injected pandemic visibly denting the economy and happiness
  - Tier-2 cognition producing real reasoning traces for high-salience citizens
"""

from civ_lab.seed import build_default_simulation


def print_header():
    print(f"{'tick':>5} {'GDP':>9} {'unemp%':>7} {'happy':>6} {'crime':>6} {'approval':>8} {'party':>20} {'pop':>4}")


def print_row(stats: dict):
    print(
        f"{stats['tick']:>5} "
        f"{stats['gdp']:>9.1f} "
        f"{stats['unemployment_rate']*100:>6.1f}% "
        f"{stats['avg_happiness']:>6.3f} "
        f"{stats['crime_rate']:>6.3f} "
        f"{stats['government_approval']:>8.3f} "
        f"{(stats['ruling_party'] or '—'):>20} "
        f"{stats['population']:>4}"
    )


def main():
    sim = build_default_simulation(n_citizens=50, n_companies=8, seed=42)

    print("=== AI Civilization Laboratory — Phase 1-5 headless run ===")
    print(f"Seeded {len(sim.citizens)} citizens, {len(sim.companies)} companies, "
          f"{len(sim.parties)} parties. Cognition uses MockLLMClient (no network in this environment;\n"
          f"swap in AnthropicLLMClient locally for real reasoning — see civ_lab/llm.py).\n")
    print_header()
    print_row(sim.stats())

    for _ in range(10):
        sim.step(20)
        print_row(sim.stats())

    print("\n>>> SANDBOX EVENT: pandemic (severity 0.6) injected\n")
    print(sim.trigger_event("pandemic", 0.6))

    print_header()
    for _ in range(6):
        sim.step(20)
        print_row(sim.stats())

    print("\nRecent event log (last 15):")
    for entry in sim.world.event_log[-15:]:
        print(" ", entry)

    print("\n--- Citizens with a completed cognition pass ---")
    reasoning_citizens = [c for c in sim.citizens.values() if c.current_reasoning]
    for c in reasoning_citizens[:5]:
        print(f"\n{c.name} (age {c.age}, {c.status.value}, ideology {c.political_ideology:+.2f})")
        print(f"  goals: {c.goals}")
        print(f"  reasoning: {c.current_reasoning}")
    if not reasoning_citizens:
        print("  (none yet — run more ticks, cognition triggers on salience-crossing events)")

    print(f"\nTotal cognition passes so far: {len(reasoning_citizens)} / {sim.world.population} living citizens")


if __name__ == "__main__":
    main()
