"""Nexus v1.0 advanced civilization systems.

All systems are deterministic given the simulation RNG. They are intentionally
bounded and simulation-authoritative: agents may request actions, but this
module is the final authority on macroeconomic/social state.
"""
from __future__ import annotations
import math
import statistics
from .models import EmploymentStatus, MaritalStatus


def _alive(citizens):
    return [c for c in citizens.values() if c.alive]


def _clamp(x, lo, hi):
    return max(lo, min(hi, x))


def tick_finance(citizens, companies, world, rng):
    alive = _alive(citizens)
    if not alive:
        return
    # Banks: deposits earn modest interest; consumer/business credit follows policy rate.
    world.central_bank_rate = _clamp(world.interest_rate + 0.5 * world.inflation, 0.005, 0.15)
    for c in alive:
        if c.bank_balance <= 0:
            c.bank_balance = max(0.0, c.wealth * 0.25)
        deposit_interest = c.bank_balance * max(0.0, world.central_bank_rate - 0.01) / 365.0
        c.bank_balance += deposit_interest
        c.wealth += deposit_interest
        if c.loan_balance > 0:
            interest = c.loan_balance * (c.loan_rate / 365.0)
            payment = min(c.wealth * 0.01, c.loan_balance + interest)
            c.wealth -= payment
            c.loan_balance = max(0.0, c.loan_balance + interest - payment)
            c.credit_score = _clamp(c.credit_score + (0.15 if payment >= interest else -0.4), 300, 850)
        # savings and credit evolve with income and employment
        if c.income > 0:
            c.bank_balance += c.income * c.savings_rate * 0.03
        c.credit_score = _clamp(c.credit_score + (0.03 if c.status == EmploymentStatus.EMPLOYED else -0.05), 300, 850)

    # Equity pricing: bounded demand/profit expectations, no wealth creation from nothing.
    returns = []
    for co in companies.values():
        if co.is_bankrupt:
            continue
        earnings_signal = co.profit_last_tick / max(100.0, co.cash + 1000.0)
        demand_signal = (co.revenue_last_tick / max(1.0, co.headcount * co.price_level)) - 1.0
        shock = rng.gauss(0, 0.008)
        change = _clamp(0.004 * earnings_signal + 0.003 * demand_signal + shock, -0.08, 0.08)
        old = max(0.5, co.stock_price)
        co.stock_price = _clamp(old * (1 + change), 0.5, 10000)
        returns.append((co.stock_price / old) - 1)
    if returns:
        world.stock_market_index = _clamp(world.stock_market_index * (1 + statistics.mean(returns)), 20, 10000)

    # Poverty and housing pressure.
    poverty_line = max(20.0, 0.35 * statistics.median([max(0.0, c.income) for c in alive]))
    world.poverty_rate = sum(1 for c in alive if c.wealth < poverty_line * 20 or c.income < poverty_line) / len(alive)
    if world.housing_price_index <= 0:
        world.housing_price_index = 100.0
    demand = sum(1 for c in alive if c.owns_home) / len(alive)
    affordability = statistics.mean([_clamp(c.wealth / 6000.0, 0, 2) for c in alive])
    housing_growth = 0.0005 + 0.001 * (demand - 0.5) + 0.001 * (affordability - 0.5) - 0.01 * max(0, world.interest_rate - 0.05)
    housing_growth += rng.gauss(0, 0.0015)
    world.housing_price_index = _clamp(world.housing_price_index * (1 + housing_growth), 30, 500)
    for c in alive:
        if c.owns_home:
            c.housing_value = max(1000, c.housing_value * (world.housing_price_index / max(1, getattr(c, '_last_hpi', world.housing_price_index))))
        else:
            base_rent = 45 * (world.housing_price_index / 100)
            c.rent = base_rent * (1.0 + 0.25 * (1 - c.happiness))
        c._last_hpi = world.housing_price_index


def tick_government(citizens, companies, world, rng):
    alive = _alive(citizens)
    if not alive:
        return
    # Automatic stabilizers and simple fiscal rule.
    unemployment = sum(c.status == EmploymentStatus.UNEMPLOYED for c in alive) / len(alive)
    tax_revenue = sum(max(0, c.income) for c in alive) * world.tax_rate
    welfare = sum(min(25.0, 8.0 + 20.0 * unemployment) for c in alive if c.status == EmploymentStatus.UNEMPLOYED)
    infra = max(0.0, 20.0 * world.infrastructure)
    spending = welfare + infra
    world.welfare_spending = welfare
    world.government_budget += tax_revenue - spending
    deficit = max(0.0, -world.government_budget)
    world.government_debt += deficit * 0.03
    if world.government_budget < -50000:
        world.tax_rate = _clamp(world.tax_rate + 0.0005, 0.05, 0.45)
    elif world.government_budget > 100000:
        world.tax_rate = _clamp(world.tax_rate - 0.0003, 0.05, 0.45)
    # Policy feedback: approval responds to jobs, inflation and services.
    score = 0.55 - 0.9 * unemployment - 0.7 * abs(world.inflation) + 0.25 * world.infrastructure
    world.government_approval = _clamp(score, 0.05, 0.95)
    if world.tick % 24 == 0:
        policy = {"tick": world.tick, "tax_rate": world.tax_rate, "interest_rate": world.interest_rate,
                  "infrastructure": world.infrastructure, "approval": world.government_approval}
        world.policy_history.append(policy)
        world.policy_history[:] = world.policy_history[-200:]


def tick_society_network(citizens, world, rng):
    alive = _alive(citizens)
    if not alive:
        return
    # Sparse small-world-ish relationship graph stored as nested dict.
    for c in alive:
        world.relationships.setdefault(str(c.id), {})
    if world.tick % 12 == 0:
        for c in alive:
            candidates = [x for x in alive if x.id != c.id and abs(x.age-c.age) < 15]
            if candidates and len(world.relationships[str(c.id)]) < 5:
                friend = rng.choice(candidates)
                key = str(friend.id)
                world.relationships[str(c.id)][key] = round(_clamp(0.35 + rng.random()*0.6, 0, 1), 3)
                world.relationships.setdefault(key, {})[str(c.id)] = world.relationships[str(c.id)][key]
            c.social_activity = _clamp(c.social_activity + rng.gauss(0, .01), 0, 1)
    # Social cohesion/polarization from ideology distance and network trust.
    pairs = []
    for a_id, rels in world.relationships.items():
        a = citizens.get(int(a_id))
        if not a or not a.alive: continue
        for b_id, trust in rels.items():
            b = citizens.get(int(b_id))
            if b and b.alive and int(a_id) < b.id:
                pairs.append((abs(a.political_ideology-b.political_ideology), trust))
    if pairs:
        world.polarization = _clamp(statistics.mean(p[0] for p in pairs), 0, 2) / 2
        world.social_cohesion = _clamp(statistics.mean(p[1] for p in pairs) * (1-world.polarization), 0, 1)


def tick_generations(citizens, companies, world, rng, allocate_id):
    alive = _alive(citizens)
    # Births are rare and bounded. New citizens inherit a blend of parents' traits.
    if world.tick % 24 == 0:
        couples = [(c, citizens.get(c.spouse_id)) for c in alive if c.marital_status == MaritalStatus.MARRIED and c.spouse_id and c.id < c.spouse_id]
        for a, b in couples:
            if not b or a.age > 48 or b.age > 48 or rng.random() > 0.025:
                continue
            cid = allocate_id()
            child = type(a)(id=cid, name=f"{rng.choice(['Ari','Sam','Leo','Mia','Nora','Eli'])} {rng.choice(['Nova','River','Vale','Stone'])}",
                age=0, skill_level=_clamp((a.skill_level+b.skill_level)/2+rng.gauss(0,.08),.05,.99), wealth=0,
                education_level=_clamp((a.education_level+b.education_level)/2+rng.gauss(0,.05),.1,.99),
                political_ideology=_clamp((a.political_ideology+b.political_ideology)/2+rng.gauss(0,.12),-1,1),
                consumption_propensity=_clamp((a.consumption_propensity+b.consumption_propensity)/2+rng.gauss(0,.05),.4,.95),
                risk_tolerance=_clamp((a.risk_tolerance+b.risk_tolerance)/2+rng.gauss(0,.1),0,1),
                parent_ids=[a.id,b.id], goals=['grow and learn'])
            citizens[cid] = child
            a.child_ids.append(cid); b.child_ids.append(cid)
            world.births_total += 1
            world.log(f"A new generation was born to {a.name} and {b.name}.")
    # Career/education progression.
    for c in alive:
        if c.age >= 18 and c.status == EmploymentStatus.EMPLOYED:
            c.career_level = min(10, c.career_level + (1 if world.tick % 48 == 0 and rng.random() < .25 else 0))
            c.skill_level = _clamp(c.skill_level + 0.001 * world.education_funding_level, 0, 1)


def tick_environment_and_technology(citizens, companies, world, rng):
    active = [c for c in companies.values() if not c.is_bankrupt]
    automation = max(0, world.technology_progress) * 0.0001
    for co in active:
        co.technology_level = _clamp(co.technology_level + automation + rng.gauss(0,.0003), .5, 5)
        co.productivity = _clamp(co.productivity + (co.technology_level-1)*.0005, .5, 5)
    output = sum(co.headcount * co.productivity for co in active)
    world.productivity_index = _clamp(95 + output / max(1,len(citizens))*10, 50, 300)
    world.technology_progress = _clamp(world.technology_progress + 0.001 * statistics.mean([c.education_level for c in _alive(citizens)]) if citizens else 0, 0, 100)
    world.emissions = output * (1.2 - 0.6 * world.environmental_quality)
    world.environmental_quality = _clamp(world.environmental_quality - world.emissions * 0.000001 + world.infrastructure*0.0000005, 0, 1)
    world.energy_price = _clamp(world.energy_price * (1 + rng.gauss(0,.003) + 0.00001*(1-world.environmental_quality)*100), .2, 5)


def tick_international(world, rng):
    # A compact open-economy layer: trade responds to relative price and energy costs.
    world.exchange_rate = _clamp(world.exchange_rate * (1 + 0.0005*(world.inflation) + rng.gauss(0,.0015)), .5, 2)
    imports = 0.02 * max(0, world.gdp) * world.energy_price
    exports = 0.025 * max(0, world.gdp) * (1 + world.productivity_index/200) / max(.5, world.exchange_rate)
    world.trade_balance = exports - imports
    world.gdp += world.trade_balance * 0.02


def record_macro(world):
    world.macro_history.append({
        'tick': world.tick, 'gdp': round(world.gdp,2), 'inflation': round(world.inflation,4),
        'unemployment': round(world.unemployment_rate,4), 'housing_index': round(world.housing_price_index,2),
        'stock_index': round(world.stock_market_index,2), 'poverty': round(world.poverty_rate,4),
        'polarization': round(world.polarization,4), 'cohesion': round(world.social_cohesion,4),
        'government_debt': round(world.government_debt,2), 'trade_balance': round(world.trade_balance,2),
        'environment': round(world.environmental_quality,4)
    })
    world.macro_history[:] = world.macro_history[-2000:]
