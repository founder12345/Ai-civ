"""
Validated action layer — Phase 5.

This is the boundary the architecture doc calls for: "LLM = decision-maker,
simulation = authority." cognition.py gets a *proposed* action name (a
string) out of the LLM/mock response; nothing about that proposal touches
Citizen/Company/WorldState directly. Every action here re-checks the real
numbers (wealth, headcount, debt, available lots) before mutating
anything, and returns a plain-English result string describing what
actually happened — including "rejected because you can't afford it",
which is the whole point: an agent can't just declare "buy a €2M house"
into existence.

Every function has the same shape: (citizen, ctx) -> str, where ctx
bundles whatever that action needs (citizens dict, companies dict,
world, layout, rng). Keeping ctx a single object instead of a long
parameter list keeps ACTIONS a flat, easy-to-extend registry.
"""

from __future__ import annotations
import random
from dataclasses import dataclass
from .models import Citizen, Company, WorldState, EmploymentStatus
from . import city as city_module

SECTORS = ["Food", "Tech", "Retail", "Construction", "Healthcare"]

ACTIONS = frozenset({
    "SEARCH_FOR_JOB", "CHANGE_JOB", "REDUCE_SPENDING", "INCREASE_SPENDING",
    "SAVE_MONEY", "TAKE_LOAN", "REPAY_DEBT", "BUY_HOME", "SELL_HOME", "MOVE",
    "START_BUSINESS", "CLOSE_BUSINESS", "SOCIALIZE", "JOIN_PROTEST",
    "CHANGE_POLITICAL_SUPPORT", "DO_NOTHING",
})

HOME_PRICE = 6000.0  # flat, simplified valuation — see README/city.html note on housing not being a full market yet


@dataclass
class ActionContext:
    citizens: dict[int, Citizen]
    companies: dict[int, Company]
    world: WorldState
    layout: "city_module.CityLayout | None"
    rng: random.Random
    parties: dict | None = None


def _next_company_id(companies: dict[int, Company]) -> int:
    return max(companies, default=0) + 1


def _act_search_for_job(citizen: Citizen, ctx: ActionContext) -> str:
    if citizen.status == EmploymentStatus.EMPLOYED:
        return "Already employed — no job search needed."
    openings = [c for c in ctx.companies.values() if not c.is_bankrupt and c.headcount < c.target_headcount]
    if not openings:
        return "Searched for work, but no openings were available right now."
    company = max(openings, key=lambda c: c.wage_budget_per_head)
    success_chance = 0.3 + 0.5 * citizen.skill_level
    if ctx.rng.random() < success_chance:
        citizen.status = EmploymentStatus.EMPLOYED
        citizen.employer_id = company.id
        citizen.ticks_unemployed = 0
        company.employee_ids.append(citizen.id)
        ctx.world.log(f"{citizen.name} found a new job at {company.name}.")
        return f"Hired at {company.name}."
    return f"Applied at {company.name} but wasn't hired this time."


def _act_change_job(citizen: Citizen, ctx: ActionContext) -> str:
    if citizen.status != EmploymentStatus.EMPLOYED:
        return _act_search_for_job(citizen, ctx)
    current = ctx.companies.get(citizen.employer_id)
    better = [c for c in ctx.companies.values()
              if not c.is_bankrupt and c.id != citizen.employer_id and c.headcount < c.target_headcount
              and (current is None or c.wage_budget_per_head > current.wage_budget_per_head)]
    if not better:
        return "Looked for a better position but found nothing worth switching to."
    target = max(better, key=lambda c: c.wage_budget_per_head)
    if ctx.rng.random() < 0.3 + 0.5 * citizen.skill_level:
        if current:
            current.employee_ids = [cid for cid in current.employee_ids if cid != citizen.id]
        citizen.employer_id = target.id
        target.employee_ids.append(citizen.id)
        ctx.world.log(f"{citizen.name} switched jobs to {target.name}.")
        return f"Switched jobs to {target.name}."
    return f"Interviewed at {target.name} but didn't get the offer."


def _act_reduce_spending(citizen: Citizen, ctx: ActionContext) -> str:
    before = citizen.consumption_propensity
    citizen.consumption_propensity = max(0.1, citizen.consumption_propensity - 0.10)
    return f"Cut spending rate from {before:.2f} to {citizen.consumption_propensity:.2f}."


def _act_increase_spending(citizen: Citizen, ctx: ActionContext) -> str:
    before = citizen.consumption_propensity
    citizen.consumption_propensity = min(0.95, citizen.consumption_propensity + 0.10)
    return f"Raised spending rate from {before:.2f} to {citizen.consumption_propensity:.2f}."


def _act_save_money(citizen: Citizen, ctx: ActionContext) -> str:
    before = citizen.consumption_propensity
    citizen.consumption_propensity = max(0.05, citizen.consumption_propensity - 0.15)
    return f"Committed to saving more — spending rate {before:.2f} -> {citizen.consumption_propensity:.2f}."


def _act_take_loan(citizen: Citizen, ctx: ActionContext) -> str:
    if citizen.debt > citizen.income * 10 + 2000:
        return "Loan request rejected — existing debt is already too high relative to income."
    amount = round(min(citizen.wealth * 0.5 + 500, 3000), 2)
    citizen.wealth += amount
    citizen.debt = round(citizen.debt + amount * 1.05, 2)  # 5% origination, simplified
    return f"Took a loan of {amount:.0f} (new debt: {citizen.debt:.0f})."


def _act_repay_debt(citizen: Citizen, ctx: ActionContext) -> str:
    if citizen.debt <= 0:
        return "No debt to repay."
    pay = round(min(citizen.debt, citizen.wealth * 0.5), 2)
    if pay <= 0:
        return "Wanted to repay debt but has no spare wealth to do it with."
    citizen.debt -= pay
    citizen.wealth -= pay
    return f"Repaid {pay:.0f} of debt (remaining: {citizen.debt:.0f})."


def _act_buy_home(citizen: Citizen, ctx: ActionContext) -> str:
    if citizen.owns_home:
        return "Already owns a home."
    if citizen.wealth < HOME_PRICE:
        return f"Wanted to buy a home ({HOME_PRICE:.0f}) but only has {citizen.wealth:.0f} — rejected."
    citizen.wealth -= HOME_PRICE
    citizen.owns_home = True
    return f"Bought a home for {HOME_PRICE:.0f}."


def _act_sell_home(citizen: Citizen, ctx: ActionContext) -> str:
    if not citizen.owns_home:
        return "Doesn't own a home to sell."
    proceeds = HOME_PRICE * 0.9  # friction/depreciation
    citizen.wealth += proceeds
    citizen.owns_home = False
    return f"Sold their home for {proceeds:.0f}."


def _act_move(citizen: Citizen, ctx: ActionContext) -> str:
    if ctx.layout is None or not ctx.layout.house_lots:
        return "No alternate housing available to move to."
    options = [lot for lot in ctx.layout.house_lots if lot != (citizen.home_x, citizen.home_y)]
    if not options:
        return "No alternate housing available to move to."
    x, y = ctx.rng.choice(options)
    citizen.home_x, citizen.home_y = x, y
    return f"Moved to a new home at ({x}, {y})."


def _act_start_business(citizen: Citizen, ctx: ActionContext) -> str:
    cost = 1000.0
    if citizen.wealth < cost:
        return f"Wanted to start a business ({cost:.0f}) but only has {citizen.wealth:.0f} — rejected."
    if ctx.layout is None:
        return "No location available to place a new business."
    sector = ctx.rng.choice(SECTORS)
    building_type = city_module.SECTOR_TO_BUILDING.get(sector, city_module.TILE_OFFICE)
    preference = city_module.SECTOR_ZONE_PREFERENCE.get(sector, (city_module.ZONE_DOWNTOWN,))
    pt = ctx.layout._take_lot(preference[0], fallback=preference[1:])
    if pt is None:
        return "Wanted to start a business but there's no available lot in the city — rejected."
    x, y = pt
    ctx.layout.tiles[y][x] = building_type
    new_id = _next_company_id(ctx.companies)
    company = Company(
        id=new_id, name=f"{citizen.name.split()[0]}'s {sector} Venture", sector=sector,
        cash=2500.0, target_headcount=2, wage_budget_per_head=24.0, price_level=10.0,
        loc_x=x, loc_y=y, building_type=building_type, founder_id=citizen.id,
    )
    company.employee_ids.append(citizen.id)
    ctx.companies[new_id] = company
    if citizen.employer_id and citizen.employer_id in ctx.companies:
        old = ctx.companies[citizen.employer_id]
        old.employee_ids = [cid for cid in old.employee_ids if cid != citizen.id]
    citizen.wealth -= cost
    citizen.employer_id = new_id
    citizen.status = EmploymentStatus.EMPLOYED
    ctx.world.log(f"{citizen.name} started a new business: {company.name}.")
    return f"Started {company.name} with {cost:.0f} in startup capital."


def _act_close_business(citizen: Citizen, ctx: ActionContext) -> str:
    owned = [c for c in ctx.companies.values() if c.founder_id == citizen.id and not c.is_bankrupt]
    if not owned:
        return "Doesn't own an active business to close."
    company = owned[0]
    company.is_bankrupt = True
    for cid in company.employee_ids:
        if cid in ctx.citizens:
            ctx.citizens[cid].status = EmploymentStatus.UNEMPLOYED
            ctx.citizens[cid].employer_id = None
    company.employee_ids = []
    ctx.world.log(f"{citizen.name} closed their business: {company.name}.")
    return f"Closed {company.name}."


def _act_socialize(citizen: Citizen, ctx: ActionContext) -> str:
    before = citizen.happiness
    citizen.happiness = min(1.0, citizen.happiness + 0.05)
    return f"Spent time socializing — happiness {before:.2f} -> {citizen.happiness:.2f}."


def _act_join_protest(citizen: Citizen, ctx: ActionContext) -> str:
    ctx.world.government_approval = max(0.0, ctx.world.government_approval - 0.002)
    return "Joined a protest against the government."


def _act_change_political_support(citizen: Citizen, ctx: ActionContext) -> str:
    if not ctx.parties:
        return "No parties available to shift support toward."
    closest = min(ctx.parties.values(), key=lambda p: abs(p.ideology_center - citizen.political_ideology))
    citizen.party_id = closest.id
    return f"Shifted political support toward {closest.name}."


def _act_do_nothing(citizen: Citizen, ctx: ActionContext) -> str:
    return "Decided to maintain their current course."


_HANDLERS = {
    "SEARCH_FOR_JOB": _act_search_for_job,
    "CHANGE_JOB": _act_change_job,
    "REDUCE_SPENDING": _act_reduce_spending,
    "INCREASE_SPENDING": _act_increase_spending,
    "SAVE_MONEY": _act_save_money,
    "TAKE_LOAN": _act_take_loan,
    "REPAY_DEBT": _act_repay_debt,
    "BUY_HOME": _act_buy_home,
    "SELL_HOME": _act_sell_home,
    "MOVE": _act_move,
    "START_BUSINESS": _act_start_business,
    "CLOSE_BUSINESS": _act_close_business,
    "SOCIALIZE": _act_socialize,
    "JOIN_PROTEST": _act_join_protest,
    "CHANGE_POLITICAL_SUPPORT": _act_change_political_support,
    "DO_NOTHING": _act_do_nothing,
}


def apply_action(citizen: Citizen, action: str, ctx: ActionContext) -> str:
    """The single authoritative entry point. Unknown/invalid actions never
    reach here — cognition.py coerces anything outside ACTIONS to
    DO_NOTHING before calling this."""
    handler = _HANDLERS.get(action, _act_do_nothing)
    result = handler(citizen, ctx)
    citizen.last_action = action
    citizen.last_action_result = result
    return result
