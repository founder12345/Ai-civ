"""Portable SQLite checkpoints for Nexus worlds."""
from __future__ import annotations
import json, sqlite3, random
from dataclasses import asdict
from .models import WorldState, Citizen, Company, Party, MemoryEntry, EmploymentStatus, MaritalStatus
from .city import CityLayout

class CheckpointStore:
    def __init__(self, path='nexus_checkpoints.db'):
        self.path = path
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute('CREATE TABLE IF NOT EXISTS checkpoints (id TEXT PRIMARY KEY, tick INTEGER, payload TEXT)')
        self.db.commit()
    def save(self, sim, checkpoint_id='latest'):
        payload = {'world': asdict(sim.world), 'citizens': [asdict(c) for c in sim.citizens.values()],
                   'companies': [asdict(c) for c in sim.companies.values()], 'parties': [asdict(p) for p in sim.parties.values()],
                   'rng_state': sim.rng.getstate(), 'next_citizen_id': sim._next_citizen_id,
                   'city_layout': asdict(sim.city_layout) if sim.city_layout else None}
        self.db.execute('INSERT OR REPLACE INTO checkpoints VALUES (?,?,?)', (checkpoint_id, sim.world.tick, json.dumps(payload, default=str)))
        self.db.commit(); return checkpoint_id
    def list(self):
        return [{'id': r[0], 'tick': r[1]} for r in self.db.execute('SELECT id,tick FROM checkpoints ORDER BY tick DESC')]
    def load(self, sim, checkpoint_id='latest'):
        row = self.db.execute('SELECT payload FROM checkpoints WHERE id=?', (checkpoint_id,)).fetchone()
        if not row: raise KeyError(checkpoint_id)
        d=json.loads(row[0]); sim.world=WorldState(**{k:v for k,v in d['world'].items() if k in WorldState.__dataclass_fields__})
        sim.citizens={}
        for x in d['citizens']:
            x['status']=EmploymentStatus(x['status']); x['marital_status']=MaritalStatus(x['marital_status'])
            x['memories']=[MemoryEntry(**m) for m in x.get('memories',[])]
            sim.citizens[x['id']]=Citizen(**{k:v for k,v in x.items() if k in Citizen.__dataclass_fields__})
        sim.companies={x['id']:Company(**{k:v for k,v in x.items() if k in Company.__dataclass_fields__}) for x in d['companies']}
        sim.parties={x['id']:Party(**{k:v for k,v in x.items() if k in Party.__dataclass_fields__}) for x in d['parties']}
        # tuple/list conversion for Random.setstate
        def tup(x): return tuple(tup(y) if isinstance(y,list) else y for y in x) if isinstance(x,list) else x
        sim.rng.setstate(tup(d['rng_state'])); sim._next_citizen_id=d['next_citizen_id']
        if d.get('city_layout'):
            sim.city_layout = CityLayout(**d['city_layout'])
        return sim
