"""
Tier-2 cognition's LLM boundary — Phase 5.

create_llm_client() is the single place that decides Mock vs real: if
ANTHROPIC_API_KEY is set (and the anthropic package is installed), it
returns a real AnthropicLLMClient; otherwise it falls back to
MockLLMClient automatically. Nothing else in the codebase needs to know
which one it got — both implement LLMClient.reason() -> str and both
are expected to return a single JSON object matching cognition.py's
schema (see cognition.RESPONSE_SCHEMA_DESCRIPTION).

MockLLMClient is not just a stub anymore: it parses the same structured,
labeled context block cognition.py builds for the real LLM, and makes a
genuinely personality-driven decision (risk_tolerance, wealth, event
category) from a deterministic branching table — this is what makes the
"same event, different personality -> different decision" test provable
offline, with no API key, reproducibly.
"""

from __future__ import annotations
import json
import os
import random
import re
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod


class LLMClient(ABC):
    #: subclasses may set this after reason() returns, e.g. {"input_tokens": N,
    #: "output_tokens": M} — cognition.py reads it via getattr(..., None) so
    #: clients that don't track usage (MockLLMClient) just report nothing.
    last_usage: dict | None = None

    @abstractmethod
    def reason(self, system_prompt: str, user_prompt: str) -> str:
        """Return the raw text response for a single reasoning call —
        expected to be a single JSON object (see cognition.py's schema)."""
        raise NotImplementedError


class AnthropicLLMClient(LLMClient):
    """Real client. Requires `pip install anthropic` and ANTHROPIC_API_KEY
    in the environment (never hardcoded — see .env.example). Model is
    configurable via ANTHROPIC_MODEL, defaulting to a current Sonnet."""

    def __init__(self, model: str | None = None):
        try:
            import anthropic  # noqa: F401
        except ImportError as e:
            raise RuntimeError(
                "anthropic package not installed. `pip install anthropic` "
                "to use AnthropicLLMClient (requires network access)."
            ) from e
        self._anthropic = anthropic
        self._client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env itself
        self.model = model or os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")

    def reason(self, system_prompt: str, user_prompt: str) -> str:
        response = self._client.messages.create(
            model=self.model,
            max_tokens=500,
            system=system_prompt,
            messages=[{"role": "user", "content": user_prompt}],
        )
        usage = getattr(response, "usage", None)
        if usage is not None:
            self.last_usage = {
                "input_tokens": getattr(usage, "input_tokens", 0),
                "output_tokens": getattr(usage, "output_tokens", 0),
            }
        return "".join(block.text for block in response.content if block.type == "text")



class OpenAICompatibleLLMClient(LLMClient):
    """Dependency-free client for OpenAI-compatible chat APIs.

    Used by both Ollama (local, zero marginal cost) and OpenRouter (free
    routed models when OPENROUTER_API_KEY is configured). Keeping this
    transport dependency-free means Nexus can run on a fresh Python install.
    """
    def __init__(self, base_url: str, api_key: str, model: str, *, timeout: float = 25.0,
                 name: str = "openai-compatible"):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or ""
        self.model = model
        self.timeout = timeout
        self.provider_name = name
        self.last_error: str | None = None

    def reason(self, system_prompt: str, user_prompt: str) -> str:
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": 0.35,
            "max_tokens": 500,
            "response_format": {"type": "json_object"},
        }
        data = json.dumps(payload).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        if self.provider_name == "openrouter":
            headers["HTTP-Referer"] = os.environ.get("OPENROUTER_SITE_URL", "https://nexus-sim.local")
            headers["X-OpenRouter-Title"] = "Nexus AI Civilization Simulator"
        req = urllib.request.Request(self.base_url + "/chat/completions", data=data, headers=headers, method="POST")
        started = time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as response:
                body = json.loads(response.read().decode("utf-8"))
            self.last_usage = body.get("usage") or None
            self.last_latency_ms = round((time.perf_counter() - started) * 1000, 1)
            self.last_error = None
            return body["choices"][0]["message"]["content"]
        except Exception as exc:
            self.last_latency_ms = round((time.perf_counter() - started) * 1000, 1)
            self.last_error = str(exc)
            raise RuntimeError(f"{self.provider_name} request failed: {exc}") from exc


class OllamaLLMClient(OpenAICompatibleLLMClient):
    """Local Qwen3/Ollama cognition. Completely free after model download."""
    def __init__(self, model: str | None = None):
        super().__init__(
            os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434/v1"),
            "ollama",
            model or os.environ.get("OLLAMA_MODEL", "qwen3:8b"),
            timeout=float(os.environ.get("LLM_TIMEOUT_SECONDS", "25")),
            name="ollama",
        )


class OpenRouterLLMClient(OpenAICompatibleLLMClient):
    """Free-tier routed cloud cognition through OpenRouter."""
    def __init__(self, model: str | None = None):
        key = os.environ.get("OPENROUTER_API_KEY", "")
        if not key:
            raise RuntimeError("OPENROUTER_API_KEY is not set")
        super().__init__(
            "https://openrouter.ai/api/v1",
            key,
            model or os.environ.get("OPENROUTER_MODEL", "openrouter/free"),
            timeout=float(os.environ.get("LLM_TIMEOUT_SECONDS", "30")),
            name="openrouter",
        )


class ResilientLLMClient(LLMClient):
    """Use a real free/local model when available, with safe Mock fallback."""
    def __init__(self, primary: LLMClient, fallback: LLMClient | None = None):
        self.primary = primary
        self.fallback = fallback or MockLLMClient()
        self.last_error: str | None = None
        self.provider_name = getattr(primary, "provider_name", type(primary).__name__)
        self.failed_over = False

    def reason(self, system_prompt: str, user_prompt: str) -> str:
        try:
            self.failed_over = False
            result = self.primary.reason(system_prompt, user_prompt)
            self.last_usage = getattr(self.primary, "last_usage", None)
            return result
        except Exception as exc:
            self.last_error = str(exc)
            self.failed_over = True
            result = self.fallback.reason(system_prompt, user_prompt)
            self.last_usage = getattr(self.fallback, "last_usage", None)
            return result


def _probe_ollama() -> bool:
    try:
        url = os.environ.get("OLLAMA_BASE_URL", "http://127.0.0.1:11434/v1").rstrip("/") + "/models"
        with urllib.request.urlopen(url, timeout=0.35) as r:
            return r.status == 200
    except Exception:
        return False

def create_llm_client() -> LLMClient:
    """Select Nexus cognition provider.

    Priority in ``auto`` mode:
      1. Local Ollama + Qwen3 (free, private, no rate limit).
      2. OpenRouter free router (free tier, requires a key).
      3. Anthropic if explicitly configured.
      4. Deterministic MockLLMClient.

    Set LLM_PROVIDER to ``ollama``, ``openrouter``, ``anthropic`` or ``mock``
    to force a mode. A real provider is always wrapped with a Mock fallback
    so an API outage never crashes the civilization.
    """
    provider = os.environ.get("LLM_PROVIDER", "auto").lower()
    if provider == "mock":
        return MockLLMClient()

    candidates: list[LLMClient] = []
    if provider in ("auto", "ollama"):
        if provider == "ollama" or _probe_ollama():
            try:
                candidates.append(OllamaLLMClient())
            except Exception:
                if provider == "ollama":
                    raise
    if provider in ("auto", "openrouter") and os.environ.get("OPENROUTER_API_KEY"):
        try:
            candidates.append(OpenRouterLLMClient())
        except Exception:
            if provider == "openrouter":
                raise
    if provider in ("auto", "anthropic") and os.environ.get("ANTHROPIC_API_KEY"):
        try:
            candidates.append(AnthropicLLMClient())
        except RuntimeError:
            if provider == "anthropic":
                raise

    if candidates:
        return ResilientLLMClient(candidates[0])
    return MockLLMClient()


# ---- Mock client: deterministic, personality-aware, dependency-free ----

_FIELD_RE = {
    "risk_tolerance": re.compile(r"Risk tolerance:\s*([\d.]+)"),
    "wealth": re.compile(r"Wealth:\s*([\d.]+)"),
    "debt": re.compile(r"Debt:\s*([\d.]+)"),
    "happiness": re.compile(r"Happiness:\s*([\d.]+)"),
    "status": re.compile(r"Employment status:\s*(\w+)"),
    "event_category": re.compile(r"Event category:\s*(\w+)"),
    "name": re.compile(r"You are ([\w\s]+),"),
}


def _extract(user_prompt: str) -> dict:
    out = {}
    for key, pattern in _FIELD_RE.items():
        m = pattern.search(user_prompt)
        if m:
            out[key] = m.group(1)
    return out


class MockLLMClient(LLMClient):
    """Deterministic, dependency-free stand-in that still produces
    genuinely individualized decisions — see module docstring. This is a
    stub for network access, not for behavioral depth: the branching
    below is the same signal (risk_tolerance x wealth x event) a real
    LLM would reasonably weigh, just without the flexibility of language."""

    def __init__(self, seed: int = 7):
        self.rng = random.Random(seed)

    def reason(self, system_prompt: str, user_prompt: str) -> str:
        f = _extract(user_prompt)
        name = f.get("name", "This citizen").strip()
        risk = float(f.get("risk_tolerance", 0.5))
        wealth = float(f.get("wealth", 500))
        debt = float(f.get("debt", 0))
        status = f.get("status", "unemployed")
        event = f.get("event_category", "generic")

        decision, feeling, goal, memory = self._decide(name, risk, wealth, debt, status, event)
        return json.dumps({
            "decision": decision,
            "reasoning_summary": self._explain(name, decision, risk, wealth, event),
            "goal": goal,
            "emotional_state": feeling,
            "memory_to_store": memory,
        })

    def _decide(self, name, risk, wealth, debt, status, event):
        # Job loss / bankruptcy / layoffs -> now unemployed
        if event in ("job_loss", "bankruptcy", "mass_layoffs") or status == "unemployed" and event != "generic":
            if risk > 0.65 and wealth > 3000:
                return ("START_BUSINESS", "determined",
                        "build a stable business", f"{name} decided to start a business after losing their job.")
            if risk < 0.35 or wealth < 500:
                return ("REDUCE_SPENDING", "anxious",
                        "get through this without running out of money",
                        f"{name} cut spending hard after losing their job.")
            return ("SEARCH_FOR_JOB", "worried",
                    "find new employment", f"{name} started actively job hunting.")

        if event == "marriage":
            return ("SAVE_MONEY", "optimistic", "build shared financial stability",
                    f"{name} started planning shared finances after getting married.")

        if event == "election":
            return ("CHANGE_POLITICAL_SUPPORT", "engaged", "support a party aligned with their values",
                    f"{name} reconsidered their political support after the election.")

        if event == "protest_opportunity":
            if risk > 0.6:
                return ("JOIN_PROTEST", "frustrated", "push for political change",
                        f"{name} joined a protest against the government.")
            return ("DO_NOTHING", "wary", "avoid unnecessary risk",
                    f"{name} chose to stay out of the protest.")

        if event in ("recession", "pandemic", "disaster", "housing_crash", "bank_failure"):
            if debt > 2000 and wealth < 1000:
                return ("REPAY_DEBT" if wealth > 200 else "REDUCE_SPENDING", "stressed",
                        "get debt under control", f"{name} focused on managing debt during hard times.")
            if risk > 0.7 and wealth > 4000:
                return ("START_BUSINESS", "opportunistic", "capitalize on the downturn",
                        f"{name} saw opportunity in the downturn and started a business.")
            if risk < 0.4 or wealth < 800:
                return ("REDUCE_SPENDING", "anxious", "protect savings",
                        f"{name} cut back on spending as a precaution.")
            return ("SAVE_MONEY", "cautious", "build a larger financial cushion",
                    f"{name} started saving more as a precaution.")

        # generic / routine tick
        if wealth > 5000 and risk > 0.6:
            return ("START_BUSINESS", "ambitious", "grow personal wealth",
                    f"{name} decided to start a business with their savings.")
        return ("DO_NOTHING", "content", "maintain stability",
                f"{name} continued with their established routine.")

    def _explain(self, name, decision, risk, wealth, event):
        return (f"{name} (risk tolerance {risk:.2f}, wealth {wealth:.0f}) weighed the {event} "
                f"situation against their own risk appetite and finances, and chose to {decision.replace('_',' ').lower()}.")
