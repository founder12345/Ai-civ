"""
Tier-2 cognition scheduler — Phase 5.

The full loop the architecture doc describes, now actually closed:

  WORLD EVENT -> salience (bump_salience, called from society/politics/
  events/economy) -> this module picks the top-N salient agents each tick
  -> retrieves relevant memories -> builds a STRUCTURED context (identity,
  personality, goals, needs, economic situation, relationships, relevant
  memories, current event) -> calls the LLM/mock for a JSON decision ->
  validates the decision is in actions.ACTIONS -> actions.apply_action()
  actually mutates simulation state (or rejects it, e.g. "can't afford
  that") -> a memory of the decision+consequence is stored -> future
  cognition passes for this citizen see that memory.

Cost control: a global daily budget (world.max_cognitions_per_day) and a
per-citizen cooldown (citizen.cognition_cooldown_until) bound how often
any of this runs, on top of MAX_COGNITIONS_PER_TICK already bounding
per-tick cost the way Phase 2 did.
"""

from __future__ import annotations
import json
import random
from .models import Citizen, WorldState, Company
from . import memory as memory_store
from . import actions as actions_module
from .llm import LLMClient

MAX_COGNITIONS_PER_TICK = 3       # per-tick cap, unchanged from Phase 2
COOLDOWN_TICKS = 24               # ~1 simulated day before a citizen can be re-selected

RESPONSE_SCHEMA_DESCRIPTION = (
    "Respond with ONLY a single JSON object, no other text, matching exactly:\n"
    '{"decision": "<ONE_OF: ' + ", ".join(sorted(actions_module.ACTIONS)) + '>", '
    '"reasoning_summary": "<1-2 sentences, first-person-informed, concrete>", '
    '"goal": "<short persistent goal string, or null>", '
    '"emotional_state": "<one or two words>", '
    '"memory_to_store": "<short third-person sentence describing what happened, for this citizen\'s own memory>"}'
)


def bump_salience(citizen: Citizen, amount: float, reason: str, world: WorldState,
                   event_category: str = "generic") -> None:
    citizen.salience_score = min(1.0, citizen.salience_score + amount)
    citizen._pending_event_category = event_category  # transient, not persisted — read once by _build_prompt
    memory_store.add_memory(citizen, world.tick, reason, importance=min(1.0, amount), kind="event")


def _reset_daily_budget(world: WorldState) -> None:
    day = world.tick // 24
    if day != world.llm_calls_day_marker:
        world.llm_calls_day_marker = day
        world.llm_calls_today = 0


def _build_context(citizen: Citizen, citizens: dict[int, Citizen], companies: dict[int, Company],
                    world: WorldState, trigger_reason: str, event_category: str) -> tuple[str, str]:
    relevant = memory_store.retrieve(citizen, query=trigger_reason, current_tick=world.tick, k=6)
    memory_lines = "\n".join(f"- (t={m.tick}) {m.text}" for m in relevant) or "- No significant memories yet."
    recent_events = [m.text for m in citizen.memories[-3:]] or ["Nothing notable recently."]

    employer = companies.get(citizen.employer_id) if citizen.employer_id else None
    spouse = citizens.get(citizen.spouse_id) if citizen.spouse_id else None
    coworkers = sum(1 for c in citizens.values() if c.employer_id == citizen.employer_id and c.id != citizen.id) \
        if citizen.employer_id else 0

    system_prompt = (
        "You are simulating one citizen's internal decision-making inside an economic/social "
        "simulation. You will be given ONLY the information relevant to this decision — identity, "
        "personality, goals, current needs, economic situation, relationships, relevant memories, "
        "and the triggering event. Weigh personality (especially risk tolerance) and financial "
        "reality heavily: two citizens facing the same event with different risk tolerance and "
        "savings should often choose differently. " + RESPONSE_SCHEMA_DESCRIPTION
    )
    user_prompt = (
        f"You are {citizen.name}, age {citizen.age}.\n\n"
        f"IDENTITY\nSkill level: {citizen.skill_level:.2f}\nEducation level: {citizen.education_level:.2f}\n"
        f"Political ideology: {citizen.political_ideology:+.2f} (-1 left to +1 right)\n\n"
        f"PERSONALITY\nRisk tolerance: {citizen.risk_tolerance:.2f}\nSpending propensity: {citizen.consumption_propensity:.2f}\n\n"
        f"NEEDS\nHappiness: {citizen.happiness:.2f}\n\n"
        f"ECONOMIC SITUATION\nWealth: {citizen.wealth:.2f}\nDebt: {citizen.debt:.2f}\n"
        f"Income last tick: {citizen.income:.2f}\nEmployment status: {citizen.status.value}\n"
        f"Employer: {employer.name if employer else 'none'}\nOwns home: {citizen.owns_home}\n\n"
        f"GOALS\n{citizen.goals or ['none set yet']}\n\n"
        f"RELATIONSHIPS\nSpouse: {spouse.name if spouse else 'none'}\nCoworkers: {coworkers}\n\n"
        f"RELEVANT MEMORIES\n{memory_lines}\n\n"
        f"RECENT EVENTS\n" + "\n".join(f"- {e}" for e in recent_events) + "\n\n"
        f"TRIGGERING EVENT\n{trigger_reason}\n"
        f"Event category: {event_category}\n\n"
        f"What do you decide to do? Respond with the JSON object described above, nothing else."
    )
    return system_prompt, user_prompt


def _parse_decision(raw_text: str) -> dict | None:
    text = raw_text.strip()
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None
    try:
        obj = json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict) or "decision" not in obj:
        return None
    return obj


def _track_cost(llm: LLMClient, world: WorldState) -> None:
    world.llm_calls_total += 1
    world.llm_calls_today += 1
    world.tier2_decisions_total += 1
    usage = getattr(llm, "last_usage", None)
    if usage:
        inp, out = usage.get("input_tokens", 0), usage.get("output_tokens", 0)
        world.llm_input_tokens_total += inp
        world.llm_output_tokens_total += out
        world.llm_estimated_cost_usd += inp / 1_000_000 * 3.0 + out / 1_000_000 * 15.0


def run_cognition_pass(citizens: dict, companies: dict, world: WorldState,
                        llm: LLMClient, layout=None, rng: random.Random | None = None,
                        parties: dict | None = None) -> None:
    _reset_daily_budget(world)
    if world.llm_calls_today >= world.max_cognitions_per_day:
        return

    candidates = [
        c for c in citizens.values()
        if c.alive and c.salience_score > 0.15 and world.tick >= c.cognition_cooldown_until
    ]
    candidates.sort(key=lambda c: c.salience_score, reverse=True)
    remaining_budget = world.max_cognitions_per_day - world.llm_calls_today
    chosen = candidates[:max(0, min(MAX_COGNITIONS_PER_TICK, remaining_budget))]

    ctx = actions_module.ActionContext(citizens=citizens, companies=companies, world=world,
                                        layout=layout, rng=rng or random.Random(world.tick), parties=parties)

    for citizen in chosen:
        recent_trigger = citizen.memories[-1].text if citizen.memories else "A routine moment of reflection."
        event_category = getattr(citizen, "_pending_event_category", "generic")
        system_prompt, user_prompt = _build_context(citizen, citizens, companies, world, recent_trigger, event_category)

        raw = llm.reason(system_prompt, user_prompt)
        _track_cost(llm, world)
        decision_obj = _parse_decision(raw)

        if decision_obj is None:
            corrective = user_prompt + "\n\nYour previous response was not valid JSON. Respond with ONLY the JSON object, nothing else."
            raw = llm.reason(system_prompt, corrective)
            _track_cost(llm, world)
            decision_obj = _parse_decision(raw)

        if decision_obj is None:
            action = "DO_NOTHING"
            reasoning = raw[:300] if raw else "(no parseable response)"
            emotional_state, goal, mem_text = "", None, None
        else:
            action = decision_obj.get("decision", "DO_NOTHING")
            if action not in actions_module.ACTIONS:
                action = "DO_NOTHING"
            reasoning = str(decision_obj.get("reasoning_summary", ""))[:400]
            emotional_state = str(decision_obj.get("emotional_state", ""))[:40]
            goal = decision_obj.get("goal")
            mem_text = decision_obj.get("memory_to_store")

        result = actions_module.apply_action(citizen, action, ctx)

        citizen.current_reasoning = reasoning
        citizen.emotional_state = emotional_state
        citizen.last_cognition_tick = world.tick
        citizen.cognition_cooldown_until = world.tick + COOLDOWN_TICKS

        if goal and isinstance(goal, str) and goal not in citizen.goals:
            citizen.goals.append(goal)
            if len(citizen.goals) > 5:
                citizen.goals.pop(0)

        if mem_text and isinstance(mem_text, str):
            memory_store.add_memory(citizen, world.tick, mem_text[:200], importance=0.5, kind="reflection")
        memory_store.add_memory(citizen, world.tick, f"Decided to {action}: {result}", importance=0.4, kind="decision")

        citizen.salience_score = 0.0
        if hasattr(citizen, "_pending_event_category"):
            delattr(citizen, "_pending_event_category")
        world.log(f"COGNITION: {citizen.name} -> {action} ({result})")
