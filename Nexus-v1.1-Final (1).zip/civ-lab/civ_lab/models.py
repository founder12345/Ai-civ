"""
Core data models for the AI Civilization Laboratory — Phase 1.

Phase 1 deliberately uses plain dataclasses held in memory rather than
Postgres. The simulation engine only cares about a state interface
(read fields, mutate fields, iterate collections) — swapping this
module's storage for SQLAlchemy + Postgres in Phase 2 (when persistent
memory and multi-process scale actually matter) does not require
touching economy.py or simulation.py. Keep that boundary clean.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class EmploymentStatus(str, Enum):
    EMPLOYED = "employed"
    UNEMPLOYED = "unemployed"
    RETIRED = "retired"


class MaritalStatus(str, Enum):
    SINGLE = "single"
    MARRIED = "married"
    WIDOWED = "widowed"


@dataclass
class MemoryEntry:
    """One episodic memory. Phase 2 uses a lightweight in-process bag-of-words
    store instead of a real vector DB (no network access here to run an
    embedding model or a hosted vector store) — see memory.py for the
    swap-in seam to pgvector/Chroma + real embeddings later."""
    tick: int
    text: str
    importance: float   # 0.0-1.0, set by whatever created the memory
    kind: str = "event"  # "event" | "reflection" | "conversation"


@dataclass
class Citizen:
    id: int
    name: str
    age: int
    skill_level: float          # 0.0-1.0, affects wage and hiring odds
    wealth: float = 0.0
    income: float = 0.0         # last-tick income, for dashboards
    employer_id: Optional[int] = None
    status: EmploymentStatus = EmploymentStatus.UNEMPLOYED
    happiness: float = 0.6      # 0.0-1.0
    consumption_propensity: float = 0.7  # fraction of wealth spent per tick
    ticks_unemployed: int = 0
    alive: bool = True

    education_level: float = 0.5
    political_ideology: float = 0.0   # -1.0 (left) to 1.0 (right)
    party_id: Optional[int] = None

    marital_status: MaritalStatus = MaritalStatus.SINGLE
    spouse_id: Optional[int] = None
    household_id: Optional[int] = None

    # --- Tier-2 cognition state (Phase 2) ---
    salience_score: float = 0.0        # accumulates from notable events; drives cognition priority
    last_cognition_tick: int = -999
    current_reasoning: str = ""        # most recent LLM (or mock) reasoning trace, shown in inspector
    goals: list[str] = field(default_factory=list)
    predicted_actions: list[str] = field(default_factory=list)
    # Advanced life/economic state
    bank_balance: float = 0.0
    credit_score: float = 650.0
    loan_balance: float = 0.0
    loan_rate: float = 0.06
    housing_value: float = 0.0
    rent: float = 0.0
    savings_rate: float = 0.15
    career_level: int = 0
    parent_ids: list[int] = field(default_factory=list)
    child_ids: list[int] = field(default_factory=list)
    relationship_ids: list[int] = field(default_factory=list)
    trust_score: float = 0.5
    reputation: float = 0.5
    social_activity: float = 0.5
    memories: list[MemoryEntry] = field(default_factory=list)

    # --- City / movement state (Phase 2 visual layer) — additive, all
    # default to 0/empty so nothing existing (economy/society/politics/
    # cognition) that constructs a Citizen without these breaks. ---
    home_x: int = 0
    home_y: int = 0
    work_x: Optional[int] = None
    work_y: Optional[int] = None
    grid_x: int = 0            # current position on the city grid
    grid_y: int = 0
    activity: str = "idle"     # "sleeping" | "commuting" | "working" | "social" | "idle"
    current_thought: str = ""  # state-derived thought bubble text (not LLM — see city.py)

    # --- Tier-2 agent cognition (Phase 5) — additive personality/state used
    # by cognition.py + actions.py. Defaults preserve every earlier phase. ---
    risk_tolerance: float = 0.5     # 0-1, set once at creation (seed.py); drives action choice divergence
    debt: float = 0.0
    owns_home: bool = False
    emotional_state: str = ""       # LLM/mock-reported feeling, shown separately from reasoning text
    last_action: str = ""           # most recent validated action (from actions.ACTIONS)
    last_action_result: str = ""    # what actually happened when the simulation applied it
    cognition_cooldown_until: int = -1  # tick before which this citizen won't be re-selected for Tier-2


@dataclass
class Company:
    id: int
    name: str
    sector: str
    cash: float
    price_level: float = 10.0     # price per unit of output
    target_headcount: int = 5
    employee_ids: list[int] = field(default_factory=list)
    wage_budget_per_head: float = 40.0
    revenue_last_tick: float = 0.0
    output_last_tick: float = 0.0  # gross economic output generated this tick, retained for GDP accounting
    profit_last_tick: float = 0.0
    is_bankrupt: bool = False

    # --- City / movement state (Phase 2 visual layer) — additive ---
    loc_x: int = 0
    loc_y: int = 0
    building_type: str = "office"  # "office" | "shop" | "factory" | "hospital"
    founder_id: Optional[int] = None  # set when created via the START_BUSINESS action (Phase 5)
    stock_price: float = 10.0
    shares_outstanding: float = 1000.0
    debt: float = 0.0
    productivity: float = 1.0
    inventory: float = 100.0
    technology_level: float = 1.0

    @property
    def headcount(self) -> int:
        return len(self.employee_ids)


@dataclass
class Party:
    id: int
    name: str
    ideology_center: float  # -1.0 (left) to 1.0 (right)
    approval: float = 0.5
    in_power: bool = False


@dataclass
class WorldState:
    tick: int = 0
    interest_rate: float = 0.03
    tax_rate: float = 0.20
    inflation: float = 0.0
    money_supply: float = 1_000_000.0
    government_budget: float = 50_000.0

    # Society/politics knobs
    healthcare_funding_level: float = 0.5   # 0-1, affects death/illness rate
    education_funding_level: float = 0.5    # 0-1, affects education_level drift
    election_interval: int = 200            # ticks between elections
    active_event_effects: dict = field(default_factory=dict)  # name -> {field: multiplier, expires_tick: int}

    # Aggregates recomputed each tick
    gdp: float = 0.0
    unemployment_rate: float = 0.0
    avg_happiness: float = 0.0
    avg_wealth: float = 0.0
    gini_estimate: float = 0.0
    crime_rate: float = 0.0
    population: int = 0
    births_total: int = 0
    deaths_total: int = 0
    marriages_total: int = 0
    ruling_party_id: Optional[int] = None
    government_approval: float = 0.5

    event_log: list[str] = field(default_factory=list)

    # --- Tier-2 cost control / observability (Phase 5) — additive ---
    llm_calls_total: int = 0
    llm_calls_today: int = 0
    llm_calls_day_marker: int = 0          # which day (tick // 24) llm_calls_today is counting
    max_cognitions_per_day: int = 200      # global daily budget across all citizens
    llm_input_tokens_total: int = 0
    llm_output_tokens_total: int = 0
    llm_estimated_cost_usd: float = 0.0
    tier2_decisions_total: int = 0         # decisions actually validated + applied (subset of llm_calls)

    # Advanced civilization systems
    central_bank_rate: float = 0.03
    money_growth_rate: float = 0.02
    housing_price_index: float = 100.0
    stock_market_index: float = 100.0
    poverty_rate: float = 0.0
    polarization: float = 0.0
    social_cohesion: float = 0.6
    productivity_index: float = 100.0
    trade_balance: float = 0.0
    exchange_rate: float = 1.0
    energy_price: float = 1.0
    government_debt: float = 0.0
    welfare_spending: float = 0.0
    infrastructure: float = 0.5
    environmental_quality: float = 0.7
    emissions: float = 0.0
    technology_progress: float = 0.0
    social_movements: list[dict] = field(default_factory=list)
    policy_history: list[dict] = field(default_factory=list)
    macro_history: list[dict] = field(default_factory=list)
    relationships: dict = field(default_factory=dict)
    households: dict = field(default_factory=dict)
    portfolios: dict = field(default_factory=dict)
    loans: dict = field(default_factory=dict)
    replay_history: list[dict] = field(default_factory=list)
    experiment_results: list[dict] = field(default_factory=list)

    def log(self, message: str) -> None:
        self.event_log.append(f"[t={self.tick}] {message}")
        # keep the log bounded — this is a rolling recent-events feed,
        # not the historical record (that will be the DB in Phase 2)
        if len(self.event_log) > 500:
            self.event_log = self.event_log[-500:]
