"""
Tier 0/1 economic simulation — pure deterministic math, no LLM calls.

This module is intentionally simple in Phase 1: the goal is a STABLE,
explainable economic loop (wages -> spending -> revenue -> profit ->
hiring/firing -> unemployment -> repeat) that doesn't explode or
flatline over hundreds of ticks. Realism gets layered on in later
phases (supply chains, stock market, housing) once this core loop is
proven solid — that ordering is deliberate, not a shortcut.
"""

from __future__ import annotations
import random
from .models import Citizen, Company, WorldState, EmploymentStatus
from . import events
from . import cognition


def _revenue_share_weights(companies: list[Company]) -> list[float]:
    """Market-share weight per company: capacity (headcount) x price
    competitiveness. Shared by consumer_spending and government_purchases
    so the two revenue-injection paths can never drift out of sync with
    each other — see the comment at the consumer_spending call site for
    why headcount has to be part of this, not just price."""
    return [max(c.headcount, 1) / max(c.price_level, 1.0) for c in companies]


def pay_wages(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState) -> None:
    """Each employed citizen receives a wage from their employer."""
    for company in companies.values():
        if company.is_bankrupt:
            continue
        for cid in company.employee_ids:
            citizen = citizens[cid]
            if not citizen.alive:
                continue
            wage = company.wage_budget_per_head * (0.7 + 0.6 * citizen.skill_level)
            wage *= (1 - world.tax_rate)
            citizen.income = wage
            citizen.wealth += wage
            company.cash -= wage / (1 - world.tax_rate)  # gross cost to company
            world.government_budget += wage / (1 - world.tax_rate) * world.tax_rate


def pay_unemployment_support(citizens: dict[int, Citizen], world: WorldState) -> None:
    """Minimal welfare so unemployed citizens don't spiral to zero instantly.

    This is deliberately deficit-financed up to a bound, not capped at
    whatever's currently in government_budget. An unemployment safety net
    that gets cut exactly when the budget is depleted is procyclical — it
    makes recessions worse right when they're worst, which is the
    opposite of what unemployment insurance is for in a real economy.
    Real automatic stabilizers run a deficit during downturns and get
    recouped through tax revenue once employment recovers. The deficit
    is bounded (not unlimited money printing) so this stays a stabilizer,
    not a way to make scarcity disappear.
    """
    support = 8.0
    deficit_ceiling = -30_000.0  # how far into deficit the safety net is allowed to go
    for citizen in citizens.values():
        if citizen.alive and citizen.status == EmploymentStatus.UNEMPLOYED:
            if world.government_budget <= deficit_ceiling:
                payout = 0.0  # only once even deficit spending is exhausted
            else:
                payout = support
            citizen.wealth += payout
            citizen.income = payout
            world.government_budget -= payout
            citizen.ticks_unemployed += 1


def consumer_spending(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState) -> None:
    """Citizens spend a fraction of wealth; revenue is split across companies
    weighted by (inverse) price level, i.e. cheaper companies win more demand."""
    if not companies:
        return
    active = [c for c in companies.values() if not c.is_bankrupt]
    if not active:
        return
    # Revenue share must scale with a company's actual capacity (headcount),
    # not just its price — otherwise a 9-employee company and a 3-employee
    # company at the same price get an EQUAL revenue split despite one
    # having 3x the wage bill to cover. Verified against the seeded
    # default: two 9-employee companies had among the LOWEST revenue
    # weights of all 8 companies purely because of unlucky price draws,
    # guaranteeing they'd bleed cash and bankrupt regardless of the
    # aggregate wage/spending balance — this was the dominant driver of
    # the collapse, well beyond the tax-recycling gap.
    weights = _revenue_share_weights(active)
    total_weight = sum(weights)

    # World events (Phase 5) dampen demand while active — pandemics and
    # recessions both suppress consumer spending, at different intensities.
    demand_multiplier = 1.0
    demand_multiplier -= 0.35 * events.pandemic_active_severity(world)
    demand_multiplier -= 0.25 * events.recession_active_severity(world)
    demand_multiplier = max(0.2, demand_multiplier)

    for citizen in citizens.values():
        if not citizen.alive:
            continue
        # Spend mainly out of income (this tick's actual earnings), with a
        # much smaller drawdown from savings — not 15% of the whole wealth
        # stock every tick. The previous wealth-based formula made an
        # average citizen spend ~3x their income every tick purely
        # mechanically (verified: ~115/tick spend vs ~38/tick wage at
        # seed.py's default ranges), which guaranteed wealth erosion and a
        # company-cash crisis from tick 1 regardless of any bankruptcy
        # dynamics — not an emergent outcome, a calibration bug.
        spend = (citizen.income * citizen.consumption_propensity
                 + citizen.wealth * 0.02 * citizen.consumption_propensity) * demand_multiplier
        if spend <= 0:
            continue
        citizen.wealth -= spend
        for company, w in zip(active, weights):
            share = spend * (w / total_weight)
            company.cash += share
            company.revenue_last_tick += share


def government_purchases(companies: dict[int, Company], world: WorldState) -> None:
    """Recycle part of the fiscal flow back into productive demand.

    Taxes are collected from the same wage loop that funds businesses. Holding
    almost all of that money in a government account creates an artificial
    liquidity leak, so Nexus now automatically recycles a bounded share each
    tick. During recessions the existing unemployment stabilizer can still run
    deficits, but this function never creates an unbounded transfer.
    """
    active = [c for c in companies.values() if not c.is_bankrupt]
    if not active or world.government_budget <= 0:
        return
    target_buffer = 20_000.0
    surplus = max(0.0, world.government_budget - target_buffer)
    # Recycle a small share of the accumulated buffer plus a larger share of
    # current fiscal capacity. This keeps money circulating without making
    # government spending dominate GDP.
    spend = min(world.government_budget, 0.02 * surplus + 0.45 * min(world.government_budget, 2000.0))
    if spend <= 0:
        return
    weights = _revenue_share_weights(active)
    total_weight = sum(weights) or 1.0
    for company, w in zip(active, weights):
        share = spend * (w / total_weight)
        company.cash += share
        company.revenue_last_tick += share
    world.government_budget -= spend


def company_decisions(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState,
                       rng: random.Random, layout=None) -> None:
    """Companies compute profit, then hire or fire based on cash health.
    This is the Tier-1 'reflex' layer — deterministic thresholds, no LLM.
    In Phase 2, a company nearing bankruptcy or a major expansion decision
    is exactly the kind of event that should raise agent salience and
    trigger a real LLM reasoning pass instead of this rule."""
    unemployed_ids = [c.id for c in citizens.values() if c.alive and c.status == EmploymentStatus.UNEMPLOYED]
    rng.shuffle(unemployed_ids)

    for company in companies.values():
        if company.is_bankrupt:
            continue

        wage_cost_estimate = sum(company.wage_budget_per_head * (0.7 + 0.6 * citizens[cid].skill_level)
                                  for cid in company.employee_ids if citizens[cid].alive)
        # Preserve gross sales before resetting the per-tick revenue accumulator.
        # GDP must measure actual production/sales this period, not a structural
        # proxy such as the wage budget. Keeping this value also lets analytics
        # and the stock market react to real demand shocks.
        company.output_last_tick = max(0.0, company.revenue_last_tick)
        company.profit_last_tick = company.output_last_tick - wage_cost_estimate
        company.revenue_last_tick = 0.0  # reset for next tick's accumulation

        # Bankruptcy: sustained negative cash
        if company.cash < -500:
            company.is_bankrupt = True
            world.log(f"{company.name} went bankrupt — {company.headcount} employees laid off.")
            for cid in company.employee_ids:
                citizens[cid].status = EmploymentStatus.UNEMPLOYED
                citizens[cid].employer_id = None
                cognition.bump_salience(citizens[cid], 0.55, f"{company.name} went bankrupt and they lost their job.", world, "bankruptcy")
            company.employee_ids = []
            # Free the physical lot back into the city's inventory — a
            # bankrupt storefront becomes available for a new venture to
            # move into. Without this, zone_lots permanently empties out
            # during initial city generation and NO new company can ever
            # be placed anywhere again, regardless of any citizen's wealth
            # or risk tolerance — verified directly this was a hard,
            # total block on business formation independent of economic
            # conditions.
            if layout is not None:
                from . import city as city_module
                zone = city_module._classify_zone(company.loc_x, company.loc_y, layout.width, layout.height, layout.river_x)
                layout.zone_lots.setdefault(zone, []).append((company.loc_x, company.loc_y))
            continue

        # Hiring: healthy cash + below target headcount
        if company.cash > 300 and company.headcount < company.target_headcount and unemployed_ids:
            hire_id = unemployed_ids.pop()
            citizen = citizens[hire_id]
            citizen.status = EmploymentStatus.EMPLOYED
            citizen.employer_id = company.id
            citizen.ticks_unemployed = 0
            company.employee_ids.append(hire_id)
            world.log(f"{company.name} hired {citizen.name}.")

        # Layoff: cash trouble but not yet bankrupt
        elif company.cash < 0 and company.headcount > 1:
            fire_id = company.employee_ids.pop()
            citizens[fire_id].status = EmploymentStatus.UNEMPLOYED
            citizens[fire_id].employer_id = None
            cognition.bump_salience(citizens[fire_id], 0.45, f"Lost their job at {company.name} due to cost cutting.", world, "job_loss")
            world.log(f"{company.name} laid off {citizens[fire_id].name} (cost cutting).")

        # Price adjustment: scaled to the company's OWN wage bill, not a
        # fixed absolute profit number — a fixed threshold (previously
        # "profit > 200") never triggers for a 3-employee company whose
        # typical profit is order ±50-90, so small profitable companies
        # could never raise prices while unprofitable ones kept
        # discounting: a one-way ratchet where whichever company started
        # cheapest just kept winning more market share forever (verified:
        # one company's cash grew from ~3,000 to ~30,000 over 300 ticks
        # purely from this, while equal-size competitors bled out).
        # Margin-based thresholds scale naturally with company size.
        wage_bill = max(1.0, wage_cost_estimate)
        margin = company.profit_last_tick / wage_bill
        if margin > 0.15:
            company.price_level *= 1.01  # demand strong relative to size, nudge price up
        elif margin < -0.10:
            company.price_level *= 0.99  # struggling relative to size, discount
        company.price_level = max(1.0, company.price_level)


def update_happiness(citizens: dict[int, Citizen]) -> None:
    for citizen in citizens.values():
        if not citizen.alive:
            continue
        target = 0.5
        if citizen.status == EmploymentStatus.EMPLOYED:
            target += 0.25
        else:
            target -= 0.05 * min(citizen.ticks_unemployed, 6)
        target += min(citizen.wealth / 5000.0, 0.15)
        # happiness eases toward target rather than jumping — avoids noisy swings
        citizen.happiness += (target - citizen.happiness) * 0.2
        citizen.happiness = max(0.0, min(1.0, citizen.happiness))


def compute_aggregates(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState) -> None:
    alive = [c for c in citizens.values() if c.alive]
    n = len(alive)
    if n == 0:
        return
    unemployed = sum(1 for c in alive if c.status == EmploymentStatus.UNEMPLOYED)
    world.unemployment_rate = unemployed / n
    world.avg_happiness = sum(c.happiness for c in alive) / n
    world.avg_wealth = sum(c.wealth for c in alive) / n

    wealths = sorted(c.wealth for c in alive)
    total = sum(wealths) or 1.0
    cum = 0.0
    gini_area = 0.0
    for i, w in enumerate(wealths, start=1):
        cum += w
        gini_area += cum / total
    world.gini_estimate = max(0.0, 1.0 - 2 * gini_area / n + 1 / n)

    # GDP is modeled as realized gross final output/sales. Revenue is generated
    # by household consumption + government purchases earlier in the tick and
    # retained as output_last_tick before the accumulator is reset. A small
    # productivity component captures unsold productive output without letting
    # inventory create unlimited GDP. This makes demand shocks, unemployment,
    # company failures and productivity visibly propagate into GDP.
    sales = sum(co.output_last_tick for co in companies.values() if not co.is_bankrupt)
    productivity_output = sum(
        max(0.0, co.headcount * co.wage_budget_per_head * 0.10 * (co.productivity - 1.0))
        for co in companies.values() if not co.is_bankrupt
    )
    world.gdp = max(0.0, sales + productivity_output)


def apply_inflation_drift(world: WorldState, rng: random.Random) -> None:
    """Money supply growth and interest rate feed a small inflation drift.
    Deliberately simple (no full quantity-theory model) — good enough to
    make sandbox interest-rate changes visibly matter, which is the point
    of Phase 1's 'prove the sandbox propagates' requirement."""
    drift = (world.money_supply / 1_000_000.0 - 1.0) * 0.01
    drift += (0.03 - world.interest_rate) * 0.02  # low rates -> inflationary pressure
    drift += rng.uniform(-0.002, 0.002)
    world.inflation = max(-0.05, min(0.20, world.inflation * 0.9 + drift))


def business_formation(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState,
                        layout, rng: random.Random) -> None:
    """Tier-0/1 endogenous business formation — no LLM required.

    Diagnosed root cause (see HANDOFF.md): total company capacity only
    ever shrinks via bankruptcy, with nothing to replace it, so ANY
    long-run economy eventually decays to zero active companies
    regardless of how well the wage/spending flow is balanced. Verified
    directly: population stayed flat (33-36) over a 26,000-tick run while
    active companies shrank 8 -> 0 in lockstep with unreplaced
    bankruptcies. This isn't about population outgrowing capacity — it's
    capacity draining to nothing with no replacement mechanism at all.

    This reuses the exact same validated START_BUSINESS action Tier-2
    cognition already uses (via actions.apply_action) — same startup
    cost, same failure conditions, same company mechanics. Only the
    trigger is new: an eligible citizen has a small per-tick chance to
    found a business without needing an LLM/cognition pass, so the base
    economy stays viable even with cognition entirely disabled. Genuine
    risk is preserved — new companies aren't guaranteed to survive, they
    go through the exact same bankruptcy logic as any other company.

    Eligibility is wealth + risk tolerance, deliberately NOT restricted
    to unemployed citizens — verified directly that restricting to
    unemployed-only left zero eligible candidates at the exact point the
    opportunity signal correctly fired (the unemployed citizens with
    enough savings happened to have low risk tolerance, and the
    risk-tolerant ones had depleted savings). Real entrepreneurs are
    often employed people who leave a job to start something; the
    existing action already handles a citizen leaving their current
    employer to found a new company.
    """
    if layout is None:
        return
    active = [c for c in companies.values() if not c.is_bankrupt]
    population = sum(1 for c in citizens.values() if c.alive)
    if population == 0:
        return
    capacity_ratio = sum(c.target_headcount for c in active) / population
    if capacity_ratio >= 0.75:
        return  # enough jobs already exist relative to population — no unmet opportunity

    # Scarcer capacity -> stronger opportunity signal -> higher (but still
    # bounded, still probabilistic) chance any single eligible citizen acts on it.
    opportunity = (0.75 - capacity_ratio) / 0.75  # 0..1
    chance_per_tick = 0.02 * opportunity

    # Personality gate only — NOT also a wealth gate here. The actual
    # affordability check ($2000 startup cost) already happens inside
    # apply_action itself (same validated START_BUSINESS logic Tier-2
    # cognition uses), so duplicating it here would be redundant. It's
    # also economically necessary NOT to require wealth>=2000 up front:
    # verified directly that in this economy, high-wealth and
    # high-risk-tolerance are nearly mutually exclusive in practice
    # (cautious citizens save more through their own Tier-2 decisions;
    # risk-tolerant ones spend/venture more) — requiring both
    # simultaneously left zero eligible candidates for the entire second
    # half of a 26,000-tick run. Citizens who roll the dice without
    # enough capital just get validly rejected by apply_action, the same
    # as any other unaffordable action.
    #
    # Cooldown after ANY attempt (success or failure) — verified directly
    # that without one, a single citizen whose venture fails immediately
    # would re-attempt again next tick, repeatedly burning the $2000
    # startup cost on doomed ventures (one citizen created and lost 4
    # businesses within a few hundred ticks). Reuses the same
    # cognition_cooldown_until field cognition.py already has, since this
    # is conceptually the same thing: "don't re-evaluate this citizen for
    # a major decision again immediately."
    candidates = [c for c in citizens.values() if c.alive and c.risk_tolerance > 0.6
                  and world.tick >= c.cognition_cooldown_until]
    if not candidates:
        return

    # Import here (not at module top) to avoid a needless import for every
    # caller that never hits this branch, and because actions.py already
    # imports economy indirectly via cognition — keeping this import local
    # sidesteps having to reason about module-load order at all.
    from . import actions as actions_module
    ctx = actions_module.ActionContext(citizens=citizens, companies=companies, world=world, layout=layout, rng=rng)
    for citizen in candidates:
        if rng.random() < chance_per_tick:
            actions_module.apply_action(citizen, "START_BUSINESS", ctx)
            citizen.cognition_cooldown_until = world.tick + 24 * 30  # ~1 month before trying again


def tick(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState, rng: random.Random,
         layout=None) -> None:
    """Run one tick of economic logic. Does NOT advance world.tick itself —
    simulation.Simulation.step() owns the master tick counter and calls
    economy.tick / society.tick / politics.tick / cognition in a fixed
    order (see simulation.py) so world.tick is consistent across all
    subsystems within a single step. Order matters here too: wages must
    be paid before spending, spending before company profit, profit
    before hire/fire decisions."""
    events.apply_active_effects(world)
    pay_wages(citizens, companies, world)
    pay_unemployment_support(citizens, world)
    consumer_spending(citizens, companies, world)
    government_purchases(companies, world)
    company_decisions(citizens, companies, world, rng, layout=layout)
    business_formation(citizens, companies, world, layout, rng)
    update_happiness(citizens)
    apply_inflation_drift(world, rng)
    compute_aggregates(citizens, companies, world)
