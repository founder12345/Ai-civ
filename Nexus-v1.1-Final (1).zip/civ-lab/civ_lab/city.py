"""
City module — Phase 2 visual layer. Purely additive: generates a static
tile grid + building placements once at seed time, then each tick moves
citizens toward wherever their schedule says they should be and updates
a short state-derived "current thought" string.

This does NOT touch economy.py/society.py/politics.py/cognition.py.
simulation.py calls city.tick() as one more step in the per-tick order,
same pattern as the other subsystems.

Clock note: society.py's aging uses a slower "1 tick ≈ fraction of a
year" clock (TICKS_PER_YEAR). City movement uses its own faster
"1 tick ≈ 1 hour of a day" clock (HOUR_TICK = world.tick % 24). Both
run off the same world.tick counter but represent different time
scales — a known simplification, not a bug: real calendar reconciliation
(a tick can't simultaneously be both an hour and 1/20th of a year) is
a Phase 3+ concern if this project's clock model gets unified.
"""

from __future__ import annotations
import random
from dataclasses import dataclass, field
from .models import Citizen, Company, WorldState, EmploymentStatus

HOURS_PER_DAY = 24
BLOCK_SIZE = 6  # roads every BLOCK_SIZE tiles -> 5x5 interior per block, 3x3 of which is buildable
                # (the outer ring of each interior touches a road and becomes sidewalk instead)

TILE_GRASS = "grass"
TILE_ROAD = "road"
TILE_SIDEWALK = "sidewalk"
TILE_WATER = "water"
TILE_PARK = "park"
TILE_PLAZA = "plaza"
TILE_BRIDGE = "bridge"
TILE_HOUSE = "house"
TILE_SHOP = "shop"
TILE_OFFICE = "office"
TILE_FACTORY = "factory"
TILE_HOSPITAL = "hospital"
TILE_SCHOOL = "school"
TILE_BANK = "bank"
TILE_GOVERNMENT = "government"

ROAD_LIKE = {TILE_ROAD, TILE_BRIDGE}

SECTOR_TO_BUILDING = {
    "Tech": TILE_OFFICE,
    "Construction": TILE_FACTORY,
    "Food": TILE_SHOP,
    "Retail": TILE_SHOP,
    "Healthcare": TILE_HOSPITAL,
}

# ---- Phase 4: neighborhood zoning -----------------------------------------
# Purely a placement bias — decides WHICH lot a building/company/house ends
# up on, using the same tiles/economy/citizen data as before. Nothing about
# the simulation's numbers changes; a company in "downtown" still runs the
# exact same economy.py logic as one anywhere else.
ZONE_CIVIC = "civic_core"
ZONE_DOWNTOWN = "downtown"
ZONE_INDUSTRIAL = "industrial"
ZONE_WATERFRONT = "waterfront"
ZONE_RESIDENTIAL = "residential"
ALL_ZONES = (ZONE_CIVIC, ZONE_DOWNTOWN, ZONE_INDUSTRIAL, ZONE_WATERFRONT, ZONE_RESIDENTIAL)

SECTOR_ZONE_PREFERENCE = {
    "Tech": (ZONE_DOWNTOWN, ZONE_CIVIC),
    "Healthcare": (ZONE_CIVIC, ZONE_DOWNTOWN),
    "Construction": (ZONE_INDUSTRIAL, ZONE_RESIDENTIAL),
    "Food": (ZONE_DOWNTOWN, ZONE_RESIDENTIAL),
    "Retail": (ZONE_DOWNTOWN, ZONE_RESIDENTIAL),
}


def _classify_zone(x: int, y: int, width: int, height: int, river_x: int) -> str:
    cx, cy = width / 2, height / 2
    dist_center = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
    max_dist = ((width / 2) ** 2 + (height / 2) ** 2) ** 0.5 or 1.0
    norm = dist_center / max_dist
    if abs(x - river_x) <= 2 and norm > 0.25:
        return ZONE_WATERFRONT
    if norm < 0.22:
        return ZONE_CIVIC
    if norm < 0.42:
        return ZONE_DOWNTOWN
    if x < width * 0.35 and y > height * 0.65:
        return ZONE_INDUSTRIAL
    return ZONE_RESIDENTIAL


@dataclass
class CityLayout:
    width: int
    height: int
    tiles: list[list[str]]                  # [y][x] -> tile type
    house_lots: list[tuple[int, int]] = field(default_factory=list)
    civic_buildings: list[dict] = field(default_factory=list)  # {x,y,type,name}
    available_lots: list[tuple[int, int]] = field(default_factory=list)  # deprecated post-bucketing, kept for shape
    zone_lots: dict = field(default_factory=dict)  # zone name -> list[(x,y)], consumed by _take_lot
    river_x: int = -1

    def _take_lot(self, zone: str, fallback: tuple = ()) -> tuple[int, int] | None:
        """Pop a lot from the preferred zone, falling back in order, then
        any zone at all. Each bucket was shuffled once at generation time,
        so this stays O(1) amortized — no per-call rescanning/sorting,
        which matters at thousands-of-citizens generation size."""
        for z in (zone,) + fallback:
            bucket = self.zone_lots.get(z)
            if bucket:
                return bucket.pop()
        for bucket in self.zone_lots.values():
            if bucket:
                return bucket.pop()
        return None


def _lots_per_block_side(block_size: int) -> int:
    """How many grass columns/rows survive per gap between roads once the
    ring touching each road is converted to sidewalk. block_size=6 ->
    interior indices 1..5, sidewalk at 1 and 5, grass at 2,3,4 -> 3."""
    return max(1, block_size - 3)


def _build_grid(width: int, height: int, rng: random.Random) -> CityLayout:
    tiles = [[TILE_GRASS for _ in range(width)] for _ in range(height)]

    for y in range(height):
        for x in range(width):
            if x % BLOCK_SIZE == 0 or y % BLOCK_SIZE == 0:
                tiles[y][x] = TILE_ROAD

    # Road hierarchy: every 3rd block line is a wider "avenue" (2 tiles),
    # the rest stay narrow "streets" (1 tile) — purely a second lane of
    # TILE_ROAD, same walkability, just visually distinct in the renderer.
    for x in range(0, width, BLOCK_SIZE):
        if (x // BLOCK_SIZE) % 3 == 0 and x + 1 < width:
            for y in range(height):
                tiles[y][x + 1] = TILE_ROAD
    for y in range(0, height, BLOCK_SIZE):
        if (y // BLOCK_SIZE) % 3 == 0 and y + 1 < height:
            for x in range(width):
                tiles[y + 1][x] = TILE_ROAD

    for y in range(height):
        for x in range(width):
            if tiles[y][x] != TILE_ROAD:
                continue
            for dy, dx in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ny, nx = y + dy, x + dx
                if 0 <= ny < height and 0 <= nx < width and tiles[ny][nx] == TILE_GRASS:
                    tiles[ny][nx] = TILE_SIDEWALK

    river_x = width - 3
    for y in range(height):
        if 0 <= river_x < width and tiles[y][river_x] != TILE_ROAD:
            tiles[y][river_x] = TILE_WATER
    # any road tile that survived on the river column is a crossing —
    # relabel it as a bridge for the renderer (same tile role, purely cosmetic)
    for y in range(height):
        if 0 <= river_x < width and tiles[y][river_x] == TILE_ROAD:
            tiles[y][river_x] = TILE_BRIDGE

    layout = CityLayout(width=width, height=height, tiles=tiles, river_x=river_x)
    raw_lots = [
        (x, y) for y in range(height) for x in range(width)
        if tiles[y][x] == TILE_GRASS
    ]
    rng.shuffle(raw_lots)
    layout.available_lots = list(raw_lots)  # kept populated for introspection; not consumed further

    layout.zone_lots = {z: [] for z in ALL_ZONES}
    for (x, y) in raw_lots:
        layout.zone_lots[_classify_zone(x, y, width, height, river_x)].append((x, y))
    return layout


def generate_layout(rng: random.Random, n_house_lots: int, n_companies: int = 8) -> CityLayout:
    """Sizes the grid to comfortably fit houses + company buildings + civic
    buildings, then carves out civic buildings (parks/school/bank/city
    hall/plaza) from the civic-core/downtown zone lots. Companies and
    houses are assigned afterward (place_companies / assign_positions) —
    deliberately NOT done here, so companies get first pick of lots
    instead of finding none left, which was Phase 2's first bug (all
    companies collapsing onto the same fallback tile)."""
    required = n_house_lots + n_companies + 7 + 15  # +7 civic (incl. plaza), +15 buffer
    lots_per_gap = _lots_per_block_side(BLOCK_SIZE)

    blocks_per_side = 2
    while True:
        width = height = blocks_per_side * BLOCK_SIZE + 1
        capacity = (blocks_per_side * lots_per_gap) ** 2
        if capacity >= required or blocks_per_side > 20:
            break
        blocks_per_side += 1

    layout = _build_grid(width, height, rng)

    for _ in range(min(3, len(layout.zone_lots[ZONE_RESIDENTIAL]))):
        pt = layout._take_lot(ZONE_RESIDENTIAL, fallback=(ZONE_CIVIC,))
        if pt is None:
            break
        x, y = pt
        layout.tiles[y][x] = TILE_PARK
        layout.civic_buildings.append({"x": x, "y": y, "type": TILE_PARK, "name": "Park"})

    pt = layout._take_lot(ZONE_CIVIC, fallback=(ZONE_DOWNTOWN,))
    if pt is not None:
        x, y = pt
        layout.tiles[y][x] = TILE_PLAZA
        layout.civic_buildings.append({"x": x, "y": y, "type": TILE_PLAZA, "name": "Civic Plaza"})

    for civic_type, name in [(TILE_SCHOOL, "City School"), (TILE_BANK, "Central Bank"),
                              (TILE_GOVERNMENT, "City Hall")]:
        pt = layout._take_lot(ZONE_CIVIC, fallback=(ZONE_DOWNTOWN,))
        if pt is None:
            break
        x, y = pt
        layout.tiles[y][x] = civic_type
        layout.civic_buildings.append({"x": x, "y": y, "type": civic_type, "name": name})

    return layout


def place_companies(layout: CityLayout, companies: dict[int, Company], rng: random.Random) -> None:
    """Give each company a building on the grid, biased toward the zone
    that fits its sector (offices/banks downtown, factories in the
    industrial fringe, shops mixed downtown/residential) — called BEFORE
    houses are carved out, so companies always get a real, distinct lot
    instead of falling back to a shared default."""
    for company in companies.values():
        building_type = SECTOR_TO_BUILDING.get(company.sector, TILE_OFFICE)
        preference = SECTOR_ZONE_PREFERENCE.get(company.sector, (ZONE_DOWNTOWN,))
        pt = layout._take_lot(preference[0], fallback=preference[1:])
        if pt is None:
            company.loc_x, company.loc_y = layout.width // 2, layout.height // 2
            company.building_type = building_type
            continue
        x, y = pt
        layout.tiles[y][x] = building_type
        company.loc_x, company.loc_y = x, y
        company.building_type = building_type


def assign_positions(citizens: dict[int, Citizen], layout: CityLayout, rng: random.Random) -> None:
    """Carve houses out of whatever's left across all zone buckets (called
    AFTER place_companies) and give each citizen one. If population
    exceeds available house lots even after grid sizing, multiple
    citizens share a lot (apartment building, in spirit) rather than
    crashing — logged as a known simplification, not hidden."""
    leftover = [pt for bucket in layout.zone_lots.values() for pt in bucket]
    rng.shuffle(leftover)
    for x, y in leftover:
        layout.tiles[y][x] = TILE_HOUSE
        layout.house_lots.append((x, y))
    for bucket in layout.zone_lots.values():
        bucket.clear()
    layout.available_lots = []

    if not layout.house_lots:
        layout.house_lots = [(1, 1)]  # degenerate fallback, should not happen in practice

    pool = list(layout.house_lots)
    rng.shuffle(pool)
    for i, citizen in enumerate(citizens.values()):
        if pool:
            x, y = pool.pop()
        else:
            x, y = layout.house_lots[i % len(layout.house_lots)]  # apartment sharing once lots run out
        citizen.home_x, citizen.home_y = x, y
        citizen.grid_x, citizen.grid_y = x, y


def sync_workplace(citizen: Citizen, companies: dict[int, Company]) -> None:
    if citizen.status == EmploymentStatus.EMPLOYED and citizen.employer_id in companies:
        company = companies[citizen.employer_id]
        citizen.work_x, citizen.work_y = company.loc_x, company.loc_y
    else:
        citizen.work_x, citizen.work_y = None, None


PROFESSION_BY_BUILDING = {
    TILE_HOSPITAL: "Doctor",
    TILE_OFFICE: "Office worker",
    TILE_SHOP: "Shop worker",
    TILE_FACTORY: "Construction worker",
}


def profession_label(citizen: Citizen, companies: dict[int, Company]) -> str:
    if not citizen.alive:
        return "—"
    if citizen.age < 18:
        return "Student"
    if citizen.status == EmploymentStatus.RETIRED:
        return "Retiree"
    if citizen.status == EmploymentStatus.UNEMPLOYED:
        return "Unemployed"
    company = companies.get(citizen.employer_id)
    if company is None:
        return "Worker"
    return PROFESSION_BY_BUILDING.get(company.building_type, "Office worker")


def _step_towards(citizen: Citizen, target_x: int, target_y: int) -> None:
    if citizen.grid_x < target_x:
        citizen.grid_x += 1
    elif citizen.grid_x > target_x:
        citizen.grid_x -= 1
    if citizen.grid_y < target_y:
        citizen.grid_y += 1
    elif citizen.grid_y > target_y:
        citizen.grid_y -= 1


def _schedule_target(citizen: Citizen, hour: int, layout: CityLayout, rng: random.Random) -> tuple[int, int, str]:
    """Returns (target_x, target_y, activity_label) for this citizen at
    this hour. Simple fixed schedule, not per-citizen variation (a
    Phase 3+ refinement) beyond employed/unemployed/retired branching."""
    has_job_today = citizen.work_x is not None

    if 0 <= hour < 6 or hour == 23:
        return citizen.home_x, citizen.home_y, "sleeping"
    if 6 <= hour < 8:
        if has_job_today:
            return citizen.work_x, citizen.work_y, "commuting"
        return citizen.home_x, citizen.home_y, "idle"
    if 8 <= hour < 12 or 13 <= hour < 17:
        if has_job_today:
            return citizen.work_x, citizen.work_y, "working"
        # unemployed/retired daytime: wander toward a park if one exists
        if layout.civic_buildings:
            park = rng.choice([b for b in layout.civic_buildings if b["type"] == TILE_PARK] or layout.civic_buildings)
            return park["x"], park["y"], "idle"
        return citizen.home_x, citizen.home_y, "idle"
    if 12 <= hour < 13:
        # lunch — head toward a shop if any exist nearby, else stay put
        return citizen.work_x or citizen.home_x, citizen.work_y or citizen.home_y, "social"
    if 17 <= hour < 19:
        return citizen.home_x, citizen.home_y, "commuting"
    if 19 <= hour < 22:
        if layout.civic_buildings and rng.random() < 0.4:
            park = rng.choice([b for b in layout.civic_buildings if b["type"] == TILE_PARK] or layout.civic_buildings)
            return park["x"], park["y"], "social"
        return citizen.home_x, citizen.home_y, "social"
    return citizen.home_x, citizen.home_y, "idle"


def generate_thought(citizen: Citizen, world: WorldState, companies: dict[int, Company]) -> str:
    """Templated, state-derived — explicitly NOT an LLM call (per the
    Phase 2 spec: 'for now this can be generated from simulation state').
    cognition.py's current_reasoning is the separate, LLM-backed field;
    this is the lightweight always-on thought bubble."""
    if citizen.activity == "sleeping":
        return "Asleep."
    if citizen.status == EmploymentStatus.UNEMPLOYED:
        if world.unemployment_rate > 0.2:
            return "Job hunting is rough right now — so many people are out of work."
        return "Looking for work. Hoping something opens up soon."
    if world.inflation > 0.04:
        return "Prices keep climbing. I'm watching my spending closely."
    if world.inflation < -0.03:
        return "Things feel a bit cheaper lately, which helps."
    if citizen.happiness < 0.35:
        return "It's been a rough stretch. Trying to stay hopeful."
    if citizen.activity == "working":
        company = companies.get(citizen.employer_id)
        workplace_label = company.building_type if company else "job"
        return f"Focused on work at the {workplace_label}."
    if citizen.activity == "social":
        return "Enjoying some time with the neighborhood."
    if citizen.activity == "commuting":
        return "On the way — city traffic isn't too bad today."
    if citizen.happiness > 0.75:
        return "Things are going well. Feeling good about life right now."
    return "Just going about the day."


def tick(citizens: dict[int, Citizen], companies: dict[int, Company], world: WorldState,
         layout: CityLayout | None, rng: random.Random) -> None:
    if layout is None:
        return
    hour = world.tick % HOURS_PER_DAY
    for citizen in citizens.values():
        if not citizen.alive:
            continue
        sync_workplace(citizen, companies)
        target_x, target_y, activity = _schedule_target(citizen, hour, layout, rng)
        citizen.activity = activity
        _step_towards(citizen, target_x, target_y)
        # thought refreshes every few ticks rather than every single tick —
        # keeps it from flickering with every micro state change
        if world.tick % 3 == 0 or citizen.current_thought == "":
            citizen.current_thought = generate_thought(citizen, world, companies)
