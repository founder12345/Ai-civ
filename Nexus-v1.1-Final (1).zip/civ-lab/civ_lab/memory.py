"""
Episodic memory store — Phase 2.

The architecture doc specifies vector-embedding retrieval (pgvector /
Chroma) for agent memory. This sandbox has no network access, so no
embedding model can be called here. Instead: a dependency-free
bag-of-words + recency + importance scorer that implements the SAME
retrieval contract (`retrieve(citizen, query, k)` -> top-k relevant
memories) real embeddings would.

Swap seam: replace `_similarity()` with a cosine similarity over real
embeddings (OpenAI/Voyage/local sentence-transformers) and everything
above this module — cognition.py, api.py — is unaffected, because they
only call `retrieve()`, not the scoring internals.

The retrieval formula mirrors the Stanford "Generative Agents" paper:
score = recency * decay + importance + relevance
"""

from __future__ import annotations
import math
import re
from collections import Counter
from .models import Citizen, MemoryEntry

STOPWORDS = {
    "the", "a", "an", "is", "was", "were", "of", "to", "in", "on", "at",
    "and", "or", "for", "with", "by", "it", "this", "that", "as", "be",
    "has", "have", "had", "his", "her", "their", "its",
}


def _tokenize(text: str) -> Counter:
    words = re.findall(r"[a-zA-Z]+", text.lower())
    return Counter(w for w in words if w not in STOPWORDS)


def _similarity(query_tokens: Counter, memory_tokens: Counter) -> float:
    if not query_tokens or not memory_tokens:
        return 0.0
    shared = set(query_tokens) & set(memory_tokens)
    if not shared:
        return 0.0
    dot = sum(query_tokens[w] * memory_tokens[w] for w in shared)
    qnorm = math.sqrt(sum(v * v for v in query_tokens.values()))
    mnorm = math.sqrt(sum(v * v for v in memory_tokens.values()))
    return dot / (qnorm * mnorm + 1e-9)


def add_memory(citizen: Citizen, tick: int, text: str, importance: float, kind: str = "event") -> None:
    citizen.memories.append(MemoryEntry(tick=tick, text=text, importance=max(0.0, min(1.0, importance)), kind=kind))
    # bound per-agent memory count — Phase 2 uses periodic reflection (below)
    # to compress old memories instead of letting this grow unbounded forever
    if len(citizen.memories) > 200:
        _compress_oldest(citizen)


def _compress_oldest(citizen: Citizen) -> None:
    """Collapse the oldest 50 memories into one reflection summary. A real
    implementation would call the LLM here to write a proper narrative
    summary (see cognition.reflect()); Phase 2's headless default just
    concatenates counts to keep the demo runnable without an API key."""
    oldest = citizen.memories[:50]
    rest = citizen.memories[50:]
    kinds = Counter(m.kind for m in oldest)
    span = f"t={oldest[0].tick}-{oldest[-1].tick}"
    summary = MemoryEntry(
        tick=oldest[-1].tick,
        text=f"(compressed memory {span}: {dict(kinds)})",
        importance=max(m.importance for m in oldest),
        kind="reflection",
    )
    citizen.memories = [summary] + rest


def retrieve(citizen: Citizen, query: str, current_tick: int, k: int = 8) -> list[MemoryEntry]:
    """Top-k memories by recency + importance + relevance, same contract a
    real vector store would expose."""
    if not citizen.memories:
        return []
    query_tokens = _tokenize(query)
    scored = []
    for m in citizen.memories:
        age = max(0, current_tick - m.tick)
        recency = math.exp(-age / 200.0)          # exponential decay, half-life ~140 ticks
        relevance = _similarity(query_tokens, _tokenize(m.text))
        score = 1.0 * recency + 1.0 * m.importance + 2.0 * relevance
        scored.append((score, m))
    scored.sort(key=lambda pair: pair[0], reverse=True)
    return [m for _, m in scored[:k]]
