"""
Politics module — parties, periodic elections, approval rating, and
protest events. Ideology is a single left-right axis per citizen/party
for tractability; a real platform would want a multi-axis model
(economic, social, etc.) — flagged as a Phase 3+ refinement, not hidden.
"""

from __future__ import annotations
import random
from .models import Citizen, WorldState, Party
from . import cognition


def seed_parties() -> dict[int, Party]:
    return {
        1: Party(id=1, name="Progressive Alliance", ideology_center=-0.6, in_power=True),
        2: Party(id=2, name="Liberty Coalition", ideology_center=0.6),
        3: Party(id=3, name="Centrist Union", ideology_center=0.0),
    }


def update_approval(citizens: dict[int, Citizen], parties: dict[int, Party], world: WorldState) -> None:
    """Government approval tracks economic conditions (unemployment,
    inflation) and how well the ruling party's ideology matches the
    population's average ideology — a simplified but directionally
    correct model of retrospective + ideological voting."""
    ruling = parties.get(world.ruling_party_id) if world.ruling_party_id else None
    if ruling is None:
        return
    alive = [c for c in citizens.values() if c.alive]
    if not alive:
        return
    avg_ideology = sum(c.political_ideology for c in alive) / len(alive)
    ideology_gap = abs(ruling.ideology_center - avg_ideology)  # 0 (aligned) .. 2 (opposite)

    economic_score = 1.0 - min(1.0, world.unemployment_rate * 2 + abs(world.inflation) * 5)
    ideology_score = 1.0 - ideology_gap / 2.0
    target_approval = 0.5 * economic_score + 0.5 * ideology_score

    world.government_approval += (target_approval - world.government_approval) * 0.05
    world.government_approval = max(0.0, min(1.0, world.government_approval))
    ruling.approval = world.government_approval


def maybe_hold_election(citizens: dict[int, Citizen], parties: dict[int, Party], world: WorldState, rng: random.Random) -> None:
    if world.tick == 0 or world.tick % world.election_interval != 0:
        return
    alive = [c for c in citizens.values() if c.alive]
    if not alive:
        return

    votes = {pid: 0 for pid in parties}
    for citizen in alive:
        # each citizen votes for whichever party's ideology is closest to
        # their own, with a bit of noise from current happiness (economic voting)
        noise = rng.uniform(-0.15, 0.15) * (1.0 - citizen.happiness)
        best_party = min(parties.values(), key=lambda p: abs(p.ideology_center - citizen.political_ideology - noise))
        votes[best_party.id] += 1

    winner_id = max(votes, key=votes.get)
    previous_ruler = world.ruling_party_id
    for party in parties.values():
        party.in_power = (party.id == winner_id)
    world.ruling_party_id = winner_id
    winner = parties[winner_id]

    total_votes = sum(votes.values())
    pct = {parties[pid].name: round(100 * v / total_votes, 1) for pid, v in votes.items()}
    world.log(f"ELECTION at t={world.tick}: {winner.name} wins ({pct}).")

    # Policy effect: winning party nudges tax_rate toward its ideology
    # (left = higher tax/spend, right = lower tax/spend) — again a
    # simplification, but one that makes elections visibly matter.
    if winner.ideology_center < -0.2:
        world.tax_rate = min(0.45, world.tax_rate + 0.03)
        world.education_funding_level = min(1.0, world.education_funding_level + 0.05)
        world.healthcare_funding_level = min(1.0, world.healthcare_funding_level + 0.05)
    elif winner.ideology_center > 0.2:
        world.tax_rate = max(0.05, world.tax_rate - 0.03)

    if winner_id != previous_ruler:
        world.government_approval = 0.55  # honeymoon bump for new government
        # engaged citizens near the political center get a cognition trigger
        for citizen in alive:
            if abs(citizen.political_ideology) < 0.3 and rng.random() < 0.05:
                cognition.bump_salience(citizen, 0.3, f"{winner.name} won the election.", world, "election")


def maybe_trigger_protest(citizens: dict[int, Citizen], world: WorldState, rng: random.Random) -> None:
    """Low approval + high unemployment can spark a protest event, which
    dents happiness broadly and is exactly the kind of event Phase 4/5
    would let the player's sandbox both cause and respond to."""
    if world.government_approval < 0.3 and world.unemployment_rate > 0.2 and rng.random() < 0.02:
        world.log(f"PROTEST erupts (approval={world.government_approval:.2f}, unemployment={world.unemployment_rate:.2f}).")
        alive = [c for c in citizens.values() if c.alive]
        for citizen in alive:
            citizen.happiness = max(0.0, citizen.happiness - 0.03)
        # a handful of the most dissatisfied citizens get a real cognition pass
        angriest = sorted(alive, key=lambda c: c.happiness)[:3]
        for citizen in angriest:
            cognition.bump_salience(citizen, 0.5, "Participated in a protest against the government.", world, "protest_opportunity")


def tick(citizens: dict[int, Citizen], parties: dict[int, Party], world: WorldState, rng: random.Random) -> None:
    if world.ruling_party_id is None and parties:
        world.ruling_party_id = next(p.id for p in parties.values() if p.in_power)
    update_approval(citizens, parties, world)
    maybe_hold_election(citizens, parties, world, rng)
    maybe_trigger_protest(citizens, world, rng)
