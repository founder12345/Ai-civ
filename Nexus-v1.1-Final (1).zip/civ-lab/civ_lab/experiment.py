"""
Experiment Mode — Phase 6.

Architectural rule this module follows strictly: it does not simulate
anything itself. It builds one real Simulation (the same class every
other phase uses), calls its existing .step()/.stats(), applies events
through the existing events.trigger_event() / direct WorldState field
writes (same fields the sandbox variable endpoint already exposes), and
records snapshots. Analysis is pure arithmetic over recorded snapshots
and citizen state — no separate model of the economy.

TICKS_PER_YEAR = 24 * 365 = 8760, matching city.py's HOURS_PER_DAY=24
schedule (1 tick = 1 simulated hour, as used everywhere else already).
"""
from __future__ import annotations
import json
import hashlib
import random
import statistics
import time
from dataclasses import dataclass, field, asdict
from .simulation import Simulation
from .seed import build_default_simulation
from .llm import MockLLMClient
from . import events as events_module
from .models import EmploymentStatus

TICKS_PER_YEAR = 24 * 365
SNAPSHOT_EVERY_TICKS = 24 * 7  # weekly — keeps a 10-year run's time series to ~520 points, not 87,600

DIRECT_VARIABLE_EVENTS = {
    # events not in events.trigger_event's vocabulary — applied as direct,
    # bounded WorldState/citizen writes using the exact same fields the
    # sandbox variable endpoint already exposes (no new state model).
    "inflation_shock": lambda world, citizens, companies, severity, rng: setattr(world, "inflation", min(0.5, world.inflation + 0.20 * severity)),
    "interest_rate_increase": lambda world, citizens, companies, severity, rng: setattr(world, "interest_rate", min(0.30, world.interest_rate + 0.04 * severity)),
    "interest_rate_decrease": lambda world, citizens, companies, severity, rng: setattr(world, "interest_rate", max(0.0, world.interest_rate - 0.04 * severity)),
    "tax_increase": lambda world, citizens, companies, severity, rng: setattr(world, "tax_rate", min(0.60, world.tax_rate + 0.08 * severity)),
    "tax_cut": lambda world, citizens, companies, severity, rng: setattr(world, "tax_rate", max(0.0, world.tax_rate - 0.08 * severity)),
}


def _apply_ubi(world, citizens, companies, severity, rng):
    amount = 500 * severity
    cost = 0.0
    for c in citizens.values():
        if c.alive:
            c.wealth += amount
            cost += amount
    world.government_budget -= cost


def _apply_immigration_shock(world, citizens, companies, severity, rng):
    from . import city as city_module
    n_new = max(1, int(len(citizens) * 0.05 * severity))
    next_id = max(citizens, default=0) + 1
    for i in range(n_new):
        from .models import Citizen
        cid = next_id + i
        c = Citizen(id=cid, name=f"Newcomer{cid}", age=rng.randint(20, 40),
                    skill_level=round(rng.uniform(0.3, 0.8), 2), education_level=round(rng.uniform(0.3, 0.7), 2),
                    political_ideology=round(rng.uniform(-1, 1), 2), consumption_propensity=round(rng.uniform(0.5, 0.9), 2),
                    risk_tolerance=round(rng.uniform(0, 1), 2), wealth=round(rng.uniform(100, 800), 2),
                    status=EmploymentStatus.UNEMPLOYED)
        if world._layout_ref and world._layout_ref.house_lots:
            x, y = rng.choice(world._layout_ref.house_lots)
            c.home_x, c.home_y, c.grid_x, c.grid_y = x, y, x, y
        citizens[cid] = c


def _apply_ai_automation_shock(world, citizens, companies, severity, rng):
    affected = [c for c in citizens.values() if c.alive and c.status == EmploymentStatus.EMPLOYED
                and c.skill_level < 0.4 and rng.random() < 0.3 * severity]
    from . import cognition
    for c in affected:
        if c.employer_id and c.employer_id in companies:
            comp = companies[c.employer_id]
            comp.employee_ids = [cid for cid in comp.employee_ids if cid != c.id]
        c.status = EmploymentStatus.UNEMPLOYED
        c.employer_id = None
        cognition.bump_salience(c, 0.5, "Lost their job to workplace automation.", world, "job_loss")


DIRECT_VARIABLE_EVENTS["universal_basic_income"] = _apply_ubi
DIRECT_VARIABLE_EVENTS["immigration_shock"] = _apply_immigration_shock
DIRECT_VARIABLE_EVENTS["ai_automation_shock"] = _apply_ai_automation_shock

ALL_EVENT_NAMES = frozenset(
    set(events_module.EVENT_DEFINITIONS.keys()) | set(DIRECT_VARIABLE_EVENTS.keys())
)


@dataclass
class ScheduledEvent:
    year: float
    event: str
    severity: float = 0.7
    applied: bool = False


@dataclass
class ExperimentConfig:
    name: str = "Untitled Experiment"
    population: int = 1000
    n_companies: int | None = None
    years: float = 10.0
    seed: int = 12345
    starting_unemployment: float = 0.06
    starting_inflation: float = 0.0
    starting_interest_rate: float = 0.03
    starting_tax_rate: float = 0.20
    starting_government_budget: float = 50_000.0
    wealth_inequality: float = 0.5  # 0 = flat/equal, 1 = high variance
    events: list[ScheduledEvent] = field(default_factory=list)


@dataclass
class ExperimentResult:
    config: ExperimentConfig
    time_series: list[dict] = field(default_factory=list)  # one row per snapshot
    before_snapshot: dict | None = None   # state right before the first event
    after_snapshot: dict | None = None    # state at experiment end
    most_affected: dict | None = None     # category -> list of citizen summaries
    distribution_before: dict | None = None
    distribution_after: dict | None = None
    wall_clock_seconds: float = 0.0
    reproducibility_hash: str = ""


def _apply_wealth_distribution(sim: Simulation, inequality: float) -> None:
    """Reshapes the seed population's wealth to match wealth_inequality
    without touching seed.py's employment/personality logic — just a
    post-pass redistribution using the same rng, so it stays seeded and
    reproducible."""
    citizens = list(sim.citizens.values())
    n = len(citizens)
    if n == 0:
        return
    total = sum(c.wealth for c in citizens)
    avg = total / n
    for c in citizens:
        # blend each citizen's wealth toward a Pareto-shaped draw as
        # inequality rises, toward flat `avg` as inequality falls to 0
        skewed = avg * (sim.rng.paretovariate(max(0.5, 3.0 - 2.5 * inequality)))
        c.wealth = round(avg * (1 - inequality) + skewed * inequality, 2)


def _seed_starting_unemployment(sim: Simulation, target_rate: float) -> None:
    citizens = [c for c in sim.citizens.values() if c.alive]
    n_target = int(len(citizens) * target_rate)
    sim.rng.shuffle(citizens)
    for c in citizens[:n_target]:
        if c.status == EmploymentStatus.EMPLOYED and c.employer_id in sim.companies:
            comp = sim.companies[c.employer_id]
            comp.employee_ids = [cid for cid in comp.employee_ids if cid != c.id]
        c.status = EmploymentStatus.UNEMPLOYED
        c.employer_id = None


def _snapshot(sim: Simulation) -> dict:
    s = sim.stats()
    citizens = [c for c in sim.citizens.values() if c.alive]
    wealths = [c.wealth for c in citizens] or [0]
    incomes = [c.income for c in citizens] or [0]
    return {
        "tick": s["tick"], "year": round(s["tick"] / TICKS_PER_YEAR, 2),
        "population": s["population"], "gdp": s["gdp"],
        "gdp_per_capita": round(s["gdp"] / max(1, s["population"]), 2),
        "inflation": s["inflation"],
        "unemployment_rate": s["unemployment_rate"], "avg_happiness": s["avg_happiness"],
        "avg_wealth": round(statistics.mean(wealths), 2), "median_wealth": round(statistics.median(wealths), 2),
        "avg_income": round(statistics.mean(incomes), 2), "median_income": round(statistics.median(incomes), 2),
        "active_companies": s["active_companies"], "bankrupt_companies": s.get("bankrupt_companies", 0),
        "crime_rate": s["crime_rate"], "gini_estimate": s.get("gini_estimate", 0.0),
        "housing_price_index": s.get("housing_price_index", 100.0), "stock_market_index": s.get("stock_market_index", 100.0),
        "poverty_rate": s.get("poverty_rate", 0.0), "polarization": s.get("polarization", 0.0),
        "social_cohesion": s.get("social_cohesion", 0.0), "government_debt": s.get("government_debt", 0.0),
        "environmental_quality": s.get("environmental_quality", 0.0), "trade_balance": s.get("trade_balance", 0.0),
    }


def _percentiles(values: list[float]) -> dict:
    if not values:
        return {"p10": 0, "p25": 0, "median": 0, "p75": 0, "p90": 0}
    v = sorted(values)
    def pct(p):
        idx = min(len(v) - 1, max(0, int(len(v) * p)))
        return round(v[idx], 2)
    return {"p10": pct(0.10), "p25": pct(0.25), "median": pct(0.50), "p75": pct(0.75), "p90": pct(0.90)}


def _distribution(sim: Simulation) -> dict:
    citizens = [c for c in sim.citizens.values() if c.alive]
    return {
        "wealth": _percentiles([c.wealth for c in citizens]),
        "income": _percentiles([c.income for c in citizens]),
        "employed_pct": round(sum(1 for c in citizens if c.status == EmploymentStatus.EMPLOYED) / max(1, len(citizens)) * 100, 1),
    }


def _most_affected(before_state: dict, sim: Simulation, limit: int = 8) -> dict:
    rows = []
    for c in sim.citizens.values():
        if not c.alive:
            continue
        prev = before_state.get(c.id)
        if prev is None:
            continue
        rows.append({
            "id": c.id, "name": c.name,
            "wealth_change": round(c.wealth - prev["wealth"], 2),
            "income_change": round(c.income - prev["income"], 2),
            "happiness_change": round(c.happiness - prev["happiness"], 2),
            "became_unemployed": prev["status"] == "employed" and c.status.value == "unemployed",
            "became_employed": prev["status"] == "unemployed" and c.status.value == "employed",
            "started_business": c.last_action == "START_BUSINESS",
        })

    def top(key, reverse):
        return sorted(rows, key=lambda r: r[key], reverse=reverse)[:limit]

    return {
        "largest_wealth_loss": top("wealth_change", False),
        "largest_wealth_gain": top("wealth_change", True),
        "largest_income_loss": top("income_change", False),
        "largest_happiness_drop": top("happiness_change", False),
        "became_unemployed": [r for r in rows if r["became_unemployed"]][:limit],
        "became_employed": [r for r in rows if r["became_employed"]][:limit],
        "started_business": [r for r in rows if r["started_business"]][:limit],
    }


def run_experiment(config: ExperimentConfig, progress_callback=None) -> ExperimentResult:
    """progress_callback(fraction_complete: float, snapshot: dict) is called
    after every recorded snapshot — this is what lets a Flask endpoint
    report live progress without a second engine polling loop."""
    t_start = time.perf_counter()
    n_companies = config.n_companies or max(8, round(config.population * 8 / 50))

    sim = build_default_simulation(n_citizens=config.population, n_companies=n_companies, seed=config.seed)
    sim.llm = MockLLMClient()  # experiments always use Mock — reproducibility must not depend on network/API state
    sim.world._layout_ref = sim.city_layout  # small internal convenience used by _apply_immigration_shock
    sim.world.inflation = config.starting_inflation
    sim.world.interest_rate = config.starting_interest_rate
    sim.world.tax_rate = config.starting_tax_rate
    sim.world.government_budget = config.starting_government_budget
    _apply_wealth_distribution(sim, config.wealth_inequality)
    _seed_starting_unemployment(sim, config.starting_unemployment)

    total_ticks = int(config.years * TICKS_PER_YEAR)
    events_sorted = sorted(config.events, key=lambda e: e.year)

    # "Before" is always captured at experiment start — not just "right
    # before the first event" — so before/after analysis is well-defined
    # even for a run where no configured event ever actually fires within
    # the duration (e.g., an event scheduled for year 3 in a 1-year run).
    before_state = {c.id: {"wealth": c.wealth, "income": c.income, "happiness": c.happiness,
                            "status": c.status.value} for c in sim.citizens.values() if c.alive}
    result = ExperimentResult(config=config)
    result.before_snapshot = _snapshot(sim)
    result.distribution_before = _distribution(sim)

    ticks_done = 0
    while ticks_done < total_ticks:
        chunk = min(SNAPSHOT_EVERY_TICKS, total_ticks - ticks_done)
        sim.step(chunk)
        ticks_done += chunk

        current_year = ticks_done / TICKS_PER_YEAR
        for ev in events_sorted:
            if not ev.applied and current_year >= ev.year:
                if ev.event in events_module.EVENT_DEFINITIONS:
                    events_module.trigger_event(sim.world, sim.citizens, ev.event, ev.severity, sim.rng, sim.companies)
                elif ev.event in DIRECT_VARIABLE_EVENTS:
                    DIRECT_VARIABLE_EVENTS[ev.event](sim.world, sim.citizens, sim.companies, ev.severity, sim.rng)
                ev.applied = True

        snap = _snapshot(sim)
        result.time_series.append(snap)
        if progress_callback:
            progress_callback(ticks_done / total_ticks, snap)

    result.after_snapshot = _snapshot(sim)
    result.distribution_after = _distribution(sim)
    result.most_affected = _most_affected(before_state, sim)
    any_event_fired = any(ev.applied for ev in events_sorted)
    if not any_event_fired:
        result.most_affected["_note"] = "No configured event actually fired within the run duration — this compares experiment start to end."

    result.wall_clock_seconds = round(time.perf_counter() - t_start, 2)
    canonical = json.dumps({"config": asdict(config), "after": result.after_snapshot, "series": result.time_series}, sort_keys=True, default=str).encode()
    result.reproducibility_hash = hashlib.sha256(canonical).hexdigest()
    return result


def pct_change(before: float, after: float) -> float | None:
    if before == 0:
        return None
    return round((after - before) / abs(before) * 100, 1)


def to_json(result: ExperimentResult) -> str:
    d = asdict(result)
    return json.dumps(d, indent=2, default=str)


def time_series_to_csv(result: ExperimentResult) -> str:
    if not result.time_series:
        return ""
    keys = list(result.time_series[0].keys())
    lines = [",".join(keys)]
    for row in result.time_series:
        lines.append(",".join(str(row[k]) for k in keys))
    return "\n".join(lines)
