"""Seed a fresh Simulation with citizens and companies for Phase 1 demo."""

from __future__ import annotations
import random
from .models import Citizen, Company, EmploymentStatus
from .simulation import Simulation
from . import city

FIRST_NAMES = [
    "Amara", "Liam", "Sofia", "Noah", "Yuki", "Elena", "Kwame", "Maya",
    "Diego", "Priya", "Omar", "Ines", "Lucas", "Zara", "Felix", "Nina",
    "Arjun", "Chloe", "Kai", "Layla",
]
LAST_NAMES = [
    "Reyes", "Novak", "Kimura", "Diallo", "Petrov", "Silva", "Nakamura",
    "Haddad", "Andersson", "Okafor", "Moreau", "Larsen", "Costa", "Blanc",
]
SECTORS = ["Food", "Tech", "Retail", "Construction", "Healthcare"]
COMPANY_ROOTS = [
    "Northgate", "Blue River", "Solace", "Ironvale", "Meridian",
    "Harbor", "Vantage", "Coral", "Timberline", "Alden",
]


def build_default_simulation(n_citizens: int = 50, n_companies: int = 8, seed: int = 42) -> Simulation:
    sim = Simulation(seed=seed)
    rng = sim.rng

    for cid in range(1, n_citizens + 1):
        name = f"{rng.choice(FIRST_NAMES)} {rng.choice(LAST_NAMES)}"
        citizen = Citizen(
            id=cid,
            name=name,
            age=rng.randint(18, 65),
            skill_level=round(rng.uniform(0.2, 0.95), 2),
            wealth=round(rng.uniform(200, 2000), 2),
            education_level=round(rng.uniform(0.2, 0.95), 2),
            political_ideology=round(rng.uniform(-1, 1), 2),
            consumption_propensity=round(rng.uniform(0.65, 0.95), 2),
            risk_tolerance=round(rng.uniform(0.0, 1.0), 2),
        )
        sim.citizens[cid] = citizen

    for coid in range(1, n_companies + 1):
        sector = rng.choice(SECTORS)
        company = Company(
            id=coid,
            name=f"{rng.choice(COMPANY_ROOTS)} {sector}",
            sector=sector,
            cash=round(rng.uniform(2000, 6000), 2),
            target_headcount=rng.randint(3, 9),
            wage_budget_per_head=round(rng.uniform(22, 38), 2),
            price_level=round(rng.uniform(8, 15), 2),
        )
        sim.companies[coid] = company

    # Initial employment: fill each company up toward target headcount
    unemployed = list(sim.citizens.keys())
    rng.shuffle(unemployed)
    for company in sim.companies.values():
        for _ in range(min(company.target_headcount, len(unemployed))):
            cid = unemployed.pop()
            sim.citizens[cid].employer_id = company.id
            sim.citizens[cid].status = EmploymentStatus.EMPLOYED
            company.employee_ids.append(cid)

    # Randomly assign initial party leanings roughly matching each
    # citizen's ideology, and seed each citizen with a starting goal so
    # the inspector never shows an empty goals list on tick 0.
    for citizen in sim.citizens.values():
        closest_party = min(sim.parties.values(), key=lambda p: abs(p.ideology_center - citizen.political_ideology))
        citizen.party_id = closest_party.id
        citizen.goals = ["build financial stability"]

    sim.world.population = n_citizens

    # --- Phase 2: generate the city grid, place company buildings, and
    # assign every citizen a home + workplace on the grid. Additive —
    # doesn't touch economy/society/politics state above.
    sim.city_layout = city.generate_layout(rng, n_house_lots=n_citizens, n_companies=n_companies)
    city.place_companies(sim.city_layout, sim.companies, rng)
    city.assign_positions(sim.citizens, sim.city_layout, rng)
    for citizen in sim.citizens.values():
        city.sync_workplace(citizen, sim.companies)

    sim.world.log(f"World seeded: {n_citizens} citizens, {n_companies} companies.")
    return sim
