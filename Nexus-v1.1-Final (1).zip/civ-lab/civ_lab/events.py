"""
World events — timed, parameterized shocks the player can inject via
the sandbox (or that could later fire randomly). Each event applies a
temporary multiplier/delta to WorldState fields and expires after a
set number of ticks, tracked in world.active_event_effects.

This is a distinct mechanism from apply_sandbox_variable: a variable
set is a permanent, direct edit; an event is a temporary, named,
expiring effect with its own narrative log entry — closer to how a
"pandemic" or "recession" should feel than silently changing a number
forever.
"""

from __future__ import annotations
import random
from .models import Citizen, WorldState, EmploymentStatus, Company
from . import cognition

EVENT_DEFINITIONS = {
    "pandemic": {
        "duration": 100,
        "description": "A pandemic strikes, straining healthcare and depressing consumer spending.",
    },
    "recession": {
        "duration": 150,
        "description": "A recession begins: demand contracts and layoffs accelerate.",
    },
    "tech_breakthrough": {
        "duration": 200,
        "description": "A technological breakthrough boosts productivity across sectors.",
    },
    "natural_disaster": {
        "duration": 40,
        "description": "A natural disaster damages property and disrupts daily life.",
    },
    "economic_boom": {
        "duration": 150,
        "description": "An economic boom takes hold: demand surges and businesses expand.",
    },
    "housing_crash": {
        "duration": 120,
        "description": "A housing crash wipes out household wealth and rattles confidence.",
    },
    "bank_failure": {
        "duration": 80,
        "description": "A major bank fails, tightening credit and spooking the market.",
    },
    "mass_layoffs": {
        "duration": 1,   # instantaneous shock — layoffs happen immediately, no lingering multiplier
        "description": "A wave of mass layoffs hits every company at once.",
    },
}


def trigger_event(world: WorldState, citizens: dict[int, Citizen], event_name: str, severity: float,
                   rng: random.Random, companies: dict[int, Company] | None = None) -> str:
    if event_name not in EVENT_DEFINITIONS:
        raise ValueError(f"Unknown event type: {event_name}. Known: {list(EVENT_DEFINITIONS)}")
    severity = max(0.0, min(1.0, severity))
    companies = companies or {}
    definition = EVENT_DEFINITIONS[event_name]
    expires_at = world.tick + definition["duration"]
    world.active_event_effects[event_name] = {"severity": severity, "expires_tick": expires_at}
    world.log(f"WORLD EVENT: {definition['description']} (severity={severity:.2f}, until t={expires_at})")

    alive = [c for c in citizens.values() if c.alive]
    if event_name == "pandemic":
        world.healthcare_funding_level = max(0.0, world.healthcare_funding_level - 0.2 * severity)
        for citizen in rng.sample(alive, k=min(5, len(alive))):
            cognition.bump_salience(citizen, 0.5 * severity, "A pandemic is affecting daily life and health.", world, "pandemic")
    elif event_name == "recession":
        world.money_supply *= (1 - 0.05 * severity)
        for citizen in rng.sample(alive, k=min(5, len(alive))):
            cognition.bump_salience(citizen, 0.4 * severity, "A recession is threatening job security.", world, "recession")
    elif event_name == "natural_disaster":
        for citizen in alive:
            loss = citizen.wealth * 0.1 * severity
            citizen.wealth -= loss
            citizen.happiness = max(0.0, citizen.happiness - 0.1 * severity)
        for citizen in rng.sample(alive, k=min(5, len(alive))):
            cognition.bump_salience(citizen, 0.6 * severity, "A natural disaster damaged the community.", world, "disaster")
    elif event_name == "tech_breakthrough":
        for citizen in alive:
            citizen.skill_level = min(1.0, citizen.skill_level + 0.02 * severity)
    elif event_name == "economic_boom":
        world.money_supply *= (1 + 0.05 * severity)
        for citizen in alive:
            citizen.happiness = min(1.0, citizen.happiness + 0.05 * severity)
        for company in companies.values():
            if not company.is_bankrupt:
                company.cash += 500 * severity
    elif event_name == "housing_crash":
        for citizen in alive:
            loss = citizen.wealth * 0.25 * severity
            citizen.wealth -= loss
            citizen.happiness = max(0.0, citizen.happiness - 0.15 * severity)
        for citizen in rng.sample(alive, k=min(5, len(alive))):
            cognition.bump_salience(citizen, 0.6 * severity, "A housing crash wiped out a large chunk of savings.", world, "housing_crash")
    elif event_name == "bank_failure":
        world.government_budget = max(0.0, world.government_budget - 5000 * severity)
        world.interest_rate = min(0.30, world.interest_rate + 0.03 * severity)
        # one random solvent company takes the hit directly
        solvent = [c for c in companies.values() if not c.is_bankrupt]
        if solvent:
            hit = rng.choice(solvent)
            hit.cash -= 1000 * severity
            world.log(f"{hit.name} lost credit access after the bank failure.")
        for citizen in rng.sample(alive, k=min(5, len(alive))):
            cognition.bump_salience(citizen, 0.5 * severity, "A major bank failure is shaking confidence in the economy.", world, "bank_failure")
    elif event_name == "mass_layoffs":
        total_laid_off = 0
        for company in companies.values():
            if company.is_bankrupt or not company.employee_ids:
                continue
            n_layoffs = max(1, int(len(company.employee_ids) * 0.3 * severity))
            for _ in range(min(n_layoffs, len(company.employee_ids))):
                cid = company.employee_ids.pop()
                if cid in citizens:
                    citizens[cid].status = EmploymentStatus.UNEMPLOYED
                    citizens[cid].employer_id = None
                    cognition.bump_salience(citizens[cid], 0.6 * severity, "Lost their job in a wave of mass layoffs.", world, "mass_layoffs")
                    total_laid_off += 1
        world.log(f"Mass layoffs: {total_laid_off} citizens lost their jobs.")

    return f"{event_name} triggered at severity {severity:.2f}, effects active until tick {expires_at}."


def apply_active_effects(world: WorldState) -> None:
    """Called every tick from economy/society modules that check
    world.active_event_effects for the multipliers relevant to them.
    Here we just expire old ones."""
    expired = [name for name, eff in world.active_event_effects.items() if world.tick >= eff["expires_tick"]]
    for name in expired:
        del world.active_event_effects[name]
        world.log(f"WORLD EVENT ended: {name}.")


def pandemic_active_severity(world: WorldState) -> float:
    eff = world.active_event_effects.get("pandemic")
    return eff["severity"] if eff else 0.0


def recession_active_severity(world: WorldState) -> float:
    eff = world.active_event_effects.get("recession")
    return eff["severity"] if eff else 0.0
