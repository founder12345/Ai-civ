"""
Society module — Tier 0/1 deterministic rules for the social layer:
aging, marriage formation, birth/death, education drift, crime.

Same pattern as economy.py: cheap rule-based updates every tick, with
notable individual events (marriage, bankruptcy-driven crime spike,
a death in the family) raising salience so cognition.py can pick them
up for real reasoning, instead of every citizen thinking every tick.
"""

from __future__ import annotations
import random
from .models import Citizen, WorldState, EmploymentStatus, MaritalStatus
from . import cognition

TICKS_PER_YEAR = 8760  # aligned with city.py's HOURS_PER_DAY=24 / experiment.py's
# 1-tick-per-hour convention (24*365=8760). Previously this was 20, a leftover
# from before that convention was established elsewhere — verified this made
# citizens age ~438x faster than intended (an "8,760-tick year" experiment run
# was actually ~438 years on this clock), which was the dominant driver of the
# long-run economic collapse: citizens retired and died at an enormously
# inflated rate, and retirement/death left them stuck in their employer's
# employee_ids forever (see age_population below and process_mortality),
# destroying real employment capacity company by company far faster than any
# hiring mechanism could replace it. The previous session's economy.py fixes
# (revenue weighting, price adjustment, tax recycling, dead-employee cleanup)
# were all real and independently correct — they just couldn't keep up with
# a labor force retiring/dying at 438x the intended rate.


def age_population(citizens: dict[int, Citizen], companies: dict, world: WorldState) -> None:
    if world.tick % TICKS_PER_YEAR != 0:
        return
    for citizen in citizens.values():
        if not citizen.alive:
            continue
        citizen.age += 1
        if citizen.age >= 67 and citizen.status == EmploymentStatus.EMPLOYED:
            citizen.status = EmploymentStatus.RETIRED
            world.log(f"{citizen.name} retired at age {citizen.age}.")
            # Same phantom-slot bug as death (see process_mortality below) —
            # a retiree left in employee_ids keeps getting paid forever
            # (pay_wages only checks .alive, not .status) AND permanently
            # blocks the seat from reopening, since company.headcount is
            # just len(employee_ids).
            if citizen.employer_id and citizen.employer_id in companies:
                company = companies[citizen.employer_id]
                company.employee_ids = [cid for cid in company.employee_ids if cid != citizen.id]
            citizen.employer_id = None


def process_mortality(citizens: dict[int, Citizen], companies: dict, world: WorldState, rng: random.Random) -> None:
    """Simple age + healthcare-funding-driven mortality. Runs every tick
    but at a low per-tick probability so population decline is gradual."""
    for citizen in citizens.values():
        if not citizen.alive:
            continue
        base_risk = 0.00005 * max(0, citizen.age - 50) ** 1.5
        base_risk *= (1.4 - world.healthcare_funding_level)  # better funding -> lower risk
        if citizen.age > 30 and rng.random() < base_risk:
            citizen.alive = False
            citizen.status = EmploymentStatus.RETIRED
            world.deaths_total += 1
            world.log(f"{citizen.name} passed away at age {citizen.age}.")
            # Must actually free their seat, not just mark them dead — a
            # dead citizen left in employee_ids permanently occupies a
            # phantom headcount slot: company.headcount = len(employee_ids)
            # never drops, so hiring's "headcount < target_headcount" check
            # stays permanently false even with abundant cash. Verified this
            # was the decisive mechanism behind the long-run 100%
            # unemployment collapse — by the time it locks in, EVERY
            # non-bankrupt company's entire employee_ids list is 100% dead
            # citizens, some sitting on 20,000+ cash, unable to ever hire
            # a real replacement.
            if citizen.employer_id and citizen.employer_id in companies:
                company = companies[citizen.employer_id]
                company.employee_ids = [cid for cid in company.employee_ids if cid != citizen.id]
            citizen.employer_id = None
            if citizen.spouse_id and citizen.spouse_id in citizens:
                spouse = citizens[citizen.spouse_id]
                spouse.marital_status = MaritalStatus.WIDOWED
                spouse.spouse_id = None
                cognition.bump_salience(spouse, 0.6, f"{citizen.name}, their spouse, passed away.", world, "bereavement")


def process_marriages(citizens: dict[int, Citizen], world: WorldState, rng: random.Random) -> None:
    """Once every ~2 years (in sim-time), eligible single adults have a
    small chance of pairing off with another single adult of compatible
    age. Deliberately simple — no dating-preference modeling."""
    if world.tick % (TICKS_PER_YEAR * 2) != 0:
        return
    eligible = [
        c for c in citizens.values()
        if c.alive and c.marital_status == MaritalStatus.SINGLE and 20 <= c.age <= 60
    ]
    rng.shuffle(eligible)
    while len(eligible) >= 2:
        a = eligible.pop()
        # find a compatible partner within 15 years of age
        partner_idx = next((i for i, b in enumerate(eligible) if abs(b.age - a.age) <= 15), None)
        if partner_idx is None:
            continue
        b = eligible.pop(partner_idx)
        if rng.random() < 0.3:  # not everyone eligible actually marries this cycle
            a.marital_status = b.marital_status = MaritalStatus.MARRIED
            a.spouse_id, b.spouse_id = b.id, a.id
            world.marriages_total += 1
            world.log(f"{a.name} and {b.name} got married.")
            cognition.bump_salience(a, 0.5, f"{a.name} got married to {b.name}.", world, "marriage")
            cognition.bump_salience(b, 0.5, f"{b.name} got married to {a.name}.", world, "marriage")


def process_births(citizens: dict[int, Citizen], world: WorldState, rng: random.Random, next_id_fn) -> None:
    """Married couples of childbearing age have a small chance of a new
    citizen joining the population each cycle."""
    if world.tick % (TICKS_PER_YEAR * 2) != 0:
        return
    seen_couples = set()
    for citizen in list(citizens.values()):
        if not citizen.alive or citizen.marital_status != MaritalStatus.MARRIED:
            continue
        if not (20 <= citizen.age <= 42):
            continue
        pair = tuple(sorted([citizen.id, citizen.spouse_id or -1]))
        if pair in seen_couples or citizen.spouse_id not in citizens:
            continue
        seen_couples.add(pair)
        if rng.random() < 0.2:
            parent_a, parent_b = citizen, citizens[citizen.spouse_id]
            new_id = next_id_fn()
            child = Citizen(
                id=new_id,
                name=f"{rng.choice(['Ari', 'Noor', 'Théo', 'Mila', 'Sana', 'Léo'])} {parent_a.name.split()[-1]}",
                age=0,
                skill_level=round((parent_a.skill_level + parent_b.skill_level) / 2, 2),
                education_level=0.1,
                consumption_propensity=0.6,
                home_x=parent_a.home_x, home_y=parent_a.home_y,
                grid_x=parent_a.home_x, grid_y=parent_a.home_y,
            )
            citizens[new_id] = child
            world.births_total += 1
            world.log(f"{parent_a.name} and {parent_b.name} had a child: {child.name}.")


def drift_education(citizens: dict[int, Citizen], world: WorldState) -> None:
    """Education funding pulls the population's education level toward a
    target proportional to funding — slow drift, not per-citizen schooling
    simulation (that's a Phase 3+ refinement if pursued further)."""
    target = 0.3 + 0.6 * world.education_funding_level
    for citizen in citizens.values():
        if not citizen.alive:
            continue
        citizen.education_level += (target - citizen.education_level) * 0.01


def process_crime(citizens: dict[int, Citizen], world: WorldState, rng: random.Random) -> None:
    """Crime rate driven by unemployment and inequality (Gini) — both
    well-supported correlates in real criminology, kept as a simple linear
    model here rather than a policing/deterrence simulation."""
    world.crime_rate = max(0.0, min(1.0, 0.05 + 0.4 * world.unemployment_rate + 0.3 * world.gini_estimate))
    if world.crime_rate > 0.35 and rng.random() < 0.1:
        victim_pool = [c for c in citizens.values() if c.alive]
        if victim_pool:
            victim = rng.choice(victim_pool)
            loss = min(victim.wealth * 0.2, 150)
            victim.wealth -= loss
            victim.happiness = max(0.0, victim.happiness - 0.1)
            world.log(f"Crime incident: {victim.name} lost {loss:.0f} in wealth (high crime_rate={world.crime_rate:.2f}).")
            cognition.bump_salience(victim, 0.4, f"{victim.name} was a victim of crime and lost {loss:.0f}.", world, "crime_victim")


def tick(citizens: dict[int, Citizen], companies: dict, world: WorldState, rng: random.Random, next_id_fn) -> None:
    age_population(citizens, companies, world)
    process_mortality(citizens, companies, world, rng)
    process_marriages(citizens, world, rng)
    process_births(citizens, world, rng, next_id_fn)
    drift_education(citizens, world)
    process_crime(citizens, world, rng)
    world.population = sum(1 for c in citizens.values() if c.alive)
