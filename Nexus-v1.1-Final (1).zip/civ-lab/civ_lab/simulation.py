"""
Simulation orchestrator — Phase 2-5. Owns world state and wires together
every subsystem module in a fixed per-tick order:

  1. economy.tick        wages, spending, hiring/firing, prices, inflation
  2. society.tick         aging, marriage, birth/death, education, crime
  3. politics.tick         approval, elections, protests
  4. cognition pass        Tier-2 LLM reasoning for high-salience agents

Sandbox mutations (apply_sandbox_variable) and world events
(trigger_event) write into the same state every module above reads —
there is no special "sandbox propagation" code path anywhere in this
file. That's deliberate: it's the mechanism the architecture doc
describes and Phase 1 already proved for the economy alone.
"""

from __future__ import annotations
import random
from .models import Citizen, Company, WorldState, Party
from . import economy, society, politics, events as events_module, city
from .llm import LLMClient, create_llm_client, ResilientLLMClient
from . import cognition
from . import advanced


class Simulation:
    def __init__(self, seed: int = 42, llm: LLMClient | None = None):
        self.rng = random.Random(seed)
        self.citizens: dict[int, Citizen] = {}
        self.companies: dict[int, Company] = {}
        self.parties: dict[int, Party] = politics.seed_parties()
        self.world = WorldState()
        self._next_citizen_id = 1
        self.city_layout: city.CityLayout | None = None  # set by seed.build_default_simulation
        # Auto-detects ANTHROPIC_API_KEY (see llm.create_llm_client / .env.example);
        # falls back to MockLLMClient with zero configuration needed. See llm.py.
        self.llm: LLMClient = llm or create_llm_client()

    def _allocate_citizen_id(self) -> int:
        self._next_citizen_id = max(self._next_citizen_id, max(self.citizens, default=0) + 1)
        new_id = self._next_citizen_id
        self._next_citizen_id += 1
        return new_id

    def step(self, n: int = 1) -> None:
        for _ in range(n):
            self.world.tick += 1
            economy.tick(self.citizens, self.companies, self.world, self.rng, layout=self.city_layout)
            society.tick(self.citizens, self.companies, self.world, self.rng, self._allocate_citizen_id)
            politics.tick(self.citizens, self.parties, self.world, self.rng)
            cognition.run_cognition_pass(self.citizens, self.companies, self.world, self.llm,
                                          layout=self.city_layout, rng=self.rng, parties=self.parties)
            advanced.tick_finance(self.citizens, self.companies, self.world, self.rng)
            advanced.tick_government(self.citizens, self.companies, self.world, self.rng)
            advanced.tick_society_network(self.citizens, self.world, self.rng)
            advanced.tick_generations(self.citizens, self.companies, self.world, self.rng, self._allocate_citizen_id)
            advanced.tick_environment_and_technology(self.citizens, self.companies, self.world, self.rng)
            advanced.tick_international(self.world, self.rng)
            advanced.record_macro(self.world)
            self.world.replay_history.append({"tick": self.world.tick, "stats": self.stats()})
            self.world.replay_history[:] = self.world.replay_history[-2000:]
            city.tick(self.citizens, self.companies, self.world, self.city_layout, self.rng)

    def llm_status(self) -> dict:
        client = self.llm
        primary = client.primary if isinstance(client, ResilientLLMClient) else client
        provider = getattr(primary, "provider_name", type(primary).__name__)
        model = getattr(primary, "model", "deterministic")
        is_mock = type(primary).__name__ == "MockLLMClient"
        return {
            "mode": "mock" if is_mock else "real",
            "provider": provider,
            "model": model,
            "fallback": bool(getattr(client, "failed_over", False)),
            "last_error": getattr(client, "last_error", None),
            "calls_today": self.world.llm_calls_today,
            "calls_total": self.world.llm_calls_total,
            "daily_limit": self.world.max_cognitions_per_day,
        }

    # ---- Sandbox: instant, arbitrary variable modification ----

    def apply_sandbox_variable(self, path: str, value) -> str:
        """
        path examples:
          "world.interest_rate" | "world.tax_rate" | "world.healthcare_funding_level"
          "company.3.wage_budget_per_head"
          "citizen.7.wealth"
        """
        parts = path.split(".")
        scope = parts[0]

        if scope == "world":
            field = parts[1]
            if not hasattr(self.world, field):
                raise ValueError(f"Unknown world field: {field}")
            setattr(self.world, field, value)
            msg = f"SANDBOX: world.{field} set to {value}"

        elif scope == "company":
            company_id = int(parts[1])
            field = parts[2]
            company = self.companies[company_id]
            if not hasattr(company, field):
                raise ValueError(f"Unknown company field: {field}")
            setattr(company, field, value)
            msg = f"SANDBOX: company {company.name}.{field} set to {value}"

        elif scope == "citizen":
            citizen_id = int(parts[1])
            field = parts[2]
            citizen = self.citizens[citizen_id]
            if not hasattr(citizen, field):
                raise ValueError(f"Unknown citizen field: {field}")
            setattr(citizen, field, value)
            msg = f"SANDBOX: citizen {citizen.name}.{field} set to {value}"

        else:
            raise ValueError(f"Unknown sandbox scope: {scope}")

        self.world.log(msg)
        return msg

    def trigger_event(self, event_name: str, severity: float = 0.5) -> str:
        return events_module.trigger_event(self.world, self.citizens, event_name, severity, self.rng, self.companies)

    # ---- Read helpers for the API layer ----

    def stats(self) -> dict:
        w = self.world
        ruling_party = self.parties.get(w.ruling_party_id) if w.ruling_party_id else None
        return {
            "tick": w.tick,
            "gdp": round(w.gdp, 2),
            "unemployment_rate": round(w.unemployment_rate, 4),
            "inflation": round(w.inflation, 4),
            "interest_rate": w.interest_rate,
            "tax_rate": w.tax_rate,
            "avg_happiness": round(w.avg_happiness, 3),
            "avg_wealth": round(w.avg_wealth, 2),
            "gini_estimate": round(w.gini_estimate, 3),
            "crime_rate": round(w.crime_rate, 3),
            "government_budget": round(w.government_budget, 2),
            "government_approval": round(w.government_approval, 3),
            "ruling_party": ruling_party.name if ruling_party else None,
            "population": w.population,
            "births_total": w.births_total,
            "deaths_total": w.deaths_total,
            "marriages_total": w.marriages_total,
            "active_companies": sum(1 for c in self.companies.values() if not c.is_bankrupt),
            "bankrupt_companies": sum(1 for c in self.companies.values() if c.is_bankrupt),
            "active_events": {name: eff["severity"] for name, eff in w.active_event_effects.items()},
            "llm_calls_total": w.llm_calls_total,
            "llm_calls_today": w.llm_calls_today,
            "max_cognitions_per_day": w.max_cognitions_per_day,
            "llm_input_tokens_total": w.llm_input_tokens_total,
            "llm_output_tokens_total": w.llm_output_tokens_total,
            "llm_estimated_cost_usd": round(w.llm_estimated_cost_usd, 4),
            "tier2_decisions_total": w.tier2_decisions_total,
            "llm_mode": self.llm_status()["mode"],
            "llm_provider": self.llm_status()["provider"],
            "llm_model": self.llm_status()["model"],
            "llm_fallback": self.llm_status()["fallback"],
            "housing_price_index": round(w.housing_price_index, 2),
            "stock_market_index": round(w.stock_market_index, 2),
            "poverty_rate": round(w.poverty_rate, 4),
            "polarization": round(w.polarization, 4),
            "social_cohesion": round(w.social_cohesion, 4),
            "productivity_index": round(w.productivity_index, 2),
            "trade_balance": round(w.trade_balance, 2),
            "exchange_rate": round(w.exchange_rate, 4),
            "energy_price": round(w.energy_price, 3),
            "government_debt": round(w.government_debt, 2),
            "infrastructure": round(w.infrastructure, 3),
            "environmental_quality": round(w.environmental_quality, 3),
            "technology_progress": round(w.technology_progress, 3),
        }
