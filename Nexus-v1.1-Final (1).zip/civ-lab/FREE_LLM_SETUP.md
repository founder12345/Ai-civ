# Nexus — Free AI Cognition Setup

Nexus does not require a paid LLM. The recommended order is:

## Option A — Local Qwen3 with Ollama (best for unlimited/private use)

1. Install Ollama: https://ollama.com/
2. Pull the model:

```bash
ollama pull qwen3:8b
```

3. In `.env`:

```env
LLM_PROVIDER=ollama
OLLAMA_MODEL=qwen3:8b
```

4. Start Nexus.

The backend automatically talks to Ollama at `http://127.0.0.1:11434/v1`.

For a stronger machine, change the model to a larger Qwen3 variant.

## Option B — OpenRouter free routing (best if local inference is too heavy)

1. Create an OpenRouter API key.
2. In `.env`:

```env
LLM_PROVIDER=openrouter
OPENROUTER_API_KEY=your_key_here
OPENROUTER_MODEL=openrouter/free
```

3. Restart the backend.

The free router can select from currently available free models. Free quotas are rate-limited and can change.

## Automatic mode

Use:

```env
LLM_PROVIDER=auto
```

Nexus tries local Ollama first, then OpenRouter if configured, then Anthropic if configured, and finally the deterministic mock.

The UI's status panel shows exactly which provider/model is active.
