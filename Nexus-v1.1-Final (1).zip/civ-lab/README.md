# Nexus — AI Civilization Simulation v1.1

## Running it locally

**One command (starts both the backend and the frontend server):**
```
./run_dev.sh
```
Then open **http://localhost:8080/city.html**. Ctrl+C stops both servers.

**Or two commands, if you prefer to see each service separately:**
```
pip install -r requirements.txt
python3 api.py                 # terminal 1 — simulation backend on :5001
python3 -m http.server 8080    # terminal 2 — static frontend on :8080
```
Then open http://localhost:8080/city.html.

No build step, no npm — `city.html` is a single dependency-free static
file. A small **dev status panel** (bottom-right "⚙ status" button, or
top-left if something's wrong) shows SIMULATION/RENDERER/CITIZENS/TICK/
MODE live, and auto-opens with a red "OFFLINE — is `python3 api.py`
running?" message if the backend isn't reachable — so a blank page never
just silently fails.

**AI cognition modes:** Nexus now has a free-first provider chain. Set `LLM_PROVIDER=auto` (the default):

1. **Ollama + Qwen3 locally** — fully free after the model download, private, and not rate-limited by an API vendor. Ollama exposes an OpenAI-compatible `/v1/chat/completions` API, and Qwen3 is available in multiple sizes.
2. **OpenRouter free router** — if `OPENROUTER_API_KEY` is present, Nexus can use `openrouter/free` to route across currently available free models. Free quotas are rate-limited and can change.
3. **Anthropic** — if `ANTHROPIC_API_KEY` is configured.
4. **Mock** — deterministic offline fallback, so a provider outage never kills the simulation.

For the easiest zero-cost cloud setup, create an OpenRouter key, then set `OPENROUTER_API_KEY` and leave `OPENROUTER_MODEL=openrouter/free`. For a completely local setup, install Ollama and run `ollama pull qwen3:8b`; then start Nexus normally.

> **Important:** these are capable reasoning models, not literal AGI. Nexus treats the model as a bounded decision-making component: the model proposes a structured action and the deterministic simulation validates and applies it.

The live status panel now reports the provider, model, fallback state, and daily cognition usage. `/llm/status` exposes the same information for diagnostics.

## ## The economic model

Households, businesses, and government form one closed loop each tick (1
tick = 1 simulated hour). This is what actually drives employment, wealth,
and GDP — not scripted events, the events just perturb it.

```
BUSINESSES pay WAGES
    -> HOUSEHOLD INCOME (net of tax)
    -> HOUSEHOLD CONSUMPTION (spent mainly from income, a small draw from savings)
    -> BUSINESS REVENUE (split by capacity x price-competitiveness)
    -> BUSINESS WAGES (next tick)
```

Two additional flows close the loop rather than leaking money out of it:

- **Government**: tax collected on wages funds unemployment support
  (deficit-financed up to a bound during downturns, like a real automatic
  stabilizer) and, once its budget exceeds a target level, spends the
  surplus back into business revenue (`government_purchases`) instead of
  letting tax revenue just accumulate unused.
- **Business formation**: companies can go bankrupt (real risk, not
  prevented), and a small, personality-gated (risk tolerance), wealth-
  validated chance exists each tick for a citizen to found a new one —
  Tier-0/1, no LLM required — so total employment capacity isn't a fixed
  ceiling that only ever shrinks.

Revenue splits between companies by `headcount x (1/price_level)` — a
bigger company captures proportionally more demand at a given price, not
an equal share regardless of scale. Prices adjust based on *profit margin*
relative to a company's own wage bill (not a fixed absolute number), so
this scales correctly for both a 2-person startup and a 9-person company.

None of this guarantees a perfectly flat economy — recessions, bankruptcy
waves, and unemployment spikes still happen and are meant to. What it
guarantees is that a downturn isn't structurally irreversible. See
HANDOFF.md for the specific bugs that used to make it irreversible (an
aging-clock miscalibration and two "phantom employment slot" bugs where
dead or retired citizens permanently blocked rehiring) and the population-
scale test results (it's notably more self-correcting at 500+ citizens
than at 50).

# Deployment

## Recommended: single Render Web Service (no database)

This is the primary supported path — one Flask service serves both the
API and `city.html` (and `dashboard.html`) from the same origin, so
there's nothing to separately host or point at each other.

**Files involved**: `render.yaml`, `requirements.txt` (now includes
`gunicorn`), `api.py` (reads `PORT` and binds `0.0.0.0`), `city.html`
(defaults its API base URL to `location.origin` in production — see
below).

### Exact steps on Render
1. Push this project to a GitHub repo.
2. In Render: **New → Blueprint**, point it at the repo. Render reads
   `render.yaml` automatically and creates the service — build command,
   start command, and Python version are already set.
   (Or **New → Web Service** manually with: build command
   `pip install -r requirements.txt`, start command
   `gunicorn api:app --bind 0.0.0.0:$PORT --workers 1 --threads 8 --timeout 120`.)
3. Leave `ANTHROPIC_API_KEY` unset — the app runs on `MockLLMClient` with
   zero configuration. To enable real Tier-2 cognition later, add
   `ANTHROPIC_API_KEY` in the Render dashboard's environment variables
   (never commit it) and redeploy; `civ_lab/llm.py`'s `create_llm_client()`
   picks it up automatically, no code change needed.
4. Deploy. Render gives you a URL like `https://ai-civilization-lab.onrender.com`.
5. Open that URL directly — `/` serves `city.html`, already pointed at
   its own origin for the API (see below), so it just works.

### Why single-worker, no database
The simulation and any running Experiment Mode jobs live in this
process's memory — that's the existing architecture, unchanged. Multiple
Gunicorn worker *processes* would each hold their own disconnected copy
of the world, silently corrupting state depending on which worker
answers a given request. `--workers 1 --threads 8` keeps one shared
memory space while still handling concurrent requests (multiple browser
tabs, background experiment polling) via threads. No Postgres, no Redis
— intentionally, matching the project's current phase.

### How the frontend finds the API automatically
`city.html` resolves its backend URL at runtime (no build step involved),
in this order:
1. `?api=https://your-backend.example.com` query param (persists to
   `localStorage` after the first visit)
2. `window.CIV_LAB_API_URL` — set this in a tiny `<script>` tag before
   `city.html`'s main script for a fixed default baked into a deployment
3. Whatever was saved in `localStorage` from a previous visit
4. **`location.origin`** — this is what makes the single-Render-service
   setup work with zero configuration: since Flask serves `city.html`
   itself, the page's own origin IS the API's origin.
5. `http://localhost:5001` — but only as a fallback specifically when
   the page is being served from port 8080, the known local-dev static-
   server port (see "Running it locally" above) where the frontend and
   API are deliberately on different ports.

Both the local two-port dev flow and the single-origin production flow
were tested directly (see "Local production test results" below) — this
isn't inferred, it's verified behavior in each case.

## Vercel + Render (why this is the right split for Vercel specifically)

**Vercel cannot run the backend as-is.** This app's architecture depends
on one persistent process holding the simulation in memory (`sim` as a
global) and running Experiment Mode jobs in background threads over
minutes. Vercel runs Python as stateless serverless functions with no
guaranteed memory between requests — ticks would reset unpredictably and
a multi-year experiment would vanish the moment its triggering request
ended. Making the backend actually correct on Vercel would mean moving
all state into an external store (Postgres/Redis), which is explicitly
out of scope for this phase.

**What Vercel IS good at here: hosting `city.html`/`dashboard.html` as a
static site.** `vercel.json` is already set up for exactly this (routes
`/` to `city.html`, keeps `/dashboard.html` reachable, adds baseline
security headers). Steps:

1. Deploy the backend to Render first (see above) — you need its URL.
2. Push this repo to Vercel (Import Project → it detects the static
   files automatically, no build command needed).
3. Open your Vercel URL once with `?api=` pointing at your Render backend:
   `https://your-project.vercel.app/?api=https://your-backend.onrender.com`
   — this is saved to `localStorage`, so every visit after that first one
   resolves automatically with no query param needed. Verified directly:
   reloading the page without `?api=` still correctly used the saved
   backend.
4. On the Render side, set `ALLOWED_ORIGINS=https://your-project.vercel.app`
   (see Security below) so the backend only accepts requests from your
   actual frontend once you know its URL.

## Alternative: any other static host
The same pattern works with Netlify, GitHub Pages, S3, etc. instead of
Vercel — host `city.html`/`dashboard.html` anywhere static, point it at
the Render backend the same way.

## Security
- **API keys**: `ANTHROPIC_API_KEY` is only ever read from the environment
  (`civ_lab/llm.py`), never hardcoded, never returned by any endpoint —
  verified by checking every response body. `.env` is git-ignored;
  `.env.example` has no real values.
- **CORS**: configurable via `ALLOWED_ORIGINS` (comma-separated), defaults
  to `*` so nothing breaks with zero config. Set it once you know your
  frontend's real domain — verified directly that a request with a
  non-matching `Origin` header gets no CORS header back (blocked), while
  a matching one is allowed.
- **Rate limiting**: mutating/expensive endpoints (`/tick`, `/reset`,
  `/sandbox/*`, `/experiment/create`) are rate-limited per-IP (no
  external dependency — in-memory, matching the project's "no Redis"
  stance). `/experiment/create` is limited tightest (5 per 5 minutes)
  since each call spawns a real background compute thread. Verified
  directly: the 11th call within a 10-per-60s window gets HTTP 429.
- **XSS**: the one genuinely user-controlled string that reaches the
  page (the Experiment Mode name field) is HTML-escaped before
  rendering — verified directly by submitting `<img src=x
  onerror=alert(1)>` as an experiment name and confirming it rendered as
  inert text with no alert firing. Citizen/company names aren't
  user-input (generated server-side from a fixed name list), so they
  weren't a risk to begin with.
- **Headers**: `X-Content-Type-Options`, `X-Frame-Options`,
  `Referrer-Policy` set on every response (both the Flask backend and,
  via `vercel.json`, the static frontend if deployed there).

## Local production test results
Gunicorn itself couldn't be installed to test directly in the sandboxed
environment this was built in (no outbound network access there) — this
is a real limitation, not glossed over. What WAS tested directly: the
exact same `api.py`/`app` object Gunicorn would serve, run with the
exact production configuration (`PORT` env var, `0.0.0.0` binding,
`city.html` served from the same origin as the API, no separate static
server), via Flask's own dev server standing in for Gunicorn at the
application level — this validates routing, CORS, static file serving,
and the same-origin API resolution, all of which are identical
regardless of which WSGI server runs the `app` object; it does not
validate Gunicorn's specific process/worker behavior itself.

Confirmed working this way, via curl and a real headless browser: all 13
core routes (`/`, `/world/stats`, `/world/events`, `/citizens`,
`/citizens/<id>`, `/companies`, `/city/layout`, `/city/citizens`,
`/dashboard.html`, `POST /tick`, `POST /sandbox/event`,
`POST /sandbox/variable`, `POST /reset`) and all 5 Experiment Mode routes
(`create`/`status`/`results`/`export`/`list`) returned correct responses;
a real browser opened at the single production origin correctly resolved
`API` to that same origin with zero console errors; and the full
interactive sequence — select a citizen, open Citizen Life Mode, trigger
a recession, open Research Mode, run an experiment to completion — worked
end to end with zero errors throughout.

---

A running simulation with an economy, a society, a political system,
Tier-2 LLM cognition, Experiment Mode, world events, and a live dashboard
— built on top of the Phase 1 core loop, per the architecture roadmap.

**Honest framing:** this is a strong, working prototype of the system
described in `ai-civilization-lab-architecture.md`, not the full
thousands-of-agents research platform — that's realistically a multi-week
build. What changed since Phase 1: the economy is no longer alone. Society
(aging, marriage, birth/death, crime), politics (parties, elections,
approval, protests), Tier-2 cognition (salience-gated LLM reasoning with
retrieved memory), injectable world events, and controlled Experiment Mode
runs are all wired in and tested together over long horizons (26,000+
ticks) — see HANDOFF.md for the specific economic stability work.

## What's here

```
civ_lab/
  models.py       Citizen, Company, Party, WorldState, MemoryEntry
  economy.py       Tier 0/1: wages, spending, hiring/firing, prices, inflation
  society.py        Tier 0/1: aging, marriage, birth/death, education, crime
  politics.py        Tier 0/1: parties, elections, approval, protests
  events.py           World events: pandemic/recession/disaster/tech — sandbox-injectable
  memory.py            Episodic memory store + retrieval (bag-of-words, see note below)
  llm.py                 Pluggable LLM boundary: MockLLMClient (offline) / AnthropicLLMClient (real)
  cognition.py           Tier-2: salience scoring + LLM reasoning pass for high-priority agents
  simulation.py           Orchestrator — wires all of the above into one tick loop + sandbox
  seed.py                  Generates 50 citizens, 8 companies, 3 parties
run_simulation.py    Headless CLI run — 320 ticks, election, injected pandemic, cognition output
api.py                Flask API exposing the simulation
dashboard.html          Single-file live dashboard (charts, population grid, sandbox controls,
                        per-citizen inspector) — polls the API, no build step required
requirements.txt
```

## Run it

```bash
pip install -r requirements.txt

# Headless — see 320 ticks evolve in your terminal, including an
# election and an injected pandemic
python3 run_simulation.py

# Live — API + dashboard
python3 api.py
# then open dashboard.html directly in a browser (or visit http://localhost:5001/)
```

The dashboard lets you: step the simulation (1/10/50 ticks or auto-run),
watch GDP/unemployment/happiness/crime/approval charts update live, click
any citizen dot to open their full inspector (biography, goals, predicted
actions, last reasoning trace, recent memories), see which party is in
power and its approval, drag sliders for interest rate / tax rate /
healthcare & education funding, and unleash a pandemic / recession /
natural disaster / tech breakthrough at a chosen severity.

## What's actually proven to work (tested this session)

- **300+ tick stability** across all four subsystems running together, no
  crashes, no runaway divergence.
- **Elections that matter**: at t=200 in the test run, Liberty Coalition
  unseated Progressive Alliance; tax policy shifted in response.
- **Sandbox propagation with zero special-casing**, now across more than
  just economy: a pandemic event depresses `healthcare_funding_level` and
  consumer demand, which cascades into unemployment, crime, and happiness
  — same mechanism Phase 1 proved for interest rates.
- **Tier-2 cognition end to end**: salience accumulates from real events
  (job loss, marriage, bankruptcy, election, crime victimization) →
  top-N agents by salience get a memory-retrieval + prompt-construction +
  LLM-call pass each tick → results (reasoning text, new goals, predicted
  actions) are written back to citizen state and shown in the inspector.
  In the test run, 27 of 48 living citizens had a completed cognition
  pass by tick 320.
- **Society dynamics**: marriages, births, deaths, retirement, and a
  crime rate that responds to unemployment and inequality all fired
  correctly in testing.

## Known limitations (documented, not hidden)

- **No real LLM calls were made in this environment** — no network access
  here. `MockLLMClient` (regex-templated responses) proves the full
  cognition pipeline runs correctly; swap in `AnthropicLLMClient` (real,
  written, untested-here code in `llm.py`) locally with an API key and
  cognition becomes real reasoning with no other code changes.
- **Memory retrieval is bag-of-words, not embeddings** — same reason
  (no network to call an embedding model). `memory.py` implements the
  same `retrieve()` contract a real vector store would; swapping the
  scoring internals for real embeddings doesn't touch any caller.
- **In-memory state, not Postgres**; Flask, not FastAPI — both are the
  no-network-access substitution noted in the Phase 1 README, unchanged.
- **No interactive world map** — the dashboard's population grid gives
  you clickable per-citizen inspection, but there's no geography/spatial
  layer yet. Would need a real frontend build (Next.js + deck.gl per the
  architecture doc) which needs npm registry access this environment
  doesn't have.
- **Ideology is a single left-right axis**, not multi-dimensional. Election
  and party-approval mechanics are simplified (linear economic + ideological
  voting), not a full public-choice model.
- **~2,000 lines total** — enough to demonstrate every mechanism in the
  architecture doc end-to-end at 50-citizen scale, not yet load-tested or
  optimized for thousands of agents (the salience-gating mechanism that
  makes that tractable is implemented and working, just not stress-tested
  at that population size).

## What's genuinely left for a "full platform"

1. Real LLM wiring (needs your API key + network — 1 line of code once you have both)
2. Real vector embeddings for memory (same — needs network access to an embedding API)
3. Postgres persistence so the simulation survives a restart
4. A built frontend (Next.js/React) with an actual interactive world map
5. Stock/housing markets, supply chains, multi-axis political ideology
6. Load testing and salience-threshold tuning at 1,000+ citizen scale

---

## Phase 2 update: the visual city

`city.html` turns the headless simulation into a browser-based pixel-art
town, per the Phase 2 spec — built on top of the existing Phase 1-5
backend, which was **not** rewritten (only additive: new dataclass
fields with safe defaults, a new `city.py` module, four new event
types, and one new line in `simulation.py`'s step loop).

**Architectural substitution, explained upfront and still true:** no
React/TypeScript/Vite/PixiJS — this sandbox has no npm registry access,
so that build pipeline cannot run here. Instead: vanilla JS + HTML5
Canvas 2D in a single file, no build step, same pattern as
`dashboard.html`. Citizens are procedurally-composed pixel sprites
(layered rectangles: body/head/hair, colored by profession + a
deterministic per-ID hash for skin/hair) rather than image assets,
since no image-generation tool was available either.

**What it does, tested end-to-end this session:**
- Procedurally generated city: roads, sidewalks, a river, houses, shops,
  offices, factories, a hospital, school, bank, city hall, and parks —
  sized dynamically so there's always enough housing for the population
  (a real bug from the first pass: companies were colliding on one tile
  and there weren't enough house lots — both fixed and reverified).
- Every citizen has a real home and (if employed) a real workplace on
  the grid, and follows an hourly schedule (sleep → commute → work →
  lunch → work → commute → social → sleep) that's visibly synced to the
  backend's tick counter.
- Click any citizen sprite → inspector with bio, wealth/income, current
  thought (state-derived, not LLM — see Phase 2 spec), goals, the
  Tier-2 LLM reasoning trace from Phase 2's cognition system, spouse +
  coworker relationships, and life events pulled from the existing
  memory store.
- Speed controls (pause/1x/2x/5x/10x/50x), pan/zoom camera, and an
  economic experiments panel wired to real backend events: recession,
  boom, pandemic, disaster, bank failure, housing crash, mass layoffs,
  tech breakthrough, an interest-rate shock, and an inflation spike —
  each one visibly changes hiring/layoffs/wealth/happiness in the world
  because it's the same sandbox mechanism proven in Phase 1, not a
  frontend-only effect.
- A secondary analytics panel (mini stats + 2 live charts) stays
  present but subordinate to the city view, per spec; the full
  Phase 1-5 dashboard is still one click away at `/dashboard.html`.

**Run it:** `python3 api.py`, then open `http://localhost:5001/` (serves
`city.html` directly; no separate frontend server or build step needed).

**Honest gaps against the original Phase 2 spec:**
- No true sprite animation (idle/walking frame cycling) — sprites move
  via smooth position interpolation, not animated limbs.
- "Friends" aren't modeled as a relationship type — only spouse and
  coworkers are tracked (that's what the backend actually has); the
  inspector shows exactly that rather than fabricating a friends list.
- Movement is grid-based, one tile per backend tick, interpolated
  client-side for smoothness — not a full pathfinding/steering system.
- Verified as far as: backend logic, generated layout correctness,
  every API call the frontend makes matching a real route, JS syntax
  validity (checked with `node --check`), and full HTML/HTTP
  integration testing via curl simulating the exact call sequence the
  browser makes. What I could **not** do is visually render the canvas
  myself — there's no browser in this sandbox — so open it and tell me
  if the sprites/layout look wrong; I can't see it, and something
  small could be off in a way pure logic-testing wouldn't catch.

## Nexus v1.0 — civilization systems

The project now includes a bounded advanced layer on top of the original simulation:

- household finance: deposits, credit scores, loans and interest
- dynamic housing-price index and household housing values/rent
- equity market and company stock prices
- government automatic stabilizers, debt, infrastructure and approval feedback
- social network graph, trust, cohesion and polarization metrics
- generational inheritance, family links, births and career progression
- technology/productivity, energy prices, emissions and environmental quality
- open-economy trade balance and exchange-rate dynamics
- rolling macro history and replay history for analytics
- SQLite checkpoints with RNG/city restoration
- analytics endpoints for history, replay, relationships and society overview
- deterministic SHA-256 experiment fingerprints

The architecture remains simulation-authoritative: LLM cognition proposes decisions, while deterministic systems validate and apply state changes.

## Verification

The project includes a dependency-light regression suite:

```bash
python -m compileall -q .
python critical_test.py
python test_suite.py
python run_simulation.py
```

The suite covers core simulation execution, personality-divergent cognition, deterministic same-seed behavior, sandbox propagation, and GDP response to a severe demand shock. The production API additionally exposes `/health` for Render health checks.

## Security

Never commit `.env` or API keys. `.env.example` contains placeholders only. For a public deployment, set `ALLOWED_ORIGINS` to the exact frontend origin and keep mutating endpoints behind the built-in rate limiter.
