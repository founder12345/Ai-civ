"""Fast, dependency-light regression tests for Nexus core systems."""
from civ_lab.seed import build_default_simulation
from civ_lab.models import EmploymentStatus


def test_core_simulation():
    sim = build_default_simulation(n_citizens=50, n_companies=8, seed=42)
    sim.step(120)
    assert sim.world.tick == 120
    assert sim.world.population > 0
    assert sim.world.gdp >= 0
    assert 0 <= sim.world.unemployment_rate <= 1
    assert 0 <= sim.world.avg_happiness <= 1


def test_gdp_reacts_to_demand_shock():
    sim = build_default_simulation(n_citizens=50, n_companies=8, seed=42)
    sim.step(20)
    baseline = sim.world.gdp
    sim.trigger_event("pandemic", 0.9)
    sim.step(20)
    shocked = sim.world.gdp
    # A severe demand shock should materially affect output over the next 20 ticks.
    assert shocked < baseline * 1.02, (baseline, shocked)


def test_cognition_diverges_by_personality():
    import critical_test
    critical_test.main()


def test_seed_reproducibility():
    a = build_default_simulation(n_citizens=50, n_companies=8, seed=123)
    b = build_default_simulation(n_citizens=50, n_companies=8, seed=123)
    a.step(80); b.step(80)
    assert a.stats() == b.stats()


def test_sandbox_propagates():
    sim = build_default_simulation(n_citizens=30, n_companies=5, seed=9)
    old = sim.world.tax_rate
    sim.apply_sandbox_variable("world.tax_rate", 0.35)
    assert sim.world.tax_rate != old
    sim.step(3)
    assert sim.world.tick == 3


if __name__ == "__main__":
    tests = [
        test_core_simulation,
        test_gdp_reacts_to_demand_shock,
        test_cognition_diverges_by_personality,
        test_seed_reproducibility,
        test_sandbox_propagates,
    ]
    for test in tests:
        test()
        print(f"PASS: {test.__name__}")
    print("ALL TESTS PASSED")
