# AI Civilization Lab — Handoff (end of session)

## 1. Current Project State
Phases 1-6 built and working: economy/society/politics simulation, procedural
zoned city, pixel-art renderer with Citizen Life Mode, Tier-2 agent cognition
with a validated action vocabulary, and Experiment Mode. Runs locally via
`./run_dev.sh` or the two-command setup in README.md. All changes below are
tested, not just written — see section 3.

**This session did two things: shipped Phase 6 (Experiment Mode), then, per
your explicit "audit the codebase, find the top weakness, fix it properly"
instruction, found and partially fixed a critical, previously-undetected
economic stability bug. That fix is the most important thing in this
handoff — read section 2 and 5 carefully.**

## 2. What Was Changed This Session

### Phase 6 — Experiment Mode (new)
- `civ_lab/experiment.py` (new) — `ExperimentConfig`/`ScheduledEvent`/
  `run_experiment()`. Builds one real `Simulation` (via `build_default_simulation`,
  same as everywhere else), runs it, records weekly snapshots, computes
  before/after stats, wealth/income percentile distributions, and
  "most affected citizens" lists. Supports 16 event types: the 8 already in
  `events.py` plus 8 new ones (inflation_shock, interest rate ±, tax ±,
  universal basic income, immigration shock, AI automation shock) implemented
  as direct, bounded WorldState/citizen writes — no second simulation engine.
- `api.py` — added `/experiment/create` (runs in a background thread so a
  multi-year run doesn't block Flask), `/experiment/status/<id>` (progress
  polling), `/experiment/results/<id>`, `/experiment/export/<id>?format=json|csv`,
  `/experiment/list`.
- `city.html` — new "🔬 Research Mode" panel: config form (population, years,
  seed, starting conditions, event timeline builder), live progress, results
  screen (before/after table, 3 time-series charts with event markers,
  wealth-distribution percentiles, most-affected citizen lists that open the
  existing Citizen Life Mode inspector, JSON/CSV export). Sits on top of the
  world view, doesn't replace it. Added `drawStaticChart()` — a separate
  lightweight chart function for pre-recorded experiment series, kept apart
  from the existing streaming `MiniChart` used by the live HUD.
- Reproducibility verified directly: same seed + same config → byte-identical
  `reproducibility_hash` and identical final GDP, confirmed by running the
  same config twice.

### Critical fix — economy death spiral (the important part)
Running an experiment longer than ~300 ticks (i.e., longer than any previous
phase had ever tested) revealed the economy reliably collapses to **100%
unemployment and 0 average wealth**, and never recovers. Traced to two real,
now partly-fixed bugs in `civ_lab/economy.py`:

1. **`pay_unemployment_support` was procyclical.** It capped payouts at
   whatever `government_budget` currently held, so the safety net got cut to
   zero exactly when a downturn had already drained the budget — the opposite
   of what unemployment insurance is for. **Fixed**: now deficit-financed up
   to a bounded ceiling (-30,000), like a real automatic stabilizer.
2. **`consumer_spending`'s formula was a calibration bug, not a tuning
   choice.** It spent `wealth * propensity * 0.15` every tick — verified with
   real numbers that this made an average citizen spend **~3x their income
   every single tick**, mechanically guaranteeing wealth erosion from tick 1
   regardless of any bankruptcy dynamics. **Fixed**: now spends mainly from
   income with a much smaller (2%) wealth drawdown — the economically correct
   shape (people spend mostly out of earnings, not out of their whole savings
   stock every hour).

**Both fixes are real, tested, and improve things** (see section 3), but they
do NOT fully solve the collapse. See section 5 for the remaining diagnosis.

## 3. Tests Performed (all actually run this session, not assumed)
- `python3 run_simulation.py` — passes, no exceptions, cognition/economy/
  society/politics all execute a full 320-tick run.
- `python3 critical_test.py` — passes: two citizens, identical income/age/
  job/shock, different risk_tolerance/wealth → different validated decisions
  (START_BUSINESS vs REDUCE_SPENDING).
- Experiment Mode tested live: real Flask backend + real headless-Chromium
  browser (Playwright) — config form, run, progress polling, results
  rendering, charts, citizen-linking, and export all confirmed working with
  **zero console/page errors**.
- Reproducibility: ran the identical experiment config twice, confirmed
  identical `reproducibility_hash` and identical final GDP.
- Economy fix validated with a tick-by-tick trace of the exact scenario that
  broke (50 citizens, seed=123) before and after each change.
- Full population scale test earlier in this session (50/500/1000/2500
  citizens) — all render/interact correctly; see prior handoff notes if
  preserved, or re-run if this document is all you have.

## 4. Known Issues / Limitations
- **The economy still eventually collapses to 100% unemployment on a long
  enough run** (confirmed out to 1 full year / 8,760 ticks post-fix, at 50
  citizens). The two fixes made it take longer and stabilize wealth for
  longer, but didn't eliminate it. See section 5 for exactly why.
- Frontend's citizen inspector still has a stale note claiming "debt isn't
  modeled" — it is (added in Phase 5) but isn't displayed. Cosmetic, not
  fixed (flagged, not critical).
- `run_dev.sh` — logic verified (its two component commands each tested
  successfully many times), but the wrapper script itself was never run to
  completion end-to-end due to this sandbox's background-process handling.
  Not a known code defect, just unverified.
- `AnthropicLLMClient` — code complete, never exercised against the real API
  (no network access in this sandbox).
- No Postgres (by design, per your instructions).

## 5. What Remains Incomplete — the exact next step
The wage bill and the consumer-spending pool are structurally mismatched at
the seed-parameter level, independent of the two bugs already fixed. Verified
with real numbers on the default 50-citizen/8-company seed:

```
total gross wage bill/tick:        ~2,783
total consumer spend pool/tick:      ~741
ratio:                              ~3.8x
total company target_headcount: 40 vs population 50
```

Companies are configured (via `seed.py`'s `wage_budget_per_head` range of
30-60 combined with `target_headcount` 3-9 across 8 companies) to pay out
roughly 4x more in wages than the same population's spending can ever
replenish, even at 100% consumption propensity. This is why the fixes in
section 2 delayed the collapse but didn't prevent it — I was correcting real
bugs downstream of a deeper parameter-calibration problem upstream.

**Recommended fix** (not yet attempted — ran out of session time, and this
needs careful testing across population sizes, which is exactly the kind of
thing your "do not rush" instruction calls for): rebalance `wage_budget_per_head`
in `seed.py` (or `target_headcount`, or company count) so aggregate wages
roughly match what aggregate consumer spending can sustain in a closed loop —
something like `total_wage_bill ≈ total_spend_pool` at equilibrium, likely
needing `wage_budget_per_head` reduced by roughly the same ~4x factor found
above, but that number needs validating against realistic income/wealth
*display* values too (a citizen earning "8/tick" looks broken in the UI even
if it's economically balanced) — this is a joint calibration problem, not a
single-constant fix.

**Test plan for that fix**: re-run the exact trace in section 3 (50 citizens,
seed=123, ticks up to 8760) and confirm unemployment stabilizes in a
reasonable band (say 5-15%) rather than climbing to 100%, then re-check
100/500/1000/2500-citizen populations for the same stability, then re-run the
full regression suite (`run_simulation.py`, `critical_test.py`) before calling
it done.

## 6. Exact Commands to Run the Project
```bash
cd civ-lab
pip install --user -r requirements.txt
python3 api.py                   # terminal 1
python3 -m http.server 8080      # terminal 2
```
Open `http://localhost:8080/city.html`. Dev status panel: bottom-right
"⚙ status" button. Research Mode: top-right "🔬 Research Mode" button.

## 8. Economic Calibration Session — Part 2: population-growth hypothesis investigated

Per your instruction, this was investigated with evidence before touching
code — the hypothesis as originally stated was **not quite right**, and the
evidence is below.

### What the diagnostic trace actually showed
Ran the exact 50-citizen/seed=123/8,760-tick scenario with full
instrumentation (population, employment, active companies, target
headcount, living headcount, bankruptcies, births, deaths every 500-1000
ticks). Population stayed roughly flat (33-45) throughout — **it did not
grow faster than capacity**. What actually happened: total company target
headcount shrank steadily from 40 to 0 as companies went bankrupt one by
one with **nothing ever replacing them**. The disable-births control test
(section 3 of your instructions) was confounded — freezing births caused
total population extinction from unreplenished aging within ~2,000 ticks,
a different failure mode — but it surfaced a decisive clue: at tick 1,000
there were 15 job slots for only 10 living citizens, yet employment was
0%. That flatly rules out "not enough jobs for the population."

### Root causes found (in order of investigation)
1. **`society.py`'s aging clock was 438x too fast.** `TICKS_PER_YEAR = 20`
   there, vs `8760` everywhere else in the codebase (`city.py`,
   `experiment.py`). An "8,760-tick year" was actually ~438 years of aging
   — citizens retired and died at a wildly inflated rate. The module
   docstring had explicitly flagged this dual-clock as a deliberate,
   deferred simplification from an earlier phase, not an oversight — but
   it's now clearly the dominant driver. **Fixed**: `TICKS_PER_YEAR = 8760`.
2. **Retirement had the same phantom-slot bug as death** (fixed last
   session for death, missed for retirement): `age_population()` sets a
   living citizen's status to RETIRED at 67+ but never removed them from
   `company.employee_ids`. Since `headcount = len(employee_ids)`, a
   retiree permanently occupies a slot forever — and `pay_wages` only
   checks `.alive`, not `.status`, so the company kept paying a retiree's
   wage indefinitely too. **Fixed**: retirement now frees the seat, same
   pattern as the death fix.
3. With both fixed, the 8,760-tick collapse was gone, but an extended
   26,000-tick trace showed it still eventually collapses — just ~6.5x
   slower (~tick 26,000 instead of ~4,000). At this point active companies
   were still shrinking to zero with **zero new companies ever created**
   (`total companies ever created: 8`, unchanged from seed) — confirming
   the real remaining gap was exactly what your step 7 anticipated: no
   endogenous (non-LLM) business formation.

### Business formation implemented (Tier-0/1, no LLM required)
New `economy.business_formation()`: eligible citizens (risk_tolerance >
0.6, no wealth pre-filter — see below) get a small per-tick chance to
found a business, scaled by an "opportunity" signal (how far total company
capacity has fallen below population). It reuses the *exact same*
validated `START_BUSINESS` action Tier-2 cognition already uses via
`actions.apply_action()` — same $1,000 startup cost, same failure
conditions, same bankruptcy risk. Zero code duplication.

Debugging this surfaced two more real, load-bearing bugs:
- **Eligibility deadlock**: requiring wealth ≥$2,000 AND risk_tolerance >
  0.6 left **zero** eligible candidates for most of a 26,000-tick run —
  verified directly that in this economy, wealthy and risk-tolerant are
  nearly mutually exclusive (cautious citizens save more via their own
  Tier-2 decisions; risk-tolerant ones spend/venture more). Fixed: dropped
  the wealth pre-filter — `apply_action` already validates affordability
  internally, so this isn't a duplicated check, it's removing a redundant
  and harmful one.
- **Zone lots were completely exhausted**: `layout.zone_lots` empties
  permanently during initial city generation. Verified directly (`{'civic_core':
  0, 'downtown': 0, 'industrial': 0, 'waterfront': 0, 'residential': 0}`)
  — meaning literally no new company could ever be placed on the map,
  regardless of any citizen's wealth. Fixed: a bankrupt company's tile is
  now returned to its zone's lot pool in `company_decisions`, so a new
  venture can occupy a vacated storefront — this is also just economically
  sensible on its own.
- **No cooldown**: without one, a single citizen whose venture failed
  instantly would re-attempt again next tick — verified one citizen
  created and lost 4 businesses in a few hundred ticks. Fixed: reuses
  `cognition_cooldown_until` (~1 month cooldown after any attempt).

### Results (50-citizen/seed=123/26,000-tick extended run)
| | Before this session | After all fixes |
|---|---|---|
| Collapse to 100% unemployment | ~tick 4,000 (~0.46 "years", pre-clock-fix) | ~tick 26,000 (~3 years) |
| Total companies ever created | 8 (never changes) | 15 (business formation genuinely active) |
| Recovery phases observed | None | Yes, at 50 citizens: partial; **at 500+ citizens: strong** |

### Population scaling test (100/500/1,000 citizens, ~1.5-year run each)
This is the most encouraging result: **business formation scales better
than the 50-citizen baseline suggests.**
- n=100: unemployment climbs to ~77% by tick 13,500 with modest company
  growth (16→28) — still trending toward collapse, weakly mitigated.
- **n=500: unemployment genuinely recovers** — rises to 70% by tick
  10,000, then *falls back* to 63.8% by tick 13,500 as total companies
  keep climbing (204→224). This is the "recession → recovery" pattern
  your acceptance criteria describe, and it emerged from the mechanism,
  not from any artificial floor.
- n=1000: similar early trajectory (unemployment 29.5%→42.6% over the
  tested window, company count climbing 160→171+); the full run wasn't
  completed in this session (time-boxed at 60s/population for this
  diagnostic pass) but shows the same qualitative pattern as n=500.

**Honest conclusion**: business formation is real and working, and scales
non-trivially better at larger populations (where there are simply more
absolute risk-tolerant candidates at any given tick, even at the same
population fraction). At the small 50-citizen scale specifically, it
delays collapse substantially but doesn't yet fully prevent it. This
should NOT be "fixed" by inflating the formation rate for small
populations specifically — that would be exactly the kind of artificial
tuning the instructions explicitly ruled out. It's an honest scale-
dependent limitation to hand off, not a bug.

### Tests performed
`run_simulation.py` and `critical_test.py` re-run and pass after every
individual change in this section (not just at the end). Live API
re-verified working (`/tick`, `/world/stats`) after all changes.

### Files changed this session
- `civ_lab/society.py`: `TICKS_PER_YEAR` 20→8760; `age_population()` and
  `process_mortality()` both now free the employee_ids seat and take
  `companies` as a parameter; `tick()` signature updated to match.
- `civ_lab/economy.py`: new `business_formation()`; `company_decisions()`
  now reclaims a bankrupt company's lot back into `zone_lots` and takes
  `layout` as a parameter; `tick()` signature updated to pass `layout`
  through.
- `civ_lab/simulation.py`: updated call sites for both of the above.

### 9. Full Population Sweep + Long-Run Economic Investigation (this session)

**Investigated before touching any code, per instructions.** Built an instrumented harness (`sweep_harness.py`, kept in the repo) that runs the real `Simulation`/`economy.tick()` unmodified, wrapping `actions.apply_action` and `economy.business_formation` to attribute every `START_BUSINESS` call to its actual source (Tier-0/1 rule-based formation vs Tier-2 cognition) without changing behavior — verified the attribution is exact (3 Tier-0/1 + 4 Tier-2 = 7 = the real company-count delta, checked directly).

### A. Population comparison table (seed=123, full 26,000 ticks except n=2500)
| Population | Final unemployment | Min unemployment | Max unemployment | Ever recovers long-term? | Final active companies | Total companies ever created |
|---|---|---|---|---|---|---|
| 50 | 100.0% | 28.9% | 100.0% | No | 4 | 15 |
| 100 | 93.8% | 38.0% | 93.8% | No | ~9 | 28 |
| 250 | 87.4% | 30.9% | 87.5% | No (small plateau only) | ~26 | 183 |
| 500 | 90.1% | 35.0% | 90.1% | No (temporary mid-run plateau) | 15 | 471 |
| 750 | 94.1% | 32.0% | 94.1% | No | ~30 | 871 |
| 1000 | 86.2% | 34.3% | 86.2% | No (temporary mid-run plateau) | 70 | 947 |
| 2500 | *(partial — see below)* | | | | | |

**n=2500 is incomplete.** At ~67ms/tick, a full 26,000-tick run costs ~29 minutes of pure compute — this session's tool-call time limit is well under that. Built checkpoint/resume capability specifically for this (`sweep_harness.py`'s `run_chunk`, pickles simulation state between calls) and got to **tick 8,000 of 26,000** before redirecting remaining time to completing the rest of this investigation, which was the higher priority. The checkpoint (`/tmp/ckpt_2500.pkl`, not included in the delivered zip since it's a large binary artifact) can be resumed by whoever continues this.

### B. 1,000-citizen complete trajectory
Full 13-checkpoint trajectory (every 2,000 ticks) recorded. Unemployment: 34.3% → 39.2% → 54.6% → 65.1% → 71.1% → 69.9% → 65.5% → 64.3% → 73.2% → 75.9% → 79.2% → 83.1% → 86.2%. Total companies ever created grew from 160 (seed) to 947; active (non-bankrupt) companies peaked around 139 near tick 16,000 then declined to 70 by tick 26,000.

### C. Minimum viable population: **NOT supported by the data — revised finding below**
The original hypothesis (below some N it collapses, above some N it's stable) is **not what the complete data shows**. Every population from 50 to 1,000 follows the same qualitative shape: unemployment climbs from a healthy ~30% baseline toward 87-100% given enough time, with larger populations only taking longer in absolute ticks to get there — not reaching a different, stable outcome. **The earlier session's "500-1,000 citizens show recovery" observation was real but incomplete**: it was looking at a partial window (up to ~13,500 ticks) that happened to catch a temporary plateau (visible at n=500: unemployment briefly eases from 70.0%→64.3% around ticks 10,000-16,000) that is followed by continued decline all the way to 90%+ by tick 26,000 in the complete trajectory. This was a genuine finding at the time, just not evidence of long-run stability.

### D. Business formation statistics
| Population | Tier-0/1 attempts | Tier-0/1 successes | Tier-2 cognition attempts | Tier-2 cognition successes | Success rate |
|---|---|---|---|---|---|
| 50 | 296 | 3 | 4 | 4 | 2.3% |
| 100 | 488 | 2 | 10 | 10 | 2.4% |
| 250 | 1,439 | 100 | 43 | 43 | 9.6% |
| 500 | 3,733 | 308 | 83 | 83 | 10.2% |
| 750 | 5,293 | 562 | 189 | 189 | 12.2% |
| 1,000 | 7,402 | 652 | 135 | 135 | 9.6% |

Both pathways contribute — the pre-existing Tier-2 cognition mechanism (MockLLMClient choosing `START_BUSINESS` for a wealthy, risk-tolerant, salient citizen) creates real companies too, not just the new Tier-0/1 mechanism. **Attempt rate normalized by population × ticks is roughly constant across all sizes (0.000188-0.000287)** — confirms the mechanism scales proportionally with population as designed, not a scaling bug. The larger-population "improvement" observed earlier is exactly what item 4 asked to check for: more absolute candidates rolling the same per-citizen chance, nothing more exotic.

### E. City capacity check
**Not the limiting factor.** Zone lot availability stayed substantial throughout every run and, notably, *increased* toward the end at both n=500 (26→65 free lots) and n=1000 (62→90 free lots) as more companies went bankrupt and returned their lots. The city was never short on physical space for new businesses.

### F. The actual mechanism (new finding, not previously documented)
`total_companies_ever_created` grows without bound (947 for n=1000) while `active_companies` peaks mid-run then declines. This is **not** capacity starvation — it's **over-entry / market fragmentation**: business formation keeps creating new companies (via both pathways), but the finite consumer-spending pool gets split across an ever-larger number of competitors, so newly-formed companies (target_headcount=2, minimal starting capital) increasingly can't capture enough revenue share to survive, and existing ones get squeezed too as the market fragments further. This produces an accelerating churn — high company birth rate, high company death rate, net decline in surviving companies — rather than the intended stabilizing effect.

### G. Inflation experiment — n=500/10-year (see note below on n=1000)
**A full n=1000/10-year run was not completed this session.** At ~30ms/tick, 87,600 ticks costs ~44 minutes — infeasible within available tool-call time. Ran the identical config (seed=12345, 20% inflation shock at year 3, same event mechanics) at **n=500 instead**, which completed in one call (253.6s). This is a disclosed substitution, not a silent one.

| Year | Unemployment | Avg wealth | GDP | Active companies |
|---|---|---|---|---|
| 0 | 0.8% | 907 | 21,574 | 80 |
| 1 | 33.8% | 599 | 10,598 | 50 |
| 2 | 65.5% | 1,066 | 5,363 | 27 |
| **3 (shock)** | **77.0%** | 1,475 | 3,200 | 36 |
| 4 | 78.4% | 1,662 | 2,681 | 39 |
| 5 | 87.1% | 1,229 | 1,768 | 24 |
| 10 | 94.9% | 584 | 623 | 7 |

### H. Recovery behavior — honest answer
**No recovery, at any point, before or after the shock.** The economy was already at 77% unemployment by year 3, purely from the same long-run mechanism (F above) — the inflation shock is superimposed on an already-collapsing baseline, not a discrete break in an otherwise-stable system. Businesses did form (both Tier-0/1 and Tier-2 mechanisms fired throughout), but net company count only ever declined after its early peak. This is **DETERMINISTIC SIMULATION + RULE-BASED BEHAVIOR** (economy.py's tick logic, business_formation) plus some **TIER-2 COGNITION** contribution (MockLLMClient choosing actions for salient citizens) — no real LLM was involved (MockLLMClient throughout, as intended for reproducible experiments).

### I. Reproducibility — confirmed
Ran the identical config (n=50, seed=123, 5,000 ticks) twice: tick, population, GDP, unemployment rate, and average wealth were **bit-for-bit identical** both times. The mechanism (seeded RNG threaded through every module, deterministic MockLLMClient) works correctly. Did not additionally re-run the full n=500/10-year inflation experiment a second time (would cost another ~4.2 minutes) given the mechanism is already confirmed at a cheap scale and is uniform across population sizes — same code path either way.

### J. Bugs found this session: **none new**. This was a pure investigation, no code changes to economy/society/cognition/city.

### K. Remaining limitations
- n=2500 population sweep incomplete (8,000/26,000 ticks)
- n=1000/10-year inflation experiment not run at literal requested scale (ran n=500 instead)
- No second inflation-experiment run for reproducibility (mechanism confirmed cheaply instead)
- **The real, actionable finding**: business formation as implemented doesn't converge to equilibrium — it needs either a survivability floor (e.g., minimum viable company size/capital) or exit-rate throttling (limit how many companies can form when the market is already saturated) to stop the over-entry/fragmentation cycle. This is a legitimate next-session fix candidate, but per this session's explicit scope ("do not fix anything unless the data justifies it" + "only fix real bugs, not design gaps"), this is a design limitation to decide on, not a bug to silently patch.

1. **50-100 citizen populations still eventually collapse**, just much
   more slowly. Worth investigating whether this is fundamentally a
   small-sample-size effect (fewer absolute entrepreneurial candidates at
   any tick) rather than a bug — if so, the honest framing is "this
   economy needs a minimum viable population to be self-sustaining,"
   which is itself a legitimate, reportable finding, not a defect to
   paper over.
2. n=1000's full 26,000-tick trajectory wasn't run to completion this
   session (time-boxed diagnostic run only) — worth completing before
   trusting the 1,000-citizen/10-year Experiment Mode acceptance test
   results.
3. The Experiment Mode 1000-citizen/10-year/20%-inflation-at-year-3
   acceptance test (originally requested at the end of the Phase 6
   session) still hasn't been run to full completion with a stable
   economy underneath it — that's the natural next step now that the
   baseline is dramatically more stable, per your step 10.

