"""
API layer — Flask (FastAPI wasn't installable in this sandboxed
environment, no network access). The simulation core in civ_lab/ has zero
dependency on this file's framework; swapping to FastAPI + async/WebSockets
for live push updates (instead of this poll-based JSON API) is a drop-in
replacement described in the architecture doc, not a rewrite.

Run:  python3 api.py
Then: open dashboard.html in a browser (it polls this API on :5001)
"""

from __future__ import annotations
import os
import time
import threading
from dataclasses import asdict
from flask import Flask, jsonify, request, send_from_directory

from civ_lab.seed import build_default_simulation
from civ_lab import city

app = Flask(__name__)
sim = build_default_simulation(n_citizens=50, n_companies=8, seed=42)


@app.get("/health")
def health():
    """Cheap deployment health check with no simulation mutation."""
    return jsonify({"status": "ok", "tick": sim.world.tick, "llm": sim.llm_status()})

# CORS is configurable, not hardcoded wide-open, once you know your actual
# frontend origin (e.g. after deploying to Vercel). Defaults to "*" so
# nothing breaks with zero configuration (matches every other "works out
# of the box" default in this project) — set ALLOWED_ORIGINS to lock it
# down, e.g.:
#   ALLOWED_ORIGINS=https://my-civilization.vercel.app
# Comma-separate multiple origins if needed.
_allowed_origins_env = os.environ.get("ALLOWED_ORIGINS", "*").strip()
ALLOWED_ORIGINS = [o.strip() for o in _allowed_origins_env.split(",") if o.strip()] or ["*"]


@app.after_request
def add_security_headers(response):
    origin = request.headers.get("Origin")
    if ALLOWED_ORIGINS == ["*"]:
        response.headers["Access-Control-Allow-Origin"] = "*"
    elif origin in ALLOWED_ORIGINS:
        response.headers["Access-Control-Allow-Origin"] = origin
        response.headers["Vary"] = "Origin"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    # Baseline hardening — cheap, doesn't touch anything the app relies on.
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    return response


# ---- Lightweight per-IP rate limiting for mutating/expensive endpoints ----
# No external dependency (no Redis) — matches the project's existing
# "no unnecessary infra" stance. This exists to stop a public deployment
# from being trivially abused (e.g. scripted /tick spam, or spawning many
# concurrent /experiment/create background threads — each one is real CPU
# work on a free-tier instance). It is NOT a substitute for real auth if
# you need one; it just stops casual abuse.
_rate_limit_state = {}
_rate_limit_lock = threading.Lock()


def rate_limited(max_calls: int, window_seconds: float):
    def decorator(fn):
        def wrapper(*args, **kwargs):
            ip = request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()
            key = (ip, fn.__name__)
            now = time.time()
            with _rate_limit_lock:
                timestamps = [t for t in _rate_limit_state.get(key, []) if now - t < window_seconds]
                if len(timestamps) >= max_calls:
                    return jsonify({"error": f"Rate limit exceeded: max {max_calls} calls per {window_seconds:.0f}s for this action."}), 429
                timestamps.append(now)
                _rate_limit_state[key] = timestamps
            return fn(*args, **kwargs)
        wrapper.__name__ = fn.__name__
        return wrapper
    return decorator


@app.get("/")
def index():
    # The visual city is the primary experience (Phase 2 spec); the
    # analytics dashboard from Phase 1-5 is still available at
    # /dashboard.html for the deeper charts/inspector view.
    return send_from_directory(".", "city.html")


@app.get("/dashboard.html")
def dashboard():
    return send_from_directory(".", "dashboard.html")


@app.get("/llm/status")
def llm_status():
    """Live cognition-provider status for the Nexus UI and diagnostics."""
    return jsonify(sim.llm_status())


@app.get("/world/stats")
def world_stats():
    return jsonify(sim.stats())


@app.get("/world/events")
def world_events():
    limit = int(request.args.get("limit", 30))
    return jsonify(sim.world.event_log[-limit:])


@app.get("/politics/parties")
def list_parties():
    return jsonify([
        {"id": p.id, "name": p.name, "ideology_center": p.ideology_center,
         "approval": round(p.approval, 3), "in_power": p.in_power}
        for p in sim.parties.values()
    ])


@app.get("/citizens")
def list_citizens():
    return jsonify([
        {"id": c.id, "name": c.name, "age": c.age, "alive": c.alive,
         "status": c.status.value, "wealth": round(c.wealth, 2),
         "happiness": round(c.happiness, 3), "employer_id": c.employer_id,
         "marital_status": c.marital_status.value,
         "political_ideology": c.political_ideology,
         "salience_score": round(c.salience_score, 3), "credit_score": round(c.credit_score,1),
         "loan_balance": round(c.loan_balance,2), "housing_value": round(c.housing_value,2),
         "owns_home": c.owns_home, "career_level": c.career_level, "reputation": round(c.reputation,3)}
        for c in sim.citizens.values()
    ])


@app.get("/citizens/<int:citizen_id>")
def get_citizen(citizen_id: int):
    citizen = sim.citizens.get(citizen_id)
    if citizen is None:
        return jsonify({"error": "not found"}), 404
    data = asdict(citizen)
    data["status"] = citizen.status.value
    data["marital_status"] = citizen.marital_status.value
    employer = sim.companies.get(citizen.employer_id) if citizen.employer_id else None
    data["employer_name"] = employer.name if employer else None
    party = sim.parties.get(citizen.party_id) if citizen.party_id else None
    data["party_name"] = party.name if party else None
    # memories already serialize fine as dataclasses via asdict; trim to
    # the most recent 25 for payload size
    data["memories"] = data["memories"][-25:]
    return jsonify(data)


@app.get("/companies")
def list_companies():
    # Additive fields (revenue/profit/wage budget/target headcount) for the
    # Phase 3 building-inspector panel — no new backend state, these already
    # existed on Company, just weren't serialized here before.
    return jsonify([
        {"id": co.id, "name": co.name, "sector": co.sector, "headcount": co.headcount,
         "cash": round(co.cash, 2), "price_level": round(co.price_level, 2),
         "is_bankrupt": co.is_bankrupt, "loc_x": co.loc_x, "loc_y": co.loc_y,
         "building_type": co.building_type,
         "revenue_last_tick": round(co.revenue_last_tick, 2),
         "profit_last_tick": round(co.profit_last_tick, 2),
         "wage_budget_per_head": round(co.wage_budget_per_head, 2),
         "target_headcount": co.target_headcount, "stock_price": round(co.stock_price,2),
         "productivity": round(co.productivity,3), "technology_level": round(co.technology_level,3),
         "debt": round(co.debt,2)}
        for co in sim.companies.values()
    ])


@app.get("/city/layout")
def city_layout():
    """Static (per-reset) city grid — fetch once, not every poll."""
    layout = sim.city_layout
    if layout is None:
        return jsonify({"error": "city not generated yet"}), 500
    return jsonify({
        "width": layout.width,
        "height": layout.height,
        "tiles": layout.tiles,  # [y][x] -> tile type string
        "civic_buildings": layout.civic_buildings,
    })


@app.get("/city/citizens")
def city_citizens():
    """Lightweight per-tick render payload — position, activity, thought,
    and enough identity to draw a consistent sprite client-side. Kept
    separate from the heavier /citizens (full economic/political detail)
    so the render loop's poll stays small."""
    # Additive fields (employer_id, home_x/home_y) so the frontend can map
    # citizens -> their workplace building and home lot for the Phase 3
    # building-click inspector, without a second round-trip per building.
    return jsonify([
        {
            "id": c.id, "name": c.name, "age": c.age, "alive": c.alive,
            "grid_x": c.grid_x, "grid_y": c.grid_y,
            "home_x": c.home_x, "home_y": c.home_y,
            "employer_id": c.employer_id,
            "activity": c.activity, "thought": c.current_thought,
            "status": c.status.value,
            "profession": city.profession_label(c, sim.companies),
            "happiness": round(c.happiness, 3),
            "salience_score": round(c.salience_score, 3),
        }
        for c in sim.citizens.values()
    ])


@app.post("/tick")
@rate_limited(max_calls=200, window_seconds=60)  # normal play polls ~1.7/s; generous headroom over that
def advance_tick():
    n = int((request.json or {}).get("n", 1))
    n = max(1, min(n, 500))  # guard against accidental huge requests
    sim.step(n)
    return jsonify(sim.stats())


@app.post("/sandbox/variable")
@rate_limited(max_calls=30, window_seconds=60)
def sandbox_variable():
    body = request.json or {}
    path = body.get("path")
    value = body.get("value")
    if not path:
        return jsonify({"error": "path is required, e.g. 'world.interest_rate'"}), 400
    try:
        msg = sim.apply_sandbox_variable(path, value)
    except (ValueError, KeyError) as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"message": msg, "stats": sim.stats()})


@app.post("/sandbox/event")
@rate_limited(max_calls=30, window_seconds=60)
def sandbox_event():
    body = request.json or {}
    event_name = body.get("event")
    severity = float(body.get("severity", 0.5))
    if not event_name:
        return jsonify({"error": "event is required, e.g. 'recession'"}), 400
    try:
        msg = sim.trigger_event(event_name, severity)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    return jsonify({"message": msg, "stats": sim.stats()})


@app.post("/reset")
@rate_limited(max_calls=10, window_seconds=60)
def reset():
    global sim
    body = request.json or {}
    sim = build_default_simulation(
        n_citizens=int(body.get("n_citizens", 50)),
        n_companies=int(body.get("n_companies", 8)),
        seed=int(body.get("seed", 42)),
    )
    return jsonify(sim.stats())


# ==================================================================
# Nexus v1.0 analytics, replay and persistence
# ==================================================================

@app.get("/analytics/history")
def analytics_history():
    limit = max(1, min(int(request.args.get("limit", 300)), 2000))
    return jsonify(sim.world.macro_history[-limit:])

@app.get("/replay")
def replay():
    limit = max(1, min(int(request.args.get("limit", 300)), 2000))
    return jsonify(sim.world.replay_history[-limit:])

@app.get("/relationships")
def relationships():
    return jsonify(sim.world.relationships)

@app.get("/society/overview")
def society_overview():
    alive=[c for c in sim.citizens.values() if c.alive]
    return jsonify({"polarization":sim.world.polarization,"social_cohesion":sim.world.social_cohesion,
                    "poverty_rate":sim.world.poverty_rate,
                    "families":sum(1 for c in alive if c.marital_status.value == "married")//2,
                    "children":sum(1 for c in alive if c.age < 18),
                    "average_credit_score": round(sum(c.credit_score for c in alive)/max(1,len(alive)),1)})

@app.post("/checkpoint/save")
@rate_limited(max_calls=20, window_seconds=60)
def checkpoint_save():
    cid=(request.json or {}).get("id", "latest")
    return jsonify({"checkpoint_id":checkpoint_store.save(sim, str(cid)), "tick":sim.world.tick})

@app.get("/checkpoint/list")
def checkpoint_list():
    return jsonify(checkpoint_store.list())

@app.post("/checkpoint/load")
@rate_limited(max_calls=10, window_seconds=60)
def checkpoint_load():
    cid=(request.json or {}).get("id", "latest")
    try:
        checkpoint_store.load(sim, str(cid))
        return jsonify(sim.stats())
    except KeyError:
        return jsonify({"error":"checkpoint not found"}),404

@app.get("/experiment/catalog")
def experiment_catalog():
    from civ_lab.experiment import ALL_EVENT_NAMES
    return jsonify(sorted(ALL_EVENT_NAMES))

# ==================================================================
# Experiment Mode (Phase 6) — runs on the SAME Simulation class as the
# live world above, in a background thread so a multi-year run doesn't
# block the Flask request. Results are kept in memory only (no
# Postgres yet, per the phase scope) in `experiments`, keyed by id.
# ==================================================================
import threading
import uuid
from civ_lab.experiment import ExperimentConfig, ScheduledEvent, run_experiment, to_json, time_series_to_csv
from civ_lab.persistence import CheckpointStore

checkpoint_store = CheckpointStore()
experiments = {}  # id -> {"status": "running"|"done"|"error", "progress": float, "config": dict, "result": ExperimentResult|None, "error": str|None}


def _run_experiment_thread(exp_id, config):
    def on_progress(fraction, snap):
        experiments[exp_id]["progress"] = fraction
        experiments[exp_id]["latest_snapshot"] = snap
    try:
        result = run_experiment(config, progress_callback=on_progress)
        experiments[exp_id]["status"] = "done"
        experiments[exp_id]["progress"] = 1.0
        experiments[exp_id]["result"] = result
    except Exception as e:
        experiments[exp_id]["status"] = "error"
        experiments[exp_id]["error"] = str(e)


@app.post("/experiment/create")
@rate_limited(max_calls=5, window_seconds=300)  # each call spawns a real background compute thread
def experiment_create():
    body = request.json or {}
    events_cfg = [ScheduledEvent(year=e["year"], event=e["event"], severity=e.get("severity", 0.7))
                  for e in body.get("events", [])]
    config = ExperimentConfig(
        name=body.get("name", "Untitled Experiment"),
        population=int(body.get("population", 1000)),
        n_companies=body.get("n_companies"),
        years=float(body.get("years", 10)),
        seed=int(body.get("seed", 12345)),
        starting_unemployment=float(body.get("starting_unemployment", 0.06)),
        starting_inflation=float(body.get("starting_inflation", 0.0)),
        starting_interest_rate=float(body.get("starting_interest_rate", 0.03)),
        starting_tax_rate=float(body.get("starting_tax_rate", 0.20)),
        starting_government_budget=float(body.get("starting_government_budget", 50_000.0)),
        wealth_inequality=float(body.get("wealth_inequality", 0.5)),
        events=events_cfg,
    )
    exp_id = uuid.uuid4().hex[:12]
    experiments[exp_id] = {"status": "running", "progress": 0.0, "config": body, "result": None,
                            "error": None, "latest_snapshot": None}
    thread = threading.Thread(target=_run_experiment_thread, args=(exp_id, config), daemon=True)
    thread.start()
    return jsonify({"experiment_id": exp_id})


@app.get("/experiment/status/<exp_id>")
def experiment_status(exp_id):
    exp = experiments.get(exp_id)
    if not exp:
        return jsonify({"error": "unknown experiment id"}), 404
    return jsonify({"status": exp["status"], "progress": exp["progress"],
                     "latest_snapshot": exp["latest_snapshot"], "error": exp["error"]})


@app.get("/experiment/results/<exp_id>")
def experiment_results(exp_id):
    exp = experiments.get(exp_id)
    if not exp:
        return jsonify({"error": "unknown experiment id"}), 404
    if exp["status"] != "done":
        return jsonify({"error": f"experiment is {exp['status']}, not done yet"}), 409
    return app.response_class(to_json(exp["result"]), mimetype="application/json")


@app.get("/experiment/export/<exp_id>")
def experiment_export(exp_id):
    exp = experiments.get(exp_id)
    if not exp or exp["status"] != "done":
        return jsonify({"error": "experiment not available"}), 404
    fmt = request.args.get("format", "json")
    if fmt == "csv":
        return app.response_class(time_series_to_csv(exp["result"]), mimetype="text/csv",
                                   headers={"Content-Disposition": f"attachment; filename=experiment_{exp_id}.csv"})
    return app.response_class(to_json(exp["result"]), mimetype="application/json",
                               headers={"Content-Disposition": f"attachment; filename=experiment_{exp_id}.json"})


@app.get("/experiment/list")
def experiment_list():
    return jsonify([
        {"id": eid, "name": e["config"].get("name", "Untitled"), "status": e["status"], "progress": e["progress"]}
        for eid, e in experiments.items()
    ])


if __name__ == "__main__":
    # Local dev only — production uses Gunicorn (see render.yaml /
    # README "Deployment"), which imports `app` directly and never runs
    # this block. PORT defaults to 5001 to keep `python3 api.py` behaving
    # exactly as before for local development; binding to 0.0.0.0 instead
    # of Flask's default 127.0.0.1 is harmless locally and correct if this
    # block ever does run somewhere PORT is externally supplied.
    port = int(os.environ.get("PORT", 5001))
    app.run(host="0.0.0.0", port=port, debug=False)
