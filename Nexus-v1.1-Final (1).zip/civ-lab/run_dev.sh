#!/usr/bin/env bash
# One-command local dev: starts the Flask simulation backend (:5001) and a
# static file server for the frontend (:8080), then prints the URL to open.
#
# There's no npm/build step here on purpose — city.html is a single
# dependency-free static file. This script is the "one command" the
# architecture doesn't otherwise need.
#
# Usage:  ./run_dev.sh
# Stop:   Ctrl+C (kills both servers)

set -e
cd "$(dirname "$0")"

if ! python3 -c "import flask" 2>/dev/null; then
  echo "Flask not installed — run: pip install -r requirements.txt"
  exit 1
fi

echo "Starting simulation backend on http://localhost:5001 ..."
python3 api.py &
API_PID=$!

echo "Starting frontend static server on http://localhost:8080 ..."
python3 -m http.server 8080 &
HTTP_PID=$!

cleanup() {
  echo ""
  echo "Stopping servers..."
  kill "$API_PID" "$HTTP_PID" 2>/dev/null
}
trap cleanup EXIT INT TERM

sleep 1
echo ""
echo "Ready. Open: http://localhost:8080/city.html"
echo "(Ctrl+C stops both servers)"
wait
