"""
Phase 5 critical test (spec section 13).

Citizen A and Citizen B: same income, age, job, and economic shock.
Different personality (risk_tolerance) and wealth. Verifies they produce
DIFFERENT validated decisions from the identical triggering event —
proof the agents are individualized, not running one shared script.

Run: python3 critical_test.py
"""
from __future__ import annotations
from civ_lab.models import Citizen, EmploymentStatus
from civ_lab.simulation import Simulation
from civ_lab.llm import MockLLMClient
from civ_lab import cognition, city


def make_citizen(cid, risk_tolerance, wealth):
    return Citizen(
        id=cid, name=f"TestCitizen{cid}", age=40,
        skill_level=0.6, education_level=0.6, political_ideology=0.0,
        consumption_propensity=0.7, wealth=wealth, risk_tolerance=risk_tolerance,
        status=EmploymentStatus.EMPLOYED,
    )


def main():
    sim = Simulation(seed=1, llm=MockLLMClient())
    a = make_citizen(101, risk_tolerance=0.85, wealth=5000)   # high risk tolerance, high savings
    b = make_citizen(102, risk_tolerance=0.15, wealth=5000)   # low risk tolerance, same savings
    sim.citizens[a.id] = a
    sim.citizens[b.id] = b
    sim.city_layout = city.generate_layout(sim.rng, n_house_lots=2, n_companies=0)

    # identical shock, identical event category, identical framing
    cognition.bump_salience(a, 0.7, "Lost their job in a wave of mass layoffs.", sim.world, "job_loss")
    cognition.bump_salience(b, 0.7, "Lost their job in a wave of mass layoffs.", sim.world, "job_loss")
    a.status = EmploymentStatus.UNEMPLOYED
    b.status = EmploymentStatus.UNEMPLOYED

    cognition.run_cognition_pass(sim.citizens, sim.companies, sim.world, sim.llm,
                                  layout=sim.city_layout, rng=sim.rng, parties=sim.parties)

    print(f"Citizen A (risk_tolerance={a.risk_tolerance}, wealth={a.wealth}): "
          f"decision={a.last_action!r} | result={a.last_action_result!r}")
    print(f"Citizen B (risk_tolerance={b.risk_tolerance}, wealth={b.wealth}): "
          f"decision={b.last_action!r} | result={b.last_action_result!r}")

    assert a.last_action != "" and b.last_action != "", "Both citizens should have made a decision"
    assert a.last_action != b.last_action, (
        f"FAILED: identical decision ({a.last_action}) despite different personality — "
        "agents are not individualized."
    )
    print(f"\nPASS: same event, different personality -> different decisions "
          f"({a.last_action} vs {b.last_action}).")


if __name__ == "__main__":
    main()
